
const { Schema, model } = require('mongoose');

const ticketSchema = new Schema({
    guildId: { type: String, required: true },
    channelId: { type: String, required: true },
    userId: { type: String, required: true },
    status: { type: String, default: 'open', enum: ['open', 'closed'] },
    createdAt: { type: Date, default: Date.now },
    closedAt: { type: Date },
    messages: [{ 
        author: String, 
        content: String, 
        timestamp: Date 
    }]
});

const ticketPanelSchema = new Schema({
    guildId: { type: String, required: true, unique: true },
    channel: { type: String, required: true },
    supportRole: { type: String, required: true },
    pingRole: { type: String },
    openCategory: { type: String, required: true },
    closedCategory: { type: String },
    embedTitle: { type: String, default: 'Ticket Panel' },
    embedDescription: { type: String, default: 'Support will be with you shortly' },
    enabled: { type: Boolean, default: false }
});

module.exports = {
    Ticket: model('Ticket', ticketSchema),
    TicketPanel: model('TicketPanel', ticketPanelSchema)
};
