const { EmbedBuilder } = require('discord.js');

module.exports = async (client) => {
    client.on('messageCreate', async (message) => {
        if (!message.guild || message.author.bot) return;

        const guildId = message.guild.id;
        const userId = message.author.id;
        const susmodeActive = await client.db.get(`susmode_${guildId}`);
        
        if (!susmodeActive) return;

        const config = await client.db.get(`susmode_config_${guildId}`) || {
            maxMessages: 10,
            timeWindow: 30000,
            autoKick: false,
            autoBan: false,
            logChannel: null
        };

        // Get user activity data
        const activityKey = `susmode_activity_${guildId}_${userId}`;
        const userActivity = await client.db.get(activityKey) || [];
        const now = Date.now();

        // Add current message timestamp
        userActivity.push(now);

        // Remove old messages outside time window
        const recentActivity = userActivity.filter(timestamp => now - timestamp < config.timeWindow);

        // Update activity data
        await client.db.set(activityKey, recentActivity);

        // Check if user exceeded message limit
        if (recentActivity.length >= config.maxMessages) {
            const member = message.guild.members.cache.get(userId);
            if (!member) return;

            // Don't take action against administrators
            if (member.permissions.has('Administrator')) return;

            const logEmbed = new EmbedBuilder()
                .setColor('#FF4500')
                .setTitle('Suspicious Activity Detected')
                .setDescription(`User ${message.author} exceeded message limit`)
                .addFields([
                    { name: 'Messages', value: recentActivity.length.toString(), inline: true },
                    { name: 'Time Window', value: `${config.timeWindow / 1000}s`, inline: true },
                    { name: 'Channel', value: message.channel.toString(), inline: true }
                ])
                .setTimestamp();

            // Log to designated channel
            if (config.logChannel) {
                const logChannel = message.guild.channels.cache.get(config.logChannel);
                if (logChannel) {
                    await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
                }
            }

            // Take automatic action if configured
            try {
                if (config.autoBan && message.guild.me.permissions.has('BanMembers')) {
                    await member.ban({ reason: 'Suspicious activity - automated ban' });
                    if (config.logChannel) {
                        const logChannel = message.guild.channels.cache.get(config.logChannel);
                        if (logChannel) {
                            await logChannel.send({
                                embeds: [
                                    new EmbedBuilder()
                                        .setColor('#FF0000')
                                        .setDescription(`User ${message.author} has been banned for suspicious activity`)
                                ]
                            }).catch(() => {});
                        }
                    }
                } else if (config.autoKick && message.guild.me.permissions.has('KickMembers')) {
                    await member.kick('Suspicious activity - automated kick');
                    if (config.logChannel) {
                        const logChannel = message.guild.channels.cache.get(config.logChannel);
                        if (logChannel) {
                            await logChannel.send({
                                embeds: [
                                    new EmbedBuilder()
                                        .setColor('#FFAA00')
                                        .setDescription(`User ${message.author} has been kicked for suspicious activity`)
                                ]
                            }).catch(() => {});
                        }
                    }
                }
            } catch (error) {
                console.error('Error taking susmode action:', error);
            }

            // Clear user activity after action
            await client.db.delete(activityKey);
        }
    });
};