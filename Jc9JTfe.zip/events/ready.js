module.exports = async (client) => {
    client.on('ready', async () => {
        try {
            client.user.setPresence({
                activities: [
                    {
                        name: `FasterThenLight`,
                        type: `WATCHING`
                    }
                ],
                status: `online`
            })
            client.logger.log(`✅ BITZXIER Bot is ready! Logged in as ${client.user.tag}`, 'ready')
            client.logger.log(`🚀 Serving ${client.guilds.cache.size} servers with ${client.users.cache.size} users`, 'ready')
            client.logger.log(`⚡ Performance optimizations active - Ultra-low latency mode enabled`, 'ready')
        } catch (error) {
            client.logger.log(`❌ Error in ready event: ${error.message}`, 'error')
        }
    })
}
