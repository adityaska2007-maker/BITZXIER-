module.exports = async (client) => {
    client.on('messageCreate', async (message) => {
        // Skip if message is from a bot or not in a guild
        if (message.author.bot || !message.guild) return;

        // Skip if message starts with bot prefix (to avoid triggering on commands)
        const prefix = await client.db.get(`${message.guild.id}_prefix`) || '&';
        if (message.content.startsWith(prefix)) return;

        // Check if server is blacklisted
        let check = await client.util.BlacklistCheck(message.guild);
        if (check) return;

        // Check if bot has permission to add reactions
        if (!message.guild.members.me.permissions.has('ADD_REACTIONS')) return;
        if (!message.channel.permissionsFor(message.guild.members.me).has('ADD_REACTIONS')) return;

        // Check if autoresponder was triggered (to avoid conflicts)
        if (message.autoresponderTriggered) return;

        // Get all autoreactors for this guild
        const allKeys = await client.db.all();
        const autoreactors = allKeys.filter(item => 
            item.ID.startsWith(`${message.guild.id}_autoreactor_`)
        );

        if (autoreactors.length === 0) return;

        const messageContent = message.content.toLowerCase();
        const userRoles = message.member.roles.cache.map(role => role.id);

        for (const item of autoreactors) {
            const data = item.data;
            let shouldReact = false;

            try {
                // Check trigger conditions based on type
                switch (data.type) {
                    case 'channel':
                        shouldReact = message.channel.id === data.target;
                        break;

                    case 'user':
                        shouldReact = message.author.id === data.target;
                        break;

                    case 'role':
                        shouldReact = userRoles.includes(data.target);
                        break;

                    case 'keyword':
                        if (data.mode === 'exact') {
                            shouldReact = messageContent === data.keyword;
                        } else if (data.mode === 'include') {
                            shouldReact = messageContent.includes(data.keyword);
                        }
                        break;
                }

                if (shouldReact) {
                    // Add reaction with error handling
                    try {
                        await message.react(data.emoji);
                    } catch (reactionError) {
                        // If reaction fails, try to remove invalid autoreactor
                        if (reactionError.code === 10014 || reactionError.code === 50013) {
                            // Invalid emoji or no permission
                            console.log(`Removing invalid autoreactor: ${item.ID}`);
                            await client.db.delete(item.ID);
                        }
                    }
                }
            } catch (error) {
                console.error('AutoReactor processing error:', error);
            }
        }
    });
};