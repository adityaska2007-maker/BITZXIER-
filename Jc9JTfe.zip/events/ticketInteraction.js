
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = async (client) => {
    client.on('interactionCreate', async (interaction) => {
        if (!interaction.isButton() && !interaction.isStringSelectMenu()) return;

        // Ticket panel setup interactions
        if (interaction.customId === 'ticket_channel') {
            return handleChannelSelect(client, interaction);
        }
        
        if (interaction.customId === 'support_role') {
            return handleRoleSelect(client, interaction, 'support');
        }
        
        if (interaction.customId === 'ping_role') {
            return handleRoleSelect(client, interaction, 'ping');
        }
        
        if (interaction.customId === 'open_category') {
            return handleCategorySelect(client, interaction, 'open');
        }
        
        if (interaction.customId === 'closed_category') {
            return handleCategorySelect(client, interaction, 'closed');
        }
        
        if (interaction.customId === 'embed_message') {
            return handleEmbedConfig(client, interaction);
        }
        
        if (interaction.customId === 'done_setup') {
            return handleDoneSetup(client, interaction);
        }
        
        if (interaction.customId === 'abort_setup') {
            return handleAbortSetup(client, interaction);
        }

        // Select menu handlers
        if (interaction.customId === 'select_ticket_channel') {
            return handleSelectChannel(client, interaction);
        }

        if (interaction.customId === 'select_support_role') {
            return handleSelectRole(client, interaction, 'support');
        }

        if (interaction.customId === 'select_ping_role') {
            return handleSelectRole(client, interaction, 'ping');
        }

        if (interaction.customId === 'select_open_category') {
            return handleSelectCategory(client, interaction, 'open');
        }

        if (interaction.customId === 'select_closed_category') {
            return handleSelectCategory(client, interaction, 'closed');
        }

        // Ticket management interactions
        if (interaction.customId === 'create_ticket') {
            return handleCreateTicket(client, interaction);
        }
        
        if (interaction.customId === 'reopen_ticket') {
            return handleReopenTicket(client, interaction);
        }
        
        if (interaction.customId === 'delete_ticket') {
            return handleDeleteTicket(client, interaction);
        }
        
        if (interaction.customId === 'confirm_delete') {
            return handleConfirmDelete(client, interaction);
        }
        
        if (interaction.customId === 'cancel_delete') {
            return handleCancelDelete(client, interaction);
        }
    });
};

async function handleChannelSelect(client, interaction) {
    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('Ticket Panel Setup')
        .setDescription('Where should I setup the ticket panel?\nIf a channel is not listed below just start typing it\'s name in select menu box it will be shown as a option')
        .setFooter({ text: 'Ravion Ticket' });

    const channels = interaction.guild.channels.cache
        .filter(ch => ch.type === 'GUILD_TEXT')
        .first(25)
        .map(ch => ({
            label: ch.name,
            value: ch.id,
            description: `#${ch.name}`
        }));

    const selectMenu = new ActionRowBuilder()
        .addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('select_ticket_channel')
                .setPlaceholder('Select the channel')
                .addOptions(channels)
        );

    return interaction.reply({ embeds: [embed], components: [selectMenu], ephemeral: true });
}

async function handleRoleSelect(client, interaction, type) {
    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('Ticket Panel Setup')
        .setDescription(`Select a role which should be ${type === 'support' ? 'allowed to view the ticket channels' : 'pinged as a ticket is created'}\nIf a role is not listed below just start typing it's name in select menu box it will be shown as a option`)
        .setFooter({ text: 'Ravion Ticket' });

    const roles = interaction.guild.roles.cache
        .filter(role => !role.managed && role.id !== interaction.guild.id)
        .first(25)
        .map(role => ({
            label: role.name,
            value: role.id,
            description: `@${role.name}`
        }));

    const selectMenu = new ActionRowBuilder()
        .addComponents(
            new StringSelectMenuBuilder()
                .setCustomId(`select_${type}_role`)
                .setPlaceholder('Select the role')
                .addOptions(roles)
        );

    return interaction.reply({ embeds: [embed], components: [selectMenu], ephemeral: true });
}

async function handleCategorySelect(client, interaction, type) {
    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('Ticket Panel Setup')
        .setDescription(`Select a category for ${type} tickets\nIf a category is not listed below just start typing it's name in select menu box it will be shown as a option`)
        .setFooter({ text: 'Ravion Ticket' });

    const categories = interaction.guild.channels.cache
        .filter(ch => ch.type === 'GUILD_CATEGORY')
        .first(25)
        .map(cat => ({
            label: cat.name,
            value: cat.id,
            description: cat.name
        }));

    const selectMenu = new ActionRowBuilder()
        .addComponents(
            new StringSelectMenuBuilder()
                .setCustomId(`select_${type}_category`)
                .setPlaceholder('Select the category')
                .addOptions(categories)
        );

    return interaction.reply({ embeds: [embed], components: [selectMenu], ephemeral: true });
}

async function handleEmbedConfig(client, interaction) {
    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('Ticket Panel Setup')
        .setDescription('Configure the ticket panel embed message')
        .setFooter({ text: 'Ravion Ticket' });

    return interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleSelectChannel(client, interaction) {
    const channelId = interaction.values[0];
    await client.db.set(`ticket_${interaction.guild.id}.channel`, channelId);
    
    return interaction.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#00FF00')
                .setDescription(`<:check:1387502959444758579> Ticket channel set to <#${channelId}>`)
        ],
        ephemeral: true
    });
}

async function handleSelectRole(client, interaction, type) {
    const roleId = interaction.values[0];
    await client.db.set(`ticket_${interaction.guild.id}.${type}Role`, roleId);
    
    return interaction.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#00FF00')
                .setDescription(`<:check:1387502959444758579> ${type} role set to <@&${roleId}>`)
        ],
        ephemeral: true
    });
}

async function handleSelectCategory(client, interaction, type) {
    const categoryId = interaction.values[0];
    await client.db.set(`ticket_${interaction.guild.id}.${type}Category`, categoryId);
    
    return interaction.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#00FF00')
                .setDescription(`<:check:1387502959444758579> ${type} tickets category set to ${interaction.guild.channels.cache.get(categoryId)?.name}`)
        ],
        ephemeral: true
    });
}

async function handleDoneSetup(client, interaction) {
    const ticketData = await client.db.get(`ticket_${interaction.guild.id}`);
    
    if (!ticketData || !ticketData.channel) {
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Please configure the ticket channel first.')
            ],
            ephemeral: true
        });
    }

    const channel = interaction.guild.channels.cache.get(ticketData.channel);
    
    if (!channel) {
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Ticket channel not found.')
            ],
            ephemeral: true
        });
    }

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle(ticketData.embedTitle || 'Ticket Panel')
        .setDescription(ticketData.embedDescription || 'Support will be with you shortly')
        .setFooter({ text: `Developed by ${client.user.username}`, iconURL: client.user.displayAvatarURL() });

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('create_ticket')
                .setLabel('Create Ticket')
                .setStyle(1)
        );

    try {
        await channel.send({ embeds: [embed], components: [row] });
        await client.db.set(`ticket_${interaction.guild.id}.enabled`, true);

        // Update the original setup message to show completion
        const updatedEmbed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('Ticket Panel Setup Complete')
            .setDescription('✅ Ticket panel has been successfully set up and deployed!')
            .addFields([
                { name: 'Channel:', value: `<#${ticketData.channel}>` },
                { name: 'Support Role:', value: ticketData.supportRole ? `<@&${ticketData.supportRole}>` : 'None' },
                { name: 'Ping Role:', value: ticketData.pingRole ? `<@&${ticketData.pingRole}>` : 'None' },
                { name: 'Open Category:', value: ticketData.openCategory ? interaction.guild.channels.cache.get(ticketData.openCategory)?.name || 'Unknown' : 'None' },
                { name: 'Closed Category:', value: ticketData.closedCategory ? interaction.guild.channels.cache.get(ticketData.closedCategory)?.name || 'Unknown' : 'None' }
            ]);

        await interaction.update({ embeds: [updatedEmbed], components: [] });
    } catch (error) {
        console.error('Error setting up ticket panel:', error);
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Failed to setup ticket panel. Please check permissions.')
            ],
            ephemeral: true
        });
    }
}

async function handleAbortSetup(client, interaction) {
    return interaction.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#FF0000')
                .setDescription('<:cross:1387502959444758580> Ticket panel setup aborted.')
        ],
        ephemeral: true
    });
}

async function handleCreateTicket(client, interaction) {
    try {
        console.log(`Creating ticket for user ${interaction.user.username} in guild ${interaction.guild.name}`);
        
        const ticketData = await client.db.get(`ticket_${interaction.guild.id}`);
        console.log('Ticket data:', ticketData);
        
        if (!ticketData || !ticketData.enabled) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Ticket system is disabled.')
                ],
                ephemeral: true
            });
        }

        // Check if user already has a ticket
        const existingTicket = await client.db.get(`user_ticket_${interaction.guild.id}_${interaction.user.id}`);
        if (existingTicket) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> You already have an open ticket.')
                ],
                ephemeral: true
            });
        }

        // Create ticket channel
        console.log('Creating ticket channel...');
        const ticketChannel = await interaction.guild.channels.create(`ticket-${interaction.user.username}`, {
            type: 'GUILD_TEXT',
            parent: ticketData.openCategory,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: ['VIEW_CHANNEL']
                },
                {
                    id: interaction.user.id,
                    allow: ['VIEW_CHANNEL', 'SendMessages', 'ReadMessageHistory']
                }
            ]
        });
        console.log('Ticket channel created:', ticketChannel.name);

    if (ticketData.supportRole) {
        await ticketChannel.permissionOverwrites.edit(ticketData.supportRole, {
            VIEW_CHANNEL: true,
            SEND_MESSAGES: true,
            READ_MESSAGE_HISTORY: true
        });
    }

    // Save ticket data
    await client.db.set(`tickets_${interaction.guild.id}_${ticketChannel.id}`, {
        userId: interaction.user.id,
        channelId: ticketChannel.id,
        status: 'open',
        createdAt: Date.now()
    });

    await client.db.set(`user_ticket_${interaction.guild.id}_${interaction.user.id}`, ticketChannel.id);

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('Ticket Created')
        .setDescription(`Hello ${interaction.user}, support will be with you shortly!`)
        .setTimestamp();

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('delete_ticket')
                .setLabel('Delete Ticket')
                .setStyle(4)
        );

        const messageData = { 
            embeds: [embed], 
            components: [row] 
        };
        
        if (ticketData.pingRole) {
            messageData.content = `<@&${ticketData.pingRole}>`;
        }
        
        await ticketChannel.send(messageData);

        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#00FF00')
                    .setDescription(`<:check:1387502959444758579> Ticket created: ${ticketChannel}`)
            ],
            ephemeral: true
        });
        
    } catch (error) {
        console.error('Error creating ticket:', error);
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Failed to create ticket. Please check bot permissions.')
            ],
            ephemeral: true
        }).catch(() => {});
    }
}

async function handleDeleteTicket(client, interaction) {
    if (!interaction.channel.name.startsWith('ticket-')) {
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> This command can only be used in ticket channels.')
            ],
            ephemeral: true
        });
    }

    const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('Delete Ticket')
        .setDescription('Are you sure you want to delete this ticket? This action cannot be undone.');

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('confirm_delete')
                .setLabel('Yes, Delete')
                .setStyle(4),
            new ButtonBuilder()
                .setCustomId('cancel_delete')
                .setLabel('Cancel')
                .setStyle(2)
        );

    return interaction.reply({ embeds: [embed], components: [row] });
}

async function handleConfirmDelete(client, interaction) {
    const ticketData = await client.db.get(`tickets_${interaction.guild.id}_${interaction.channel.id}`);
    
    if (ticketData) {
        await client.db.delete(`user_ticket_${interaction.guild.id}_${ticketData.userId}`);
        await client.db.delete(`tickets_${interaction.guild.id}_${interaction.channel.id}`);
    }

    await interaction.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#FF0000')
                .setDescription('Ticket will be deleted in 5 seconds...')
        ]
    });

    setTimeout(() => {
        interaction.channel.delete().catch(console.error);
    }, 5000);
}

async function handleCancelDelete(client, interaction) {
    return interaction.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#00FF00')
                .setDescription('<:check:1387502959444758579> Ticket deletion cancelled.')
        ]
    });
}

async function handleReopenTicket(client, interaction) {
    // Implementation for reopening ticket
    return interaction.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#00FF00')
                .setDescription('<:check:1387502959444758579> Ticket reopened.')
        ]
    });
}
