const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    PermissionsBitField,
    Collection,
    WebhookClient
} = require('discord.js')

module.exports = async (client) => {
    client.on('messageCreate', async (message) => {
        // Fast early returns for performance
        if (message.author.bot || !message.guild) return;

        // Cache frequently used values
        const messageContent = message.content;
        const authorId = message.author.id;
        const guildId = message.guild.id;
        const channelId = message.channel.id;

        // Bot ping response (optimized)
        if (messageContent === `<@${client.user.id}>` || messageContent === `<@!${client.user.id}>`) {
            try {
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setLabel('Invite Me')
                        .setStyle(5)
                        .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`),
                    new ButtonBuilder()
                        .setLabel('Support')
                        .setStyle(5)
                        .setURL('https://discord.gg/bitzxier'),
                    new ButtonBuilder()
                        .setLabel('Website')
                        .setStyle(5)
                        .setURL('https://bitzxier.dev')
                );

                // Get the correct prefix for this server
                await client.util.setPrefix(message, client).catch(() => {});
                let prefix = message.guild.prefix || '&';

                const embed = new EmbedBuilder()
                    .setColor(client.color || '#2b2d31')
                    .setAuthor({ name: "I'm BITZXIER", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
                    .setDescription(`Hey [${message.author.username}](https://discord.com/users/${message.author.id})\nPrefix For This Server Is \`${prefix}\`\n\nUnlock More Details With \`${prefix}help\`.`)
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: "BITZXIER Is Love", iconURL: client.user.displayAvatarURL({ dynamic: true }) });

                return message.channel.send({
                    embeds: [embed],
                    components: [row]
                });
            } catch (error) {
                console.error('Error sending ping response:', error);
                return message.channel.send('Hey! I\'m BITZXIER and I\'m online!');
            }
        }

        // Ultra-fast AutoReact functionality
        setImmediate(async () => {
            try {
                let autoreacts = client.guildCache.get(`${guildId}_autoreacts`);
                if (!autoreacts) {
                    autoreacts = await client.db.get(`${guildId}_autoreacts`);
                    if (autoreacts) {
                        client.guildCache.set(`${guildId}_autoreacts`, autoreacts);
                        setTimeout(() => client.guildCache.delete(`${guildId}_autoreacts`), 600000);
                    }
                }
                
                if (autoreacts && Object.keys(autoreacts).length > 0) {
                    const lowerContent = messageContent.toLowerCase();
                    for (const [trigger, reaction] of Object.entries(autoreacts)) {
                        if (lowerContent.includes(trigger.toLowerCase())) {
                            message.react(reaction).catch(() => {});
                            break;
                        }
                    }
                }
            } catch (error) {
                // Silently handle autoreact errors
            }
        })

        try {
            let check = await client.util.BlacklistCheck(message?.guild)
            if(check) return  
            let uprem = await client.db.get(`uprem_${authorId}`)
            let upremend = await client.db.get(`upremend_${authorId}`)
            let sprem = await client.db.get(`sprem_${guildId}`)
            let spremend = await client.db.get(`spremend_${guildId}`)

            // Premium handling (simplified to avoid complexity)
            let scot = 0
            let slink = 'https://discord.gg/bitzxier'

            // Optimized prefix caching
            let prefix = client.prefixCache.get(guildId);
            if (!prefix) {
                await client.util.setPrefix(message, client).catch(() => {});
                prefix = message.guild.prefix || '&';
                client.prefixCache.set(guildId, prefix);
                // Auto-clear cache after 5 minutes
                setTimeout(() => client.prefixCache.delete(guildId), 300000);
            }

            // Cached noprefix users
            const noprefixUsers = client.noprefix || [];
            const ownerIds = ['1338088204431130654', '1066827447129088111'];
            
            // Fast permission check
            const hasNoPrefix = noprefixUsers.includes(authorId) || 
                              ownerIds.includes(authorId) || 
                              client.config.owner.includes(authorId);

            // Quick prefix validation
            const startsWithPrefix = messageContent.startsWith(prefix);
            if (!hasNoPrefix && !startsWithPrefix) return;

            // Optimized argument parsing
            const args = startsWithPrefix
                ? messageContent.slice(prefix.length).trim().split(/ +/)
                : messageContent.trim().split(/ +/);

            const cmd = args.shift().toLowerCase();
            
            // Optimized command lookup with caching
            let command = client.commandCache.get(cmd);
            if (!command) {
                command = client.commands.get(cmd) || 
                         client.commands.find((c) => c.aliases?.includes(cmd));
                if (command) {
                    client.commandCache.set(cmd, command);
                    // Auto-clear cache after 10 minutes
                    setTimeout(() => client.commandCache.delete(cmd), 600000);
                }
            }

            if (command && command.premium) {
                if (!client.config.owner.includes(message.author.id) && !uprem && !sprem) {
                    const premiumRow = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel('Invite')
                            .setStyle(5)
                            .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`),
                        new ButtonBuilder()
                            .setLabel('Premium')
                            .setStyle(5)
                            .setURL('https://discord.gg/bitzxier')
                    )
                    const embeds = new EmbedBuilder()
                        .setDescription('You Just Discovered a Premium Command Join Our Support Server To Buy Premium')
                        .setColor(client.color)

                    return message.channel.send({
                        embeds: [embeds],
                        components: [premiumRow]
                    })
                }
            }

            // Optimized ignore channel/role check
            let ignore = client.guildCache.get(`ignore_${guildId}`)
            if (!ignore) {
                ignore = (await client.db?.get(`ignore_${guildId}`)) ?? { channel: [], role: [] }
                client.guildCache.set(`ignore_${guildId}`, ignore)
                setTimeout(() => client.guildCache.delete(`ignore_${guildId}`), 300000) // 5 min cache
            }
            
            if (ignore.channel.includes(channelId) && 
                !message.member.roles.cache.some((role) => ignore.role.includes(role.id))) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color)
                            .setDescription(`I can't execute commands in this channel as it's on my ignore list.`)
                    ]
                }).then((x) => {
                    setTimeout(() => x.delete().catch(() => {}), 3000)
                })
            }

            if (!command) return

            // Optimized cooldown handling
            if (command.cooldown) {
                const cooldownKey = `${authorId}_${cmd}`;
                const cooldownAmount = (command.cooldown || 3) * 1000;
                const now = Date.now();

                if (client.cooldowns.has(cooldownKey)) {
                    const expirationTime = client.cooldowns.get(cooldownKey) + cooldownAmount;
                    if (now < expirationTime) {
                        const timeLeft = (expirationTime - now) / 1000;
                        return message.channel.send({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor(client.color)
                                    .setDescription(`Please wait, this command is on cooldown for \`${timeLeft.toFixed(1)}s\``)
                            ]
                        }).then((msg) => {
                            setTimeout(() => msg.delete().catch(() => {}), 5000);
                        });
                    }
                }
                client.cooldowns.set(cooldownKey, now);
                setTimeout(() => client.cooldowns.delete(cooldownKey), cooldownAmount);
            }

            // Execute command with error handling
            try {
                await command.run(client, message, args);
            } catch (error) {
                console.error(`Command ${command.name} failed:`, error);
                message.channel.send('❌ Something went wrong while executing that command.').catch(() => {});
            }

            // Non-blocking command logging
            if (command && command.run) {
                setImmediate(() => {
                    const weboo = new WebhookClient({
                        url: `https://discord.com/api/webhooks/1217308163016233103/P75IMICLgYQYcSL4bYHaBggcyZrBZqimz39r5RLRPpVJwAShA2bg0dNaun1uoLCpdpU3`
                    });
                    const commandlog = new EmbedBuilder()
                        .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true }))
                        .setColor(client.color)
                        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                        .setTimestamp()
                        .setDescription(
                            `Command Ran In : \`${message.guild.name} | ${guildId}\`\n Command Ran In Channel : \`${message.channel.name} | ${channelId}\`\n Command Name : \`${command.name}\`\n Command Executor : \`${message.author.tag} | ${authorId}\`\n Command Content : \`${messageContent}\``
                        );
                    weboo.send({ embeds: [commandlog] }).catch(() => {});
                });
            }
        } catch (err) {
            console.error('MessageCreate error:', err)
            if (err.code === 429) {
                await client.util.handleRateLimit()
            }
            return
        }
    })
}