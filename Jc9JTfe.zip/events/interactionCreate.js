module.exports = async (client) => {
    client.on('interactionCreate', async (interaction) => {
        // Handle ticket system interactions first
        const ticketButtons = [
            'ticket_channel', 'support_role', 'ping_role', 'open_category', 'closed_category',
            'embed_message', 'done_setup', 'abort_setup', 'create_ticket', 'reopen_ticket', 
            'delete_ticket', 'confirm_delete', 'cancel_delete'
        ];
        
        const ticketSelects = [
            'select_ticket_channel', 'select_support_role', 'select_ping_role', 
            'select_open_category', 'select_closed_category'
        ];

        if (interaction.isButton() && ticketButtons.includes(interaction.customId)) {
            // Let the ticket interaction handler deal with this
            return;
        }
        
        if (interaction.isStringSelectMenu() && ticketSelects.includes(interaction.customId)) {
            // Let the ticket interaction handler deal with this
            return;
        }

        if (interaction.isStringSelectMenu())
            await client.util.selectMenuHandle(interaction)

        // Handle giveaway button interactions
        if (interaction.isButton() && interaction.customId.startsWith('giveaway_enter_')) {
            await handleGiveawayEntry(client, interaction);
            return;
        }

        if (interaction.isCommand()) {
            await interaction.deferReply({ ephemeral: true }).catch(() => {})
            const cmd = client?.slashCommands?.get(interaction.commandName)
            if (!cmd)
                return interaction.followUp({
                    content: 'This command has been removed from our system.'
                })

            const args = []

            for (let option of interaction.options.data) {
                if (option.type === 'SUB_COMMAND') {
                    if (option.name) args.push(option.name)
                    option.options?.forEach((x) => {
                        if (x.value) args.push(x.value)
                    })
                } else if (option.value) args.push(option.value)
            }
            interaction.member = interaction.guild.members.cache.get(
                interaction.user.id
            )

            cmd.run(client, interaction, args)
        } else if (interaction.isContextMenu()) {
            await interaction.deferReply({ ephemeral: false })
            const command = client.slashCommands.get(interaction.commandName)
            if (command) command.run(client, interaction)
        }
    })
}

// Giveaway entry handler function
async function handleGiveawayEntry(client, interaction) {
    const { EmbedBuilder } = require('discord.js');

    try {
        const messageId = interaction.message.id;
        const giveawayData = await client.db.get(`giveaway_${messageId}`);

        if (!giveawayData) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#ff0000')
                        .setDescription('❌ This giveaway no longer exists.')
                ],
                ephemeral: true
            });
        }

        if (giveawayData.ended) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#ff0000')
                        .setDescription('❌ This giveaway has already ended.')
                ],
                ephemeral: true
            });
        }

        if (giveawayData.paused) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#ff0000')
                        .setDescription('⏸️ This giveaway is currently paused.')
                ],
                ephemeral: true
            });
        }

        const userId = interaction.user.id;

        // Check if user already entered
        if (giveawayData.entries.includes(userId)) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#ffaa00')
                        .setDescription('⚠️ You have already entered this giveaway!')
                ],
                ephemeral: true
            });
        }

        // Add user to entries
        giveawayData.entries.push(userId);
        await client.db.set(`giveaway_${messageId}`, giveawayData);

        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#00ff00')
                    .setDescription('🎉 Successfully entered the giveaway! Good luck!')
            ],
            ephemeral: true
        });

    } catch (error) {
        console.error('Error handling giveaway entry:', error);
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#ff0000')
                    .setDescription('❌ An error occurred while entering the giveaway.')
            ],
            ephemeral: true
        }).catch(() => {});
    }
}