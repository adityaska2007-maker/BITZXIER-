const { EmbedBuilder } = require('discord.js');

module.exports = async (client) => {
    client.on('messageCreate', async (message) => {
        // Skip if message is from a bot or not in a guild
        if (message.author.bot || !message.guild) return;

        // Skip if message starts with bot prefix (to avoid triggering on commands)
        const prefix = await client.db.get(`${message.guild.id}_prefix`) || '&';
        if (message.content.startsWith(prefix)) return;

        // Check if server is blacklisted
        let check = await client.util.BlacklistCheck(message.guild);
        if (check) return;

        // Get ignore data
        const ignoreData = await client.db.get(`${message.guild.id}_autoresponder_ignore`) || { users: [], roles: [] };

        // Check if user is ignored
        if (ignoreData.users.includes(message.author.id)) return;

        // Check if user has ignored role
        const userRoles = message.member.roles.cache.map(role => role.id);
        if (ignoreData.roles.some(roleId => userRoles.includes(roleId))) return;

        // Get all autoresponders for this guild
        const allKeys = await client.db.all();
        const autoresponders = allKeys.filter(item => 
            item.ID.startsWith(`${message.guild.id}_autoresponder_`)
        );

        if (autoresponders.length === 0) return;

        const messageContent = message.content.toLowerCase();

        for (const item of autoresponders) {
            const data = item.data;
            let shouldTrigger = false;

            // Check trigger conditions based on type
            switch (data.type) {
                case 'keyword':
                    if (data.mode === 'exact') {
                        shouldTrigger = messageContent === data.trigger;
                    } else {
                        shouldTrigger = messageContent.includes(data.trigger);
                    }
                    break;

                case 'user':
                    if (message.author.id === data.target) {
                        if (data.mode === 'exact') {
                            shouldTrigger = messageContent === data.trigger;
                        } else {
                            shouldTrigger = messageContent.includes(data.trigger);
                        }
                    }
                    break;

                case 'role':
                    if (userRoles.includes(data.target)) {
                        if (data.mode === 'exact') {
                            shouldTrigger = messageContent === data.trigger;
                        } else {
                            shouldTrigger = messageContent.includes(data.trigger);
                        }
                    }
                    break;

                case 'channel':
                    if (message.channel.id === data.target) {
                        if (data.mode === 'exact') {
                            shouldTrigger = messageContent === data.trigger;
                        } else {
                            shouldTrigger = messageContent.includes(data.trigger);
                        }
                    }
                    break;
            }

            if (shouldTrigger) {
                try {
                    // Process variables in reply
                    let reply = await processVariables(data.reply, message);

                    // Send reply
                    const replyMessage = await message.channel.send({
                        content: data.replyToUser ? `${message.author}, ${reply}` : reply,
                        allowedMentions: { repliedUser: data.replyToUser }
                    });

                    if (replyMessage && data.autoDelete > 0) {
                        setTimeout(() => {
                            replyMessage.delete().catch(() => {});
                        }, data.autoDelete * 1000);
                    }

                    // Mark message as having triggered autoresponder
                    message.autoresponderTriggered = true;

                    // Only trigger one autoresponder per message
                    break;
                } catch (error) {
                    console.error('Autoresponder error:', error);
                }
            }
        }
    });
};

async function processVariables(text, message) {
    let processedText = text;

    // User variables
    processedText = processedText.replace(/{mention:user}/g, `<@${message.author.id}>`);
    processedText = processedText.replace(/{member:username}/g, message.author.username);
    processedText = processedText.replace(/{member:tag}/g, message.author.tag);
    processedText = processedText.replace(/{member:id}/g, message.author.id);

    // Server variables
    processedText = processedText.replace(/{server:name}/g, message.guild.name);
    processedText = processedText.replace(/{server:id}/g, message.guild.id);
    processedText = processedText.replace(/{member:count}/g, message.guild.memberCount.toString());
    processedText = processedText.replace(/{channel:name}/g, message.channel.name);

    return processedText;
}