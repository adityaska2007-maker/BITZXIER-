const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'clapify',
    category: 'fun',
    description: 'Adds 👏 clap 👏 emojis 👏 between 👏 words',
    run: async (client, message, args) => {
        if (!args.length) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`<:cross_mark:1375696099880206346> | Please provide some text to clapify!`)]
            });
        }

        const text = args.join(' ');
        const clapText = clapify(text);

        message.channel.send({
            embeds: [new EmbedBuilder()
                .setColor(client.color)
                .setTitle('👏 Clapified 👏 Text 👏')
                .setDescription(clapText)]
        });
    }
};

// Function to add clap emojis between words
function clapify(text) {
    // Split the text by spaces
    const words = text.split(' ');
    
    // Join the words with the clap emoji
    return words.join(' 👏 ');
}