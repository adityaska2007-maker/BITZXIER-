const { EmbedBuilder } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'giveaway',
    category: 'information',
    description: 'Create an advanced giveaway with custom requirements',
    usage: 'giveaway <duration> <winners> <prize> [requirements]',
    examples: ['giveaway 1d 1 Discord Nitro', 'giveaway 12h 3 Premium Role --role @Member --level 10'],
    run: async (client, message, args) => {
        // Delete the command message
        message.delete().catch(e => console.error('Could not delete giveaway command message:', e));
        if (!message.member.permissions.has('ManageMessages')) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#ff0000')
                    .setAuthor({ name: `${client.emoji.gift || '🎉'} Giveaway System`, iconURL: message.guild.iconURL({ dynamic: true }) })
                    .setDescription(`${client.emoji.cross || '❌'} | You need \`MANAGE_MESSAGES\` permission to use this command.`)
                    .setFooter({ text: '© FLIZER' })]
            });
        }

        const duration = args[0];
        const winners = parseInt(args[1]);
        let prize = '';
        let requirements = {
            roles: [],
            minLevel: 0,
            minMessages: 0
        };

        let inRequirements = false;
        for (let i = 2; i < args.length; i++) {
            if (args[i].startsWith('--')) {
                inRequirements = true;
                switch (args[i]) {
                    case '--role':
                        const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[++i]);
                        if (role) requirements.roles.push(role.id);
                        break;
                    case '--level':
                        requirements.minLevel = parseInt(args[++i]) || 0;
                        break;
                    case '--messages':
                        requirements.minMessages = parseInt(args[++i]) || 0;
                        break;
                }
            } else if (!inRequirements) {
                prize += `${args[i]} `;
            }
        }
        prize = prize.trim();

        if (!duration || !winners || !prize) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#ff0000')
                    .setAuthor({ name: `${client.emoji.info || 'ℹ️'} Command Usage`, iconURL: message.guild.iconURL({ dynamic: true }) })
                    .setDescription(`${client.emoji.dot || '•'} Format: \`giveaway <duration> <winners> <prize>\`\n${client.emoji.dot || '•'} Example: \`giveaway 1d 1 Discord Nitro\`\n${client.emoji.dot || '•'} Requirements (optional):\n  \`--role @Role\`\n  \`--level <number>\`\n  \`--messages <number>\``)
                    .setFooter({ text: '© FLIZER' })]
            });
        }

        const giveawayDuration = ms(duration);
        if (!giveawayDuration) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#ff0000')
                    .setDescription(`${client.emoji.cross || '❌'} | Please provide a valid duration!\n${client.emoji.info || 'ℹ️'} Example: \`1d\`, \`1h\`, \`10m\``)
                    .setFooter({ text: '© FLIZER' })]
            });
        }

        const participants = new Set();
        const endTime = Date.now() + giveawayDuration;

        let requirementsText = '';
        if (requirements.roles.length > 0) {
            requirementsText += `\n${client.emoji.role || '👑'} **Required Roles:** ${requirements.roles.map(r => `<@&${r}>`).join(', ')}`;
        }
        if (requirements.minLevel > 0) {
            requirementsText += `\n${client.emoji.level || '📊'} **Minimum Level:** ${requirements.minLevel}`;
        }
        if (requirements.minMessages > 0) {
            requirementsText += `\n${client.emoji.message || '💬'} **Minimum Messages:** ${requirements.minMessages}`;
        }

        const messageContent = `<a:girl_dance:1362711059374407742> **New Giveaway!** <a:girl_dance:1362711059374407742>`;

        const giveawayEmbed = new EmbedBuilder()

.setTitle(`<a:Gift:1362704453945262221> ${prize} <a:Gift:1362704453945262221>`)            

            .setColor('#ff0000')
            .setDescription(
                ` Ends: <t:${Math.floor(endTime / 1000)}:R>\n` +
                `<:dot:1362705151206359186> Winner: ${winners}\n` +
                `<:dot:1362705151206359186> Hosted by: ${message.author}\n\n` +
                (requirementsText ? `${requirementsText}\n\n` : '') +
                `<:dot:1362705151206359186> React with '<a:giveaway:1362716687895494791>' to participate!`
            )
            .setFooter({ text: `© FLIZER • Started at`, iconURL: client.user.displayAvatarURL() })
            .setTimestamp();

        const giveawayMsg = await message.channel.send({ content: messageContent, embeds: [giveawayEmbed] });
        await giveawayMsg.react('<a:giveaway:1362716687895494791>');

        const collector = giveawayMsg.createReactionCollector({
            filter: (reaction, user) => reaction.emoji.id === '1362716687895494791' && !user.bot,
            time: giveawayDuration
        });

        collector.on('collect', async (reaction, user) => {
            let meetsRequirements = true;
            let failureReason = '';

            if (requirements.roles.length > 0) {
                const member = await message.guild.members.fetch(user.id);
                const hasRole = requirements.roles.some(r => member.roles.cache.has(r));
                if (!hasRole) {
                    meetsRequirements = false;
                    failureReason = 'You do not have the required role(s)!';
                }
            }

            if (!meetsRequirements) {
                reaction.users.remove(user);
                user.send(`${client.emoji.cross || '❌'} | You cannot enter this giveaway: ${failureReason}`).catch(() => {});
            }
        });

        collector.on('end', async () => {
            const reaction = giveawayMsg.reactions.cache.get('1362716687895494791');
            const users = await reaction.users.fetch();
            const participants = users.filter(user => !user.bot).map(u => u.id);

            if (participants.length === 0) {
                const endEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle(`<a:Gift:1362704453945262221> ${prize} <a:Gift:1362704453945262221>`)
                    .setDescription(
                        `<:dot:1362705151206359186> Ended: <t:${Math.floor(Date.now() / 1000)}:R>\n` +
                        `<:dot:1362705151206359186> Winner: No participants\n` +
                        `<:dot:1362705151206359186> Hosted by: ${message.author}`
                    )
                    .setFooter({ text: `© FLIZER • Ended at`, iconURL: client.user.displayAvatarURL() })
                    .setTimestamp();

                return giveawayMsg.edit({ embeds: [endEmbed] });
            }

            const winnerCount = Math.min(winners, participants.length);
            const winnerIds = [];

            for (let i = 0; i < winnerCount; i++) {
                const winner = participants[Math.floor(Math.random() * participants.length)];
                winnerIds.push(winner);
                participants.splice(participants.indexOf(winner), 1);
            }

            const winnerMentions = winnerIds.map(id => `${client.emoji.dot || '•'} <@${id}>`).join('\n');
            const messageContent = `<a:girl_dance:1362711059374407742> **GIVEAWAY ENDED** <a:girl_dance:1362711059374407742>`;
            
            const endEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle(`<a:Gift:1362704453945262221> ${prize} <a:Gift:1362704453945262221>`)
                .setDescription(
                    `<:dot:1362705151206359186> Ended: <t:${Math.floor(Date.now() / 1000)}:R>\n` +
                    `<:dot:1362705151206359186> Hosted by: ${message.author}\n\n` +
                    `<:dot:1362705151206359186> **Winners:**\n${winnerMentions}`
                )
                .setFooter({ text: `© FLIZER • Ended at`, iconURL: client.user.displayAvatarURL() })
                .setTimestamp();

            await giveawayMsg.edit({ content: messageContent, embeds: [endEmbed] });
            
            // Send a simple congratulation message for the winner(s)
            if (winnerIds.length > 0) {
                if (winnerIds.length === 1) {
                    // For a single winner - simple text message
                    const winnerId = winnerIds[0];
                    await message.channel.send(`Congratulations <@${winnerId}> has won the giveaway!`);
                } else {
                    // For multiple winners - simple text message listing all winners
                    const winners = winnerIds.map(id => `<@${id}>`).join(', ');
                    await message.channel.send(`Congratulations ${winners} have won the giveaway!`);
                }
            }
        });
    }
};