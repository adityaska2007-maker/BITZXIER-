const { EmbedBuilder } = require('discord.js')

module.exports = {
    name: 'ascii',
    aliases: ['art', 'text'],
    category: 'fun',
    description: 'Convert text to ASCII art',
    run: async (client, message, args) => {
        if (!args.length) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | Please provide text to convert!`)
                ]
            })
        }

        const text = args.join(' ').toUpperCase()
        if (text.length > 10) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | Text must be 10 characters or less!`)
                ]
            })
        }

        const asciiLetters = {
            'A': '  ▄▀█  \n █▄▄█▄ \n █   █ ',
            'B': ' ███▄  \n █▄▄█▄ \n █▄▄▄█ ',
            'C': '  ▄▄▄▄ \n █     \n  ▀▀▀▀ ',
            'D': ' ███▄  \n █   █ \n █▄▄▄█ ',
            'E': ' █▄▄▄▄ \n █▄▄   \n █▄▄▄▄ ',
            'F': ' █▄▄▄▄ \n █▄▄   \n █     ',
            'G': '  ▄▄▄▄ \n █  ▄█ \n  ▀▀▀█ ',
            'H': ' █   █ \n █▄▄▄█ \n █   █ ',
            'I': ' ▄▄▄▄▄ \n   █   \n ▄▄█▄▄ ',
            'J': ' ▄▄▄▄▄ \n     █ \n ▄▄▄▄█ ',
            'K': ' █  ▄█ \n █▄▀   \n █  ▀█ ',
            'L': ' █     \n █     \n █▄▄▄▄ ',
            'M': ' █▄ ▄█ \n █ █ █ \n █   █ ',
            'N': ' █▄  █ \n █ █ █ \n █  ▄█ ',
            'O': '  ▄▄▄  \n █   █ \n  ▀▀▀  ',
            'P': ' ███▄  \n █▄▄▀  \n █     ',
            'Q': '  ▄▄▄  \n █ ▄ █ \n  ▀▀█▄ ',
            'R': ' ███▄  \n █▄▄▀  \n █  ▀█ ',
            'S': '  ▄▄▄▄ \n  ▀▀▀▄ \n ▄▄▄▄  ',
            'T': ' ▄▄█▄▄ \n   █   \n   █   ',
            'U': ' █   █ \n █   █ \n  ▀▀▀  ',
            'V': ' █   █ \n █   █ \n  ▀▄▀  ',
            'W': ' █   █ \n █ █ █ \n  ▀▄▀  ',
            'X': ' █   █ \n  ▀▄▀  \n █   █ ',
            'Y': ' █   █ \n  ▀▄▀  \n   █   ',
            'Z': ' █▄▄▄▄ \n   ▄▀  \n █▄▄▄▄ ',
            ' ': '       \n       \n       '
        }

        let asciiArt = ''
        for (let i = 0; i < 3; i++) {
            for (let char of text) {
                if (asciiLetters[char]) {
                    asciiArt += asciiLetters[char].split('\n')[i] + ' '
                } else {
                    asciiArt += '       '
                }
            }
            asciiArt += '\n'
        }

        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('🎨 ASCII Art')
            .setDescription(`\`\`\`\n${asciiArt}\`\`\``)
            .setFooter({ text: `Created by ${message.author.tag}` })
            .setTimestamp()

        message.reply({ embeds: [embed] })
    }
}