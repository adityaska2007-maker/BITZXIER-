const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'coinflip',
    aliases: ['flip', 'coin'],
    category: 'fun',
    description: 'Flip a coin or multiple coins with animated results',
    /**
     * @param {import('../../structures/Satxler')} client
     */
    run: async (client, message, args) => {
        // Determine number of coins to flip (default: 1)
        let numFlips = 1;
        let betOption = null;
        
        // Parse number of flips
        if (args.length > 0) {
            const parsed = parseInt(args[0]);
            if (!isNaN(parsed) && parsed > 0 && parsed <= 100) {
                numFlips = parsed;
            } else if (parsed > 100) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | You can only flip up to 100 coins at once!`)]
                });
            }
        }
        
        // Check if user is betting on heads or tails
        if (args.length > 1) {
            const bet = args[1].toLowerCase();
            if (bet === 'heads' || bet === 'h' || bet === 'head') {
                betOption = 'Heads';
            } else if (bet === 'tails' || bet === 't' || bet === 'tail') {
                betOption = 'Tails';
            }
        }
        
        // Create more engaging initial embed for the flip animation
        const loadingEmbed = new EmbedBuilder()
            .setColor('#FFD700') // Gold color for coins
            .setTitle(`${client.emoji.member} Coin Toss ${client.emoji.member}`)
            .setDescription(numFlips === 1 
                ? `${message.author} flips a shiny coin in the air...`
                : `${message.author} tosses ${numFlips} coins into the air...`)
            .setFooter({ text: betOption 
                ? `${message.author.username} is betting on ${betOption}` 
                : 'Waiting for results...' });
            
        const msg = await message.channel.send({ embeds: [loadingEmbed] });
        
        // First animation stage (1.2 seconds)
        setTimeout(() => {
            const firstStageEmbed = new EmbedBuilder()
                .setColor('#FFD700')
                .setTitle(`${client.emoji.time} Coin${numFlips > 1 ? 's' : ''} spinning...`)
                .setDescription(numFlips === 1 
                    ? 'The coin flips through the air, catching the light...'
                    : 'The coins are spinning, glinting in the light...')
                .setFooter({ text: 'Almost there...' });
            
            msg.edit({ embeds: [firstStageEmbed] });
            
            // Final animation stage with results (after another 1.2 seconds)
            setTimeout(() => {
                // Flip the coin(s)
                const results = [];
                let heads = 0;
                let tails = 0;
                
                for (let i = 0; i < numFlips; i++) {
                    // 50/50 chance for heads or tails
                    const result = Math.random() < 0.5 ? 'Heads' : 'Tails';
                    results.push(result);
                    
                    if (result === 'Heads') {
                        heads++;
                    } else {
                        tails++;
                    }
                }
                
                // Choose color based on result
                let resultColor;
                if (numFlips === 1) {
                    resultColor = results[0] === 'Heads' ? '#FFD700' : '#C0C0C0'; // Gold for heads, silver for tails
                } else {
                    resultColor = heads >= tails ? '#FFD700' : '#C0C0C0';
                }
                
                // Create the result embed with more engaging content
                let description;
                let title;
                
                if (numFlips === 1) {
                    // Single coin flip
                    const result = results[0];
                    const emoji = result === 'Heads' ? client.emoji.crown : client.emoji.settings;
                    title = `${emoji} Coin landed on: ${result} ${emoji}`;
                    
                    // More engaging description
                    description = `${client.emoji.member} **${message.author.username}** flipped a coin...\n\n${result === 'Heads' ? '👑' : '⚙️'} It landed on **${result}**!`;
                    
                    // Add bet result if applicable
                    if (betOption) {
                        if (betOption === result) {
                            description += `\n\n${client.emoji.success} You bet on **${betOption}** and **won**!`;
                        } else {
                            description += `\n\n${client.emoji.cross} You bet on **${betOption}** and **lost**!`;
                        }
                    }
                } else {
                    // Multiple coin flips
                    title = `${client.emoji.crown} Coin Flip Results ${client.emoji.settings}`;
                    
                    // Calculate percentages with one decimal point
                    const headsPercent = (heads/numFlips*100).toFixed(1);
                    const tailsPercent = (tails/numFlips*100).toFixed(1);
                    
                    description = `${client.emoji.member} **${message.author.username}** flipped **${numFlips}** coins!\n\n`;
                    description += `**Results:**\n`;
                    description += `👑 **Heads:** ${heads} (${headsPercent}%)\n`;
                    description += `⚙️ **Tails:** ${tails} (${tailsPercent}%)\n`;
                    
                    // Add bet result if applicable
                    if (betOption) {
                        const winCount = betOption === 'Heads' ? heads : tails;
                        const winPercent = betOption === 'Heads' ? headsPercent : tailsPercent;
                        
                        description += `\n**Bet on ${betOption}:**\n`;
                        
                        if (winCount > numFlips/2) {
                            description += `${client.emoji.success} Your bet won with ${winPercent}% ${betOption}!`;
                        } else if (winCount === numFlips/2) {
                            description += `${client.emoji.warning} Your bet resulted in a tie at exactly 50%!`;
                        } else {
                            description += `${client.emoji.cross} Your bet lost with only ${winPercent}% ${betOption}!`;
                        }
                    }
                    
                    // If there are not too many coins, show detailed results
                    if (numFlips <= 15) {
                        const flipsDisplay = results.map((result, index) => {
                            const flipEmoji = result === 'Heads' ? '👑' : '⚙️';
                            return `${flipEmoji} Flip ${index + 1}: **${result}**`;
                        }).join('\n');
                        description += `\n\n**Detailed Results:**\n${flipsDisplay}`;
                    }
                }
                
                const resultEmbed = new EmbedBuilder()
                    .setColor(resultColor)
                    .setTitle(title)
                    .setDescription(description)
                    .setFooter({ text: `Flipped by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
                    .setTimestamp();
                    
                // Edit the original message with the result
                msg.edit({ embeds: [resultEmbed] });
            }, 1200);
        }, 1200);
    }
};