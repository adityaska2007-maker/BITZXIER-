const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'blush',
    category: 'fun',
    description: 'Show embarrassment with a blushing GIF',
    run: async (client, message, args) => {
        try {
            // Get a blush GIF from an anime API
            const response = await axios.get('https://api.waifu.pics/sfw/blush');
            
            let reason = args.join(' ');
            let description;
            
            if (reason) {
                description = `<@${message.author.id}> is blushing because ${reason} 😳`;
            } else {
                description = `<@${message.author.id}> is blushing 😳`;
            }
            
            message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('😳 Blushing')
                    .setDescription(description)
                    .setImage(response.data.url)
                    .setFooter({ text: 'How cute!' })]
            });
        } catch (error) {
            message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${client.emoji.cross} | Failed to blush!`)]
            });
        }
    }
};