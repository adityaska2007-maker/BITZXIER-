const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'bonk',
    category: 'fun',
    description: 'Bonk someone',
    run: async (client, message, args) => {
        try {
            // Get a bonk GIF from an anime API
            const response = await axios.get('https://api.waifu.pics/sfw/bonk');
            
            // Check if user mentioned someone
            const target = message.mentions.users.first();
            let description;
            
            if (target) {
                description = `<@${message.author.id}> bonked <@${target.id}>! Go to horny jail!`;
            } else {
                description = `<@${message.author.id}> bonked the air... (Mention someone next time!)`;
            }
            
            message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('🔨 Bonk')
                    .setDescription(description)
                    .setImage(response.data.url)
                    .setFooter({ text: 'Bonk!' })]
            });
        } catch (error) {
            message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${client.emoji.cross} | Failed to bonk!`)]
            });
        }
    }
};