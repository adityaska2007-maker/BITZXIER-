const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'cuddle',
    category: 'fun',
    description: 'Cuddle with someone',
    run: async (client, message, args) => {
        try {
            // Get a cuddle GIF from an anime API
            const response = await axios.get('https://api.waifu.pics/sfw/cuddle');
            
            // Check if user mentioned someone
            const target = message.mentions.users.first();
            let description;
            
            if (target) {
                description = `<@${message.author.id}> is cuddling with <@${target.id}> 💕`;
            } else {
                description = `<@${message.author.id}> is cuddling a pillow... (Mention someone next time!)`;
            }
            
            message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('🤗 Cuddle')
                    .setDescription(description)
                    .setImage(response.data.url)
                    .setFooter({ text: 'So comfy!' })]
            });
        } catch (error) {
            message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${client.emoji.cross} | Failed to cuddle!`)]
            });
        }
    }
};