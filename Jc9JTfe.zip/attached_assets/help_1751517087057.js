const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    name: 'help',
    aliases: ['h'],
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        const prefix = message.guild?.prefix || '&'; // Default prefix if not set

        // Create a StringSelectMenuBuilder
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('categorySelect')
            .setPlaceholder('Levix Get Started!')
            .addOptions([
                {
                    label: 'Home',
                    value: 'home',
                    description: 'Return to the help menu',
                    emoji: '<:x_home:1360325679513731492>'
                },
                {
                    label: 'All Commands',
                    value: 'all',
                    description: 'Show all commands',
                    emoji: '<:x_folder1:1360325666817703996>'
                },
                {
                    label: 'AntiNuke',
                    value: 'antinuke',
                    description: 'Commands related to AntiNuke',
                    emoji: '<:x_automod:1360325662484725994>'
                },
                {
                    label: 'Moderation',
                    value: 'mod',
                    description: 'Commands related to Moderation',
                    emoji: '<:x_mod:1360325693992337660>'
                },
                {
                    label: 'Utility',
                    value: 'info',
                    description: 'Utility commands',
                    emoji: '<:x_tools:1360325677458391302>'
                },
                {
                    label: 'Welcomer',
                    value: 'welcomer',
                    description: 'Commands for Welcomer',
                    emoji: '<:x_member:1360325688816832753>'
                },
                {
                    label: 'Voice',
                    value: 'voice',
                    description: 'Commands related to Voice',
                    emoji: '<:x_music:1360325683519422635>'
                },
                {
                    label: 'Automod',
                    value: 'automod',
                    description: 'Commands for Automod',
                    emoji: '<:x_partner:1360325700220883126>'
                },
                {
                    label: 'Custom Role',
                    value: 'customrole',
                    description: 'Commands for Custom Roles',
                    emoji: '<:x_setting:1360325703060426913>'
                },
                {
                    label: 'Logging',
                    value: 'logging',
                    description: 'Commands for Logging',
                    emoji: '<:x_folder2:1360325672517763163>'
                },
                {
                    label: 'Autoresponder',
                    value: 'autoresponder',
                    description: 'Commands for Autoresponder',
                    emoji: '<:x_partner:1360325700220883126>'
                },
                {
                    label: 'Giveaway',
                    value: 'give',
                    description: 'Commands for Giveaway',
                    emoji: '<:x_giveawaya:1360325657313411116>'
                },
                {
                    label: 'Fun',
                    value: 'fun',
                    description: 'Fun commands',
                    emoji: '<:x_games:1360325669006999783>'
                }
            ]);

        // Create action row with buttons
        const actionRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel('Invite Me')
                    .setStyle('LINK')
                    .setURL('https://discord.com/oauth2/authorize?client_id=1218226477938511872&scope=bot%20applications.commands&permissions=8'),
                new ButtonBuilder()
                    .setLabel('Support')
                    .setStyle('LINK')
                    .setURL('https://discord.gg/4ZKhqpFze8'),
                new ButtonBuilder()
                    .setLabel('Home')
                    .setCustomId('homeButton')
                    .setStyle('SECONDARY')
            );

        // Embed message
        const embed = new EmbedBuilder()
            .setColor(client.color) // Red color for the embed
            .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true }))
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .setDescription(
                `Hello! I'm Levix, your server security bot with powerful Antinuke features.\n\nPrefix for this server \`${prefix}\`\nTotal Commands: \`${client.commands.size}\`\n Type \`${prefix}antinuke enable\``
            )
            .addField(
                '__Main Modules__',
                `<:x_automod:1360325662484725994> **AntiNuke**\n<:x_mod:1360325693992337660> **Moderation**\n<:x_folder2:1360325672517763163> **Logging**\n<:x_tools:1360325677458391302> **Utility**\n<:x_member:1360325688816832753> **Welcomer**\n<:x_games:1360325669006999783> **Fun**`,
                true
            )
            .addField(
                '__Extra Modules__',
                `<:x_music:1360325683519422635> **Voice**\n<:x_setting:1360325703060426913> **Custom Role**\n<:x_defen:1360325661243212099> **Automod**\n<:x_partner:1360325700220883126> **Autoresponder**\n<:x_giveawaya:1360325657313411116> **Giveaway**`,
                true
            )
            .addField(
                '**Links**',
                `[Support](https://discord.gg/mrontop) **|** [Invite Me](https://discord.com/oauth2/authorize?client_id=1218226477938511872&scope=bot%20applications.commands&permissions=8)`,
                false
            )
            .setFooter('Developed By Warrior xD', client.user.displayAvatarURL());

        // Send the initial help message
        const helpMessage = await message.channel.send({
            embeds: [embed],
            components: [actionRow, new ActionRowBuilder().addComponents(selectMenu)]
        });

        // Component collector for interactions
        const collector = helpMessage.createMessageComponentCollector({
            filter: (i) => i.user.id === message.author.id,
            time: 300000 // 5 minutes
        });

        collector.on('collect', async (i) => {
            if (i.customId === 'homeButton' || i.values?.[0] === 'home') {
                await i.deferUpdate();
                return helpMessage.edit({
                    embeds: [embed],
                    components: [actionRow, new ActionRowBuilder().addComponents(selectMenu)]
                });
            }

            await i.deferUpdate();

            const category = i.values[0];
            let commands = [];

            if (category === 'all') {
                commands = client.commands.map((x) => `\`${x.name}\``);
            } else {
                const categoryMap = {
                    antinuke: 'security',
                    mod: 'mod',
                    info: 'info',
                    welcomer: 'welcomer',
                    voice: 'voice',
                    automod: 'automod',
                    customrole: 'customrole',
                    logging: 'logging',
                    autoresponder: 'autoresponder',
                    giveaway: 'giveaway',
                    fun: 'fun',
                    ticket: 'ticket'
                };
                const filteredCategory = categoryMap[category];
                commands = client.commands
                    .filter((x) => x.category === filteredCategory)
                    .map((x) => `\`${x.name}\``);
            }

            const categoryEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setAuthor(client.user.username, client.user.displayAvatarURL())
                .setDescription(
                    `**${category.charAt(0).toUpperCase() + category.slice(1)} Commands**\n${commands.join(', ')}`
                );

            helpMessage.edit({
                embeds: [categoryEmbed],
                components: [actionRow, new ActionRowBuilder().addComponents(selectMenu)]
            });
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                helpMessage.edit({ components: [] });
            }
        });
    }
};