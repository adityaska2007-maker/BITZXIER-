const { EmbedBuilder } = require('discord.js')

module.exports = {
    name: 'choose',
    aliases: ['pick', 'decide'],
    category: 'fun',
    description: 'Let the bot choose between options',
    run: async (client, message, args) => {
        if (!args.length) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | Usage: \`choose option1 | option2 | option3\``)
                ]
            })
        }

        const options = args.join(' ').split('|').map(option => option.trim()).filter(option => option.length > 0)
        
        if (options.length < 2) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | Please provide at least 2 options separated by |`)
                ]
            })
        }

        const choice = options[Math.floor(Math.random() * options.length)]

        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('🎯 Decision Maker')
            .addFields([
                { name: '📝 Options', value: options.map((opt, i) => `${i + 1}. ${opt}`).join('\n'), inline: false },
                { name: '✅ My Choice', value: `**${choice}**`, inline: false }
            ])
            .setFooter({ text: `Decision made for ${message.author.tag}` })
            .setTimestamp()

        message.reply({ embeds: [embed] })
    }
}