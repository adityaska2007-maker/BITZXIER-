const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'catfact',
    category: 'fun',
    description: 'Get a random cat fact',
    run: async (client, message, args) => {
        try {
            // Create initial embed
            const loadingEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setDescription('Fetching a cat fact...');
                
            const msg = await message.channel.send({ embeds: [loadingEmbed] });
            
            // Fetch a random cat fact from the API
            const response = await axios.get('https://catfact.ninja/fact');
            const fact = response.data.fact;
            
            // Create the cat fact embed
            const factEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('🐱 Random Cat Fact 🐱')
                .setDescription(fact)
                .setFooter({ text: 'Cat facts - because cats rule the internet!' })
                .setTimestamp();
                
            // Try to get a cat image to accompany the fact
            try {
                const catResponse = await axios.get('https://api.thecatapi.com/v1/images/search');
                const catImageUrl = catResponse.data[0].url;
                factEmbed.setImage(catImageUrl);
            } catch (imageError) {
                // If cat image fetch fails, just continue without an image
                console.error('Error fetching cat image:', imageError);
            }
            
            // Update the message with the cat fact
            msg.edit({ embeds: [factEmbed] });
            
        } catch (error) {
            console.error('Error fetching cat fact:', error);
            
            // Backup cat facts if API fails
            const backupCatFacts = [
                "Cats make about 100 different sounds. Dogs make only about 10.",
                "A house cat's genome is 95.6% tiger.",
                "Cats are believed to be the only mammals who don't taste sweetness.",
                "Cats sleep for 70% of their lives.",
                "A cat's nose pad is ridged with a unique pattern, just like a human fingerprint.",
                "Cats have 32 muscles in each ear, allowing them to move their ears independently.",
                "A group of cats is called a clowder.",
                "Cats can jump up to six times their length.",
                "A cat's purr vibrates at a frequency of 25 to 150 hertz, which is the same frequency that promotes healing.",
                "Cats have 230 bones, while humans only have 206.",
                "A cat's heart beats at 110-140 beats per minute, almost twice as fast as a human heart.",
                "Cats can't see directly under their noses.",
                "In Ancient Egypt, when a family cat died, family members would shave off their eyebrows as a sign of mourning.",
                "The world's richest cat, Blackie, inherited £7 million when his owner passed away.",
                "Cats don't have sweat glands over their bodies like humans do. Instead, they sweat only through their paw pads."
            ];
            
            // Select a random backup cat fact
            const randomFact = backupCatFacts[Math.floor(Math.random() * backupCatFacts.length)];
            
            // Create the cat fact embed with backup fact
            const factEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('🐱 Random Cat Fact 🐱')
                .setDescription(randomFact)
                .setFooter({ text: 'Cat facts - because cats rule the internet!' })
                .setTimestamp();
                
            // Send the cat fact embed
            message.channel.send({ embeds: [factEmbed] });
        }
    }
};