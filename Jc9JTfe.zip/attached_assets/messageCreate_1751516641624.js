const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    PermissionsBitField,
    Collection,
    WebhookClient
} = require('discord.js')

module.exports = async (client) => {
    client.on('messageCreate', async (message) => {
        if (message.author.bot || !message.guild) return;

        // Bot ping response
        if (message.content === `<@${client.user.id}>` || message.content === `<@!${client.user.id}>`) {
            try {
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setLabel('Invite Me')
                        .setStyle('LINK')
                        .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`),
                    new ButtonBuilder()
                        .setLabel('Support')
                        .setStyle('LINK')
                        .setURL('https://discord.gg/4ZKhqpFze8'),
                    new ButtonBuilder()
                        .setLabel('Website')
                        .setStyle('LINK')
                        .setURL('https://levix.dev')
                );

                // Get the correct prefix for this server
                await client.util.setPrefix(message, client).catch(() => {});
                let prefix = message.guild.prefix || 'L!';

                const embed = new EmbedBuilder()
                    .setColor(client.color || '#00FFFF')
                    .setAuthor("I'm Magatron", client.user.displayAvatarURL({ dynamic: true }))
                    .setDescription(`Hey [${message.author.username}](https://discord.com/users/${message.author.id})\nPrefix For This Server Is \`${prefix}\`\n\nUnlock More Details With \`${prefix}help\`.`)
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .setFooter("Magatron Is Love", client.user.displayAvatarURL({ dynamic: true }));

                return message.channel.send({
                    embeds: [embed],
                    components: [row]
                });
            } catch (error) {
                console.error('Error sending ping response:', error);
                return message.channel.send('Hey! I\'m Magatron and I\'m online!');
            }
        }

        // Handle AutoReact functionality
        try {
            const autoreacts = await client.db.get(`${message.guild.id}_autoreacts`);
            if (autoreacts && Object.keys(autoreacts).length > 0) {
                const messageContent = message.content.toLowerCase();
                for (const [trigger, reaction] of Object.entries(autoreacts)) {
                    if (messageContent.includes(trigger.toLowerCase())) {
                        try {
                            await message.react(reaction);
                        } catch (error) {
                            // Silently fail if reaction is invalid or bot lacks permissions
                        }
                        break; // Only react with the first matching trigger
                    }
                }
            }
        } catch (error) {
            // Silently handle autoreact errors
        }

        try {
            let check = await client.util.BlacklistCheck(message?.guild)
            if(check) return  
            let uprem = await client.db.get(`uprem_${message.author.id}`)
            let upremend = await client.db.get(`upremend_${message.author.id}`)
            let sprem = await client.db.get(`sprem_${message.guild.id}`)
            let spremend = await client.db.get(`spremend_${message.guild.id}`)

            // Premium handling (simplified to avoid complexity)
            let scot = 0
            let slink = 'https://discord.gg/mrontop'

            // Fallback to default prefix if database isn't working
            await client.util.setPrefix(message, client).catch(() => {});
            let prefix = message.guild.prefix || 'L!';

            // Get noprefix users and ensure it's an array
            let noprefixUsers = client.noprefix || []
            if (!Array.isArray(noprefixUsers)) {
                noprefixUsers = []
            }

            // Check if user has noprefix permissions
            const hasNoPrefix = noprefixUsers.includes(message.author.id);

            // Determine if this is a valid command message
            const startsWithPrefix = message.content.startsWith(prefix);

            // If user doesn't have noprefix and message doesn't start with prefix, return
            if (!hasNoPrefix && !startsWithPrefix) return;

            // Parse arguments based on whether prefix is used
            const args = startsWithPrefix
                ? message.content.slice(prefix.length).trim().split(/ +/)
                : message.content.trim().split(/ +/)

            const cmd = args.shift().toLowerCase()
            const command = client.commands.get(cmd.toLowerCase()) || 
                          client.commands.find((c) => c.aliases?.includes(cmd.toLowerCase()))

            if (command && command.premium) {
                if (!'1338088204431130654'.includes(message.author.id) && !uprem && !sprem) {
                    const premiumRow = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel('Invite')
                            .setStyle('LINK')
                            .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`),
                        new ButtonBuilder()
                            .setLabel('Premium')
                            .setStyle('LINK')
                            .setURL('https://discord.gg/4ZKhqpFze8')
                    )
                    const embeds = new EmbedBuilder()
                        .setDescription('You Just Discovered a Premium Command Join Our Support Server To Buy Premium')
                        .setColor(client.color)

                    return message.channel.send({
                        embeds: [embeds],
                        components: [premiumRow]
                    })
                }
            }

            // Ignore channel/role check
            const ignore = (await client.db?.get(`ignore_${message.guild.id}`)) ?? { channel: [], role: [] }
            if (ignore.channel.includes(message.channel.id) && 
                !message.member.roles.cache.some((role) => ignore.role.includes(role.id))) {
                return await message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color)
                            .setDescription(`Apologies, I can't execute commands in this channel as it's currently on my ignore list. Please consider selecting a different channel or contacting the server administrator for support..`)
                    ]
                }).then((x) => {
                    setTimeout(() => x.delete().catch(() => {}), 3000)
                })
            }

            if (!command) return

            // Cooldown handling
            if (command.cooldown) {
                const timestamps = client.cooldowns
                const cooldownAmount = (command.cooldown || 3) * 1000

                if (timestamps.has(message.author.id)) {
                    const expirationTime = timestamps.get(message.author.id) + cooldownAmount
                    if (Date.now() < expirationTime) {
                        const timeLeft = (expirationTime - Date.now()) / 1000
                        return message.channel.send({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor(client.color)
                                    .setDescription(`Please wait, this command is on cooldown for \`${timeLeft.toFixed(1)}s\``)
                            ]
                        }).then((msg) => {
                            setTimeout(() => msg.delete().catch((e) => {}), 5000)
                        })
                    }
                }
                timestamps.set(message.author.id, Date.now())
                setTimeout(() => timestamps.delete(message.author.id), cooldownAmount)
            }

            await command.run(client, message, args)

            // Command logging
            if (command && command.run) {
                const weboo = new WebhookClient({
                    url: `https://discord.com/api/webhooks/1324704506121945190/jpToKOwTfFeTLMVF64Z45iRqMQE1GzjPXFWwC_wHvcbcqggcsOnsbZl2mBpLZ885KH0z`
                })
                const commandlog = new EmbedBuilder()
                    .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true }))
                    .setColor(client.color)
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .setTimestamp()
                    .setDescription(
                        `Command Ran In : \`${message.guild.name} | ${message.guild.id}\`\n Command Ran In Channel : \`${message.channel.name} | ${message.channel.id}\`\n Command Name : \`${command.name}\`\n Command Executor : \`${message.author.tag} | ${message.author.id}\`\n Command Content : \`${message.content}\``
                    )
                weboo.send({ embeds: [commandlog] }).catch(() => {})
            }
        } catch (err) {
            console.error('MessageCreate error:', err)
            if (err.code === 429) {
                await client.util.handleRateLimit()
            }
            return
        }
    })
}