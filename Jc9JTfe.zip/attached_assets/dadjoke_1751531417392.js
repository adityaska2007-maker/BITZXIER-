const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'dadjoke',
    category: 'fun',
    description: 'Get a random dad joke',
    run: async (client, message, args) => {
        try {
            // Create initial embed
            const loadingEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setDescription('Fetching a dad joke...');
                
            const msg = await message.channel.send({ embeds: [loadingEmbed] });
            
            // Fetch a random dad joke from the API
            const response = await axios.get('https://icanhazdadjoke.com/', {
                headers: {
                    'Accept': 'application/json'
                }
            });
            
            const joke = response.data.joke;
            
            // Create the joke embed
            const jokeEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('👨 Dad Joke 👨')
                .setDescription(joke)
                .setFooter({ text: '*groans internally*' })
                .setTimestamp();
                
            // Update the message with the joke
            msg.edit({ embeds: [jokeEmbed] });
            
        } catch (error) {
            console.error('Error fetching dad joke:', error);
            
            // Use a backup dad joke if API fails
            const backupDadJokes = [
                "I'm reading a book on anti-gravity. It's impossible to put down!",
                "Did you hear about the restaurant on the moon? Great food, no atmosphere.",
                "What do you call a fake noodle? An impasta!",
                "How do you organize a space party? You planet!",
                "I would avoid the sushi if it's not fresh. It's a little fishy.",
                "Want to hear a joke about construction? I'm still working on it.",
                "I used to be a baker, but I couldn't make enough dough.",
                "A ham sandwich walks into a bar and orders a beer. The bartender says, 'Sorry, we don't serve food here.'",
                "Why do seagulls fly over the sea? Because if they flew over the bay, they'd be bagels!",
                "I wouldn't buy anything with velcro. It's a total rip-off.",
                "What's the best time to go to the dentist? Tooth-hurty!",
                "I'm on a seafood diet. I see food and I eat it!",
                "Why don't eggs tell jokes? They'd crack each other up.",
                "Did you hear about the guy who invented Lifesavers? They say he made a mint.",
                "I've got a joke about paper, but it's tearable."
            ];
            
            // Select a random backup joke
            const randomJoke = backupDadJokes[Math.floor(Math.random() * backupDadJokes.length)];
            
            // Create the joke embed with backup joke
            const jokeEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('👨 Dad Joke 👨')
                .setDescription(randomJoke)
                .setFooter({ text: '*groans internally*' })
                .setTimestamp();
                
            // Send the joke embed
            message.channel.send({ embeds: [jokeEmbed] });
        }
    }
};