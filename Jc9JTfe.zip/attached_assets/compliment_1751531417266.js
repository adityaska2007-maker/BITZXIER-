const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'compliment',
    category: 'fun',
    description: 'Get a random compliment or compliment someone',
    run: async (client, message, args) => {
        // Check if a target was specified
        const target = message.mentions.users.first() || message.author;
        
        try {
            // Create initial embed
            const loadingEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setDescription('Generating a lovely compliment...');
                
            const msg = await message.channel.send({ embeds: [loadingEmbed] });
            
            // Fetch a random compliment from the API
            const response = await axios.get('https://complimentr.com/api');
            let compliment = response.data.compliment;
            
            // Capitalize the first letter and ensure it ends with punctuation
            compliment = compliment.charAt(0).toUpperCase() + compliment.slice(1);
            if (!compliment.endsWith('.') && !compliment.endsWith('!')) {
                compliment += '.';
            }
            
            // Create a personalized message based on who the command is directed to
            let personalizedMessage;
            if (target.id === message.author.id) {
                personalizedMessage = `Hey ${target}, ${compliment}`;
            } else {
                personalizedMessage = `Hey ${target}, ${compliment}`;
            }
            
            // Create the compliment embed
            const complimentEmbed = new EmbedBuilder()
                .setColor('#ff66cc')
                .setTitle('✨ Compliment ✨')
                .setDescription(personalizedMessage)
                .setThumbnail(target.displayAvatarURL({ dynamic: true }))
                .setFooter({ text: `Requested by ${message.author.tag}` })
                .setTimestamp();
                
            // Update the message with the compliment
            msg.edit({ embeds: [complimentEmbed] });
            
        } catch (error) {
            console.error('Error fetching compliment:', error);
            
            // Backup compliments if API fails
            const backupCompliments = [
                "Your smile is contagious.",
                "You look great today.",
                "You're a smart cookie.",
                "You have the best laugh.",
                "I appreciate your optimism.",
                "You're an awesome friend.",
                "You have the courage of your convictions.",
                "You're like sunshine on a rainy day.",
                "You bring out the best in other people.",
                "You're a great listener.",
                "You have a good head on your shoulders.",
                "You have the best ideas.",
                "You're one of a kind.",
                "You're so thoughtful.",
                "Your creative potential seems limitless.",
                "Your perspective is refreshing.",
                "I'm inspired by you.",
                "You deserve a hug right now.",
                "You should be proud of yourself.",
                "You're more helpful than you realize."
            ];
            
            // Select a random backup compliment
            const randomCompliment = backupCompliments[Math.floor(Math.random() * backupCompliments.length)];
            
            // Create a personalized message based on who the command is directed to
            let personalizedMessage;
            if (target.id === message.author.id) {
                personalizedMessage = `Hey ${target}, ${randomCompliment}`;
            } else {
                personalizedMessage = `Hey ${target}, ${randomCompliment}`;
            }
            
            // Create the compliment embed with backup compliment
            const complimentEmbed = new EmbedBuilder()
                .setColor('#ff66cc')
                .setTitle('✨ Compliment ✨')
                .setDescription(personalizedMessage)
                .setThumbnail(target.displayAvatarURL({ dynamic: true }))
                .setFooter({ text: `Requested by ${message.author.tag}` })
                .setTimestamp();
                
            // Send the compliment embed
            message.channel.send({ embeds: [complimentEmbed] });
        }
    }
};