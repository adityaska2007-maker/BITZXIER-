const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'cryaboutit',
    category: 'fun',
    description: 'Tell someone to cry about it',
    run: async (client, message, args) => {
        // Check if a target was specified
        if (!args.length) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${client.emoji.cross} | Please mention someone to tell them to cry about it!`)]
            });
        }
        
        // Get the target (mentioned user)
        const target = message.mentions.users.first();
        if (!target) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${client.emoji.cross} | Please mention a valid user!`)]
            });
        }
        
        // Collection of cry GIFs
        const cryGifs = [
            'https://media.tenor.com/b_k6OmyLRlIAAAAC/cry-about-it-cry.gif',
            'https://media.tenor.com/UmkxHqyBZJ4AAAAC/shaquille-o-neal-shimmy.gif',
            'https://media.tenor.com/yEI0XfEQSncAAAAC/cat-crying-meme.gif',
            'https://media.tenor.com/JiDVoZ5V2GIAAAAC/crying-spongebob.gif',
            'https://media.tenor.com/8kYfwV-m1jYAAAAC/kid-crying.gif'
        ];
        
        // Randomly select a GIF
        const randomGif = cryGifs[Math.floor(Math.random() * cryGifs.length)];
        
        // Create and send the embed
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('😭 Cry About It 😭')
            .setDescription(`${message.author} tells ${target} to cry about it!`)
            .setImage(randomGif)
            .setFooter({ text: 'Need a tissue?' });
            
        message.channel.send({ embeds: [embed] });
    }
};