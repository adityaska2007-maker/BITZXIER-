const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'cry',
    category: 'fun',
    description: 'Express sadness with a crying GIF',
    run: async (client, message, args) => {
        try {
            // Get a cry GIF from an anime API
            const response = await axios.get('https://api.waifu.pics/sfw/cry');
            
            let reason = args.join(' ');
            let description;
            
            if (reason) {
                description = `<@${message.author.id}> is crying because ${reason} 😢`;
            } else {
                description = `<@${message.author.id}> is crying 😢`;
            }
            
            message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('😭 Crying')
                    .setDescription(description)
                    .setImage(response.data.url)
                    .setFooter({ text: 'There, there...' })]
            });
        } catch (error) {
            message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${client.emoji.cross} | Failed to cry!`)]
            });
        }
    }
};