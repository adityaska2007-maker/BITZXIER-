const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'battlesim',
    aliases: ['battle', 'fight'],
    category: 'fun',
    description: 'Simulate an epic battle between two users',
    run: async (client, message, args) => {
        // Delete command message
        message.delete().catch(e => {});
        
        // Check if there's a mentioned user
        if (!message.mentions.members.first()) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${client.emoji.cross || '❌'} You need to mention someone to battle with!`)]
            });
        }
        
        // Get the two fighters
        const fighter1 = message.member;
        const fighter2 = message.mentions.members.first();
        
        // Check if user is trying to battle themselves
        if (fighter1.id === fighter2.id) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${client.emoji.cross || '❌'} You can't battle yourself! That's just hitting yourself...`)]
            });
        }
        
        // Generate stats for each fighter (1-100)
        const generateStats = () => {
            return {
                attack: Math.floor(Math.random() * 50) + 50,
                defense: Math.floor(Math.random() * 50) + 50,
                speed: Math.floor(Math.random() * 50) + 50,
                health: Math.floor(Math.random() * 50) + 150 // 150-200 health
            };
        };
        
        const fighter1Stats = generateStats();
        const fighter2Stats = generateStats();
        
        // List of possible moves with damage multipliers
        const moves = [
            { name: "Quick Attack", damageMultiplier: 0.8, description: "A swift strike that's hard to dodge" },
            { name: "Heavy Blow", damageMultiplier: 1.2, description: "A powerful but slower attack" },
            { name: "Defensive Stance", damageMultiplier: 0.3, description: "Reduces damage but provides a strong defense" },
            { name: "Charged Strike", damageMultiplier: 1.5, description: "Takes time to charge but delivers massive damage" },
            { name: "Counter Attack", damageMultiplier: 1.0, description: "Returns damage to the attacker" },
            { name: "Special Move", damageMultiplier: 2.0, description: "A rare and devastating signature attack" }
        ];
        
        // Simulate the battle
        const simulateBattle = () => {
            // Clone stats to manipulate during battle
            const stats1 = { ...fighter1Stats };
            const stats2 = { ...fighter2Stats };
            
            // Battle log
            const battleLog = [];
            
            // Determine who goes first based on speed
            let firstAttacker, secondAttacker, firstStats, secondStats;
            if (stats1.speed >= stats2.speed) {
                firstAttacker = fighter1;
                secondAttacker = fighter2;
                firstStats = stats1;
                secondStats = stats2;
            } else {
                firstAttacker = fighter2;
                secondAttacker = fighter1;
                firstStats = stats2;
                secondStats = stats1;
            }
            
            battleLog.push(`${firstAttacker.displayName} makes the first move due to superior speed!`);
            
            // Battle rounds (max 10 rounds)
            let round = 1;
            let specialMoveAvailable1 = true;
            let specialMoveAvailable2 = true;
            
            while (stats1.health > 0 && stats2.health > 0 && round <= 10) {
                battleLog.push(`\n**Round ${round}:**`);
                
                // First attacker's turn
                const move1 = selectMove(specialMoveAvailable1);
                if (move1.name === "Special Move") specialMoveAvailable1 = false;
                
                const damage1 = calculateDamage(firstStats.attack, secondStats.defense, move1.damageMultiplier);
                secondStats.health -= damage1;
                
                battleLog.push(`${firstAttacker.displayName} uses ${move1.name} for ${damage1} damage!`);
                if (secondStats.health <= 0) {
                    battleLog.push(`${secondAttacker.displayName} has been defeated!`);
                    break;
                }
                
                // Second attacker's turn
                const move2 = selectMove(specialMoveAvailable2);
                if (move2.name === "Special Move") specialMoveAvailable2 = false;
                
                const damage2 = calculateDamage(secondStats.attack, firstStats.defense, move2.damageMultiplier);
                firstStats.health -= damage2;
                
                battleLog.push(`${secondAttacker.displayName} uses ${move2.name} for ${damage2} damage!`);
                if (firstStats.health <= 0) {
                    battleLog.push(`${firstAttacker.displayName} has been defeated!`);
                    break;
                }
                
                // Status update
                battleLog.push(`Health: ${firstAttacker.displayName} (${Math.max(0, firstStats.health)}) - ${secondAttacker.displayName} (${Math.max(0, secondStats.health)})`);
                
                round++;
            }
            
            // Determine winner or draw
            let winner;
            if (stats1.health <= 0 && stats2.health <= 0) {
                battleLog.push("\n**Result: DRAW!** Both fighters collapsed at the same time!");
                winner = null;
            } else if (stats1.health <= 0) {
                battleLog.push(`\n**Result: ${fighter2.displayName} WINS!**`);
                winner = fighter2;
            } else if (stats2.health <= 0) {
                battleLog.push(`\n**Result: ${fighter1.displayName} WINS!**`);
                winner = fighter1;
            } else {
                // If we reached max rounds with no knockout
                if (stats1.health > stats2.health) {
                    battleLog.push(`\n**Result: ${fighter1.displayName} WINS by higher remaining health!**`);
                    winner = fighter1;
                } else if (stats2.health > stats1.health) {
                    battleLog.push(`\n**Result: ${fighter2.displayName} WINS by higher remaining health!**`);
                    winner = fighter2;
                } else {
                    battleLog.push("\n**Result: DRAW!** Both fighters are evenly matched!");
                    winner = null;
                }
            }
            
            return { log: battleLog.join('\n'), winner: winner, remainingHealth1: Math.max(0, stats1.health), remainingHealth2: Math.max(0, stats2.health) };
        };
        
        // Helper function to select a move
        function selectMove(specialAvailable) {
            if (specialAvailable && Math.random() < 0.15) {
                // 15% chance to use special move if available
                return moves[5]; // Special Move
            } else {
                // Otherwise select from regular moves (0-4)
                return moves[Math.floor(Math.random() * 5)];
            }
        }
        
        // Helper function to calculate damage
        function calculateDamage(attack, defense, multiplier) {
            const baseDamage = (attack * multiplier) - (defense * 0.5);
            const variation = baseDamage * 0.2; // 20% variation
            const finalDamage = Math.floor(baseDamage + (Math.random() * variation * 2) - variation);
            return Math.max(1, finalDamage); // Minimum 1 damage
        }
        
        // Run the battle simulation
        const battleResult = simulateBattle();
        
        // Create the battle announcement embed
        const announcementEmbed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle(`${client.emoji.vs || '⚔️'} EPIC BATTLE SIMULATION ${client.emoji.vs || '⚔️'}`)
            .setDescription(`**${fighter1.displayName}** has challenged **${fighter2.displayName}** to a battle!`)
            .addField(`${fighter1.displayName}'s Stats`, 
                `Attack: ${fighter1Stats.attack}\nDefense: ${fighter1Stats.defense}\nSpeed: ${fighter1Stats.speed}\nHealth: ${fighter1Stats.health}`, true)
            .addField(`${fighter2.displayName}'s Stats`, 
                `Attack: ${fighter2Stats.attack}\nDefense: ${fighter2Stats.defense}\nSpeed: ${fighter2Stats.speed}\nHealth: ${fighter2Stats.health}`, true)
            .setFooter({ 
                text: `Battle simulator v1.0 • Preparing battle sequence...`,
                iconURL: message.author.displayAvatarURL({ dynamic: true }) 
            });
            
        // Send the announcement and then start the battle
        const sentMessage = await message.channel.send({ embeds: [announcementEmbed] });
        
        // After 3 seconds, update with battle results
        setTimeout(() => {
            const resultEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle(`${client.emoji.vs || '⚔️'} BATTLE RESULTS ${client.emoji.vs || '⚔️'}`)
                .setDescription(battleResult.log)
                .setFooter({ 
                    text: `Battle requested by ${message.author.tag} • Type ${message.guild.prefix || '!'}battle @user to start another fight`,
                    iconURL: message.author.displayAvatarURL({ dynamic: true }) 
                })
                .setTimestamp();
                
            // Add winner highlight if there is one
            if (battleResult.winner) {
                resultEmbed.addField('Champion', `${client.emoji.crown || '👑'} **${battleResult.winner.displayName}** is victorious!`);
            }
            
            sentMessage.edit({ embeds: [resultEmbed] }).catch(e => {});
        }, 3000);
    }
};