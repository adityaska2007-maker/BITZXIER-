const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'advice',
    category: 'fun',
    description: 'Get random life advice',
    run: async (client, message, args) => {
        try {
            // Create initial embed
            const loadingEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setDescription('Searching for wisdom...');
                
            const msg = await message.channel.send({ embeds: [loadingEmbed] });
            
            // Fetch random advice from the API
            const response = await axios.get('https://api.adviceslip.com/advice');
            const advice = JSON.parse(response.data).slip.advice;
            
            // Create the advice embed
            const adviceEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('💭 Random Advice 💭')
                .setDescription(`"${advice}"`)
                .setFooter({ text: 'Take it or leave it!' })
                .setTimestamp();
                
            // Update the message with the advice
            msg.edit({ embeds: [adviceEmbed] });
            
        } catch (error) {
            console.error('Error fetching advice:', error);
            
            // Backup advice if API fails
            const backupAdvice = [
                "Be yourself; everyone else is already taken.",
                "Don't worry about failures, worry about the chances you miss when you don't even try.",
                "The only way to do great work is to love what you do.",
                "If you're going through hell, keep going.",
                "Life is 10% what happens to us and 90% how we react to it.",
                "Success is walking from failure to failure with no loss of enthusiasm.",
                "In three words I can sum up everything I've learned about life: it goes on.",
                "The best time to plant a tree was 20 years ago. The second best time is now.",
                "Happiness is not something ready-made. It comes from your own actions.",
                "Don't count the days, make the days count.",
                "You miss 100% of the shots you don't take.",
                "The only limit to our realization of tomorrow is our doubts of today.",
                "If you want to live a happy life, tie it to a goal, not to people or things.",
                "The purpose of our lives is to be happy.",
                "The journey of a thousand miles begins with one step."
            ];
            
            // Select a random backup advice
            const randomAdvice = backupAdvice[Math.floor(Math.random() * backupAdvice.length)];
            
            // Create the advice embed with backup advice
            const adviceEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('💭 Random Advice 💭')
                .setDescription(`"${randomAdvice}"`)
                .setFooter({ text: 'Take it or leave it!' })
                .setTimestamp();
                
            // Send the advice embed
            message.channel.send({ embeds: [adviceEmbed] });
        }
    }
};