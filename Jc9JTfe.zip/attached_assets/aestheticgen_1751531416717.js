const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'aestheticgen',
    aliases: ['aesthetic', 'vibe'],
    category: 'fun',
    description: 'Generate a random aesthetic for yourself or another user',
    run: async (client, message, args) => {
        // Delete command message
        message.delete().catch(e => {});
        
        // Get target user
        let target;
        if (args.length > 0) {
            target = message.mentions.members.first() || 
                     message.guild.members.cache.get(args[0]) || 
                     message.guild.members.cache.find(m => m.displayName.toLowerCase().includes(args.join(' ').toLowerCase()));
        }
        
        // Default to message author if no target or target not found
        if (!target) target = message.member;
        
        // Aesthetic types
        const aesthetics = [
            { name: "Vaporwave", description: "Retro digital art, neon colors, nostalgic technology from the 80s-90s, and distorted classical sculptures.", color: "#FF71CE" },
            { name: "Cottagecore", description: "Cozy countryside living, flower gardens, fresh baked bread, and picnics in meadows.", color: "#B8E986" },
            { name: "Dark Academia", description: "Classic literature, gothic architecture, candlelight, leather-bound books, and autumn leaves.", color: "#8B4513" },
            { name: "Cyberpunk", description: "Neon-lit dystopian cities, advanced technology, digital interfaces, and urban decay.", color: "#00FFFF" },
            { name: "Witchcore", description: "Crystals, herbs, spell books, tarot cards, and forest wanderings under the moonlight.", color: "#480048" },
            { name: "Pastel Goth", description: "Spooky elements paired with pastels, cute skeletons, and creepy-but-kawaii accessories.", color: "#FFCCE7" },
            { name: "Y2K", description: "Bubblegum pop aesthetics from the early 2000s, metallic colors, and flip phones.", color: "#FF66CC" },
            { name: "Synthwave", description: "80s-inspired futuristic landscapes, sunset colors, and retro sportscars on endless highways.", color: "#FF00FF" },
            { name: "Kawaii", description: "Cute and colorful characters, pastel colors, and adorable accessories.", color: "#FFB7C5" },
            { name: "Grunge", description: "Worn-out flannels, vinyl records, moody photography, and rebellious attitude.", color: "#2F2F2F" },
            { name: "Minimalist", description: "Clean lines, neutral colors, uncluttered spaces, and functional design.", color: "#E0E0E0" },
            { name: "Steampunk", description: "Victorian-era fashion mixed with industrial machinery, brass gadgets, and mechanical wonders.", color: "#B5A642" },
            { name: "Lo-fi", description: "Cozy study spaces, warm earthy tones, vintage electronic equipment, and rainy city windows.", color: "#7E7E7E" },
            { name: "Art Deco", description: "Geometric patterns, bold colors, luxurious materials, and streamlined forms from the 1920s.", color: "#FFD700" },
            { name: "Solarpunk", description: "Sustainable futures, green architecture, renewable energy, and harmony with nature.", color: "#7CFC00" },
            { name: "Kidcore", description: "Bright primary colors, nostalgic toys, cartoons, and childlike wonder.", color: "#FF6B6B" },
            { name: "Fairycore", description: "Whimsical natural settings, mushrooms, moss, flower crowns, and fairy lights.", color: "#E6E6FA" },
            { name: "Dreamcore", description: "Surreal and dream-like imagery, liminal spaces, and nostalgic but slightly unsettling visuals.", color: "#ADD8E6" },
            { name: "Webcore", description: "Early internet aesthetics, dial-up nostalgia, pixelated icons, and primitive web graphics.", color: "#00FFFF" },
            { name: "Film Noir", description: "High-contrast black and white, mysterious shadows, detective stories, and smoky rooms.", color: "#000000" }
        ];
        
        // Randomly select an aesthetic
        const aesthetic = aesthetics[Math.floor(Math.random() * aesthetics.length)];
        
        // Activities that fit the aesthetic
        const activities = [
            "listening to",
            "creating",
            "wearing",
            "collecting",
            "studying",
            "dreaming about",
            "photographing",
            "writing about",
            "designing",
            "exploring"
        ];
        
        // Generate specific elements based on the aesthetic
        const generateElements = (aestheticName) => {
            // Base of possible elements for each aesthetic
            const elements = {
                "Vaporwave": ["palm trees", "VHS tapes", "80s computers", "statues", "Japanese characters", "glitch art", "Windows 95", "cassette tapes", "neon signs", "old soda commercials"],
                "Cottagecore": ["wildflowers", "handmade bread", "wicker baskets", "gardening tools", "tea sets", "homemade jam", "vintage dresses", "forest mushrooms", "farm animals", "herbs"],
                "Dark Academia": ["vintage books", "fountain pens", "tweed blazers", "coffee shops", "chess sets", "classical music", "poetry journals", "ancient languages", "oil paintings", "old libraries"],
                "Cyberpunk": ["holographic displays", "neon-lit streets", "advanced prosthetics", "virtual reality", "underground clubs", "data chips", "hackers", "AI interfaces", "urban sprawl", "cybernetic implants"],
                "Witchcore": ["crystal collections", "herb bundles", "spell books", "tarot decks", "moon phases", "forest creatures", "potion bottles", "occult symbols", "ritual candles", "dried flowers"],
                "Pastel Goth": ["skull accessories", "pastel hair dye", "platform boots", "cute bats", "creepy-cute plushies", "pink coffins", "candy hearts", "skeleton drawings", "spooky kawaii stickers", "lavender candles"],
                "Y2K": ["butterfly clips", "platform flip flops", "glossy lips", "flip phones", "boy bands", "tattoo chokers", "mini handbags", "bedazzled everything", "low-rise jeans", "frosted eyeshadow"],
                "Synthwave": ["digital sunsets", "neon grids", "vintage sports cars", "retrofuturistic art", "analog synthesizers", "laser beams", "chrome typography", "outrun visuals", "arcade machines", "cassette mixtapes"],
                "Kawaii": ["plushies", "heart-shaped accessories", "pastel stationery", "cute animal mascots", "bubble tea", "character bento boxes", "hair bows", "soft colors", "puffy stickers", "tiny food charms"],
                "Grunge": ["flannel shirts", "vinyl records", "ripped jeans", "combat boots", "band t-shirts", "vintage cameras", "thrift store finds", "underground zines", "dive bars", "skateboards"],
                "Minimalist": ["monochrome outfits", "clean desk setups", "essential oils", "simple jewelry", "indoor plants", "unbranded items", "neutral palettes", "functional furniture", "sustainable goods", "digital decluttering"],
                "Steampunk": ["pocket watches", "mechanical wings", "brass goggles", "leather top hats", "gear-filled contraptions", "airships", "corsets", "tea brewing devices", "compass tools", "antique maps"],
                "Lo-fi": ["record players", "warm lighting", "coffee mugs", "notebooks", "plant corners", "oversized sweaters", "old film cameras", "window seats", "bedroom studios", "rain soundtracks"],
                "Art Deco": ["geometric jewelry", "bold architectural drawings", "luxury materials", "streamlined furniture", "ornate cocktail shakers", "fan patterns", "chrome details", "vintage posters", "grand hotels", "zigzag designs"],
                "Solarpunk": ["vertical gardens", "solar panels", "sustainable fashion", "community gardens", "reclaimed materials", "green tech", "natural dyes", "environmentalist literature", "bike-friendly designs", "clean energy inventions"],
                "Kidcore": ["colorful stickers", "childhood cartoons", "retro toys", "rainbow clothing", "alphabet magnets", "glitter crafts", "primary colors", "temporary tattoos", "bubble wands", "fruit-shaped erasers"],
                "Fairycore": ["flower crowns", "mushroom figurines", "iridescent wings", "crystal gardens", "moss terrariums", "butterfly accessories", "forest photography", "tiny doors", "glowing jars", "pressed flowers"],
                "Dreamcore": ["liminal spaces", "vintage nostalgic objects", "slightly distorted photos", "familiar but strange settings", "dreamlike filters", "empty playgrounds", "old TV static", "childhood memories", "surreal combinations", "foggy landscapes"],
                "Webcore": ["90s website graphics", "cursor trails", "pixelated icons", "visitor counters", "guestbooks", "flashing GIFs", "desktop backgrounds", "chatroom logs", "ASCII art", "dial-up sounds"],
                "Film Noir": ["fedora hats", "typewriters", "black and white photography", "detective notebooks", "trench coats", "cigarette holders", "shadowy portraits", "vintage microphones", "mysterious letters", "jazz records"]
            };
            
            return elements[aestheticName] || ["mysterious items", "unique collections", "special artifacts", "personal treasures", "signature pieces"];
        };
        
        const specificElements = generateElements(aesthetic.name);
        
        // Select random elements and activity
        const element1 = specificElements[Math.floor(Math.random() * specificElements.length)];
        let element2 = specificElements[Math.floor(Math.random() * specificElements.length)];
        while (element2 === element1) {
            element2 = specificElements[Math.floor(Math.random() * specificElements.length)];
        }
        
        const activity = activities[Math.floor(Math.random() * activities.length)];
        
        // Create the embed
        const embed = new EmbedBuilder()
            .setColor(aesthetic.color)
            .setTitle(`${client.emoji.crown || '👑'} AESTHETIC GENERATOR ${client.emoji.crown || '👑'}`)
            .setDescription(`${client.emoji.member || '👤'} **${target.displayName}**'s aesthetic is...\n\n**${aesthetic.name}!**`)
            .addField('Description', aesthetic.description)
            .addField('Signature Elements', `• ${element1}\n• ${element2}`)
            .addField('Activity', `You'd probably enjoy ${activity} ${specificElements[Math.floor(Math.random() * specificElements.length)]}.`)
            .setThumbnail(target.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ 
                text: `Requested by ${message.author.tag} • Use ${message.guild.prefix || '!'}aesthetic @user to check someone else's vibe`, 
                iconURL: message.author.displayAvatarURL({ dynamic: true }) 
            })
            .setTimestamp();
            
        // Send the embed
        message.channel.send({ embeds: [embed] });
    }
};