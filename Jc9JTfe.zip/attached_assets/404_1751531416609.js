const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: '404',
    aliases: ['notfound'],
    category: 'fun',
    description: 'Create a custom 404 not found message',
    run: async (client, message, args) => {
        // Delete command message
        message.delete().catch(e => {});
        
        // Check for arguments
        if (args.length < 1) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${client.emoji.cross || '❌'} Please specify what couldn't be found!`)]
            });
        }
        
        // Get the thing that wasn't found
        const notFoundItem = args.join(' ');
        
        // List of funny error messages
        const errorMessages = [
            `We searched high and low, but ${notFoundItem} seems to be playing hide and seek. And winning.`,
            `${notFoundItem} took a wrong turn at Albuquerque and ended up in an alternate dimension.`,
            `Error 404: ${notFoundItem} not found. Have you tried turning it off and on again?`,
            `We sent our best scouts to find ${notFoundItem}, but they got lost too. Now we need to find them.`,
            `${notFoundItem} was last seen boarding a rocket to Mars with no return ticket.`,
            `${notFoundItem} decided to take a spontaneous vacation without telling anyone. How rude.`,
            `We regret to inform you that ${notFoundItem} has ghosted you. It's not you, it's them.`,
            `${notFoundItem} is currently unavailable. It's probably stuck in traffic on the information superhighway.`,
            `Our advanced algorithms suggest that ${notFoundItem} might be hiding under your bed. Have you checked?`,
            `${notFoundItem} has left the chat. Possibly forever.`,
            `Legend has it that ${notFoundItem} only appears during a blue moon while standing on one foot.`,
            `The goblins that run our servers have misplaced ${notFoundItem}. We've issued them a formal warning.`,
            `${notFoundItem} was abducted by aliens for scientific research. We expect it back... eventually.`,
            `${notFoundItem} fell into a plot hole and we're still trying to write it back into existence.`,
            `We've dispatched a team of highly trained hamsters to locate ${notFoundItem}. Please stand by.`
        ];
        
        // Select a random error message
        const errorMessage = errorMessages[Math.floor(Math.random() * errorMessages.length)];
        
        // ASCII art for 404
        const ascii404 = `
\`\`\`
  _  _    ___  _  _   
 | || |  / _ \\| || |  
 | || |_| | | | || |_ 
 |__   _| | | |__   _|
    | | | |_| |  | |  
    |_|  \\___/   |_|  
\`\`\``;
        
        // Create the embed
        const embed = new EmbedBuilder()
            .setColor('#ff6666') // Error red color
            .setTitle(`${client.emoji.error || '⚠️'} 404: ${notFoundItem} Not Found ${client.emoji.error || '⚠️'}`)
            .setDescription(ascii404)
            .addField('Error Details', errorMessage)
            .addField('Suggested Actions', [
                `• Try looking somewhere else`,
                `• Ask ${notFoundItem} to come back nicely`,
                `• Pretend you didn't need ${notFoundItem} anyway`,
                `• Create a new ${notFoundItem}`,
                `• Blame the nearest person`
            ].join('\n'))
            .setFooter({ 
                text: `Error reported by ${message.author.tag}`,
                iconURL: message.author.displayAvatarURL({ dynamic: true }) 
            })
            .setTimestamp();
            
        // Send the embed
        message.channel.send({ embeds: [embed] });
    }
};