const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'cat',
    category: 'fun',
    description: 'Get a random cat image',
    run: async (client, message, args) => {
        try {
            const response = await axios.get('https://api.thecatapi.com/v1/images/search');
            const catData = response.data[0];
            
            message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle('🐱 Random Cat')
                    .setImage(catData.url)
                    .setFooter({ text: 'Meow!' })]
            });
        } catch (error) {
            message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${client.emoji.cross} | Failed to fetch cat image!`)]
            });
        }
    }
};