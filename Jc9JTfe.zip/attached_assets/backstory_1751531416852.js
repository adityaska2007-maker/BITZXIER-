const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'backstory',
    category: 'fun',
    description: 'Generate a random character backstory',
    run: async (client, message, args) => {
        // Delete command message
        message.delete().catch(e => {});
        
        // Generate random backstory elements
        const origins = [
            "a small fishing village",
            "a bustling metropolis",
            "a hidden mountain monastery",
            "the frozen tundra of the north",
            "a nomadic desert tribe",
            "a wealthy noble family",
            "an orphanage in the slums",
            "a traveling circus",
            "a secretive cult",
            "a pirate ship",
            "a magical academy",
            "a mining colony",
            "an underground resistance",
            "a farming community",
            "a royal palace"
        ];
        
        const professions = [
            "blacksmith",
            "scholar",
            "mercenary",
            "healer",
            "merchant",
            "spy",
            "artist",
            "thief",
            "soldier",
            "hunter",
            "musician",
            "alchemist",
            "farmer",
            "sailor",
            "royal advisor"
        ];
        
        const motivations = [
            "seeking revenge against those who wronged them",
            "searching for a long-lost family member",
            "running from a dark past",
            "trying to break a family curse",
            "seeking glory and renown",
            "hunting for a legendary artifact",
            "fulfilling an ancient prophecy",
            "atoning for past mistakes",
            "seeking wealth and fortune",
            "trying to save their homeland",
            "uncovering a conspiracy",
            "escaping an arranged marriage",
            "pursuing knowledge at any cost",
            "seeking immortality",
            "trying to bring back a loved one"
        ];
        
        const traits = [
            "a strong sense of justice",
            "trust issues",
            "a fear of water",
            "a photographic memory",
            "extreme stubbornness",
            "unwavering loyalty",
            "crippling indecisiveness",
            "a silver tongue",
            "a short temper",
            "endless optimism",
            "chronic pessimism",
            "an insatiable curiosity",
            "a distinctive laugh",
            "a mysterious scar",
            "an unusual pet companion"
        ];
        
        const secrets = [
            "they are the last of an ancient lineage",
            "they can speak to spirits",
            "they are actually royalty in disguise",
            "they accidentally killed someone important",
            "they have a twin no one knows about",
            "they are slowly turning into something inhuman",
            "they are being hunted by an assassin",
            "they bear a cursed artifact",
            "they made a deal with a demon",
            "they are much older than they appear",
            "they have been prophesied to save/destroy the world",
            "they are immune to magic",
            "they are being possessed",
            "they have a forbidden love",
            "they know when and how they will die"
        ];
        
        // Randomly select elements
        const origin = origins[Math.floor(Math.random() * origins.length)];
        const profession = professions[Math.floor(Math.random() * professions.length)];
        const motivation = motivations[Math.floor(Math.random() * motivations.length)];
        const trait = traits[Math.floor(Math.random() * traits.length)];
        const secret = secrets[Math.floor(Math.random() * secrets.length)];
        
        // Generate character name (can use user's name or random)
        let characterName;
        if (args.length > 0) {
            characterName = args.join(' ');
        } else {
            // Use message author's name if no args provided
            characterName = message.author.username;
        }
        
        // Construct backstory
        const backstory = `
**${characterName}** hails from ${origin}, where they worked as a ${profession} before their life changed forever. 

They are now ${motivation}, a path that has led them through great danger and adventure. Those who know ${characterName} well recognize ${trait} as their defining characteristic, though few would suspect that ${secret}.

What destiny awaits this unlikely hero? Only time will tell...
`;
        
        // Create the embed
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle(`${client.emoji.crown || '👑'} CHARACTER BACKSTORY ${client.emoji.crown || '👑'}`)
            .setDescription(`${client.emoji.member || '👤'} **${characterName}'s Tale**`)
            .addField('Background', backstory)
            .setFooter({ 
                text: `Requested by ${message.author.tag} • Use ${message.guild.prefix || '!'}backstory [name] to specify a name`,
                iconURL: message.author.displayAvatarURL({ dynamic: true }) 
            })
            .setTimestamp();
            
        // Send the embed
        message.channel.send({ embeds: [embed] });
    }
};