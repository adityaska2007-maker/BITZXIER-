const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'roleall',
    aliases: ['rall'],
    category: 'moderation',
    description: 'Add or remove a role from all members',
    usage: 'roleall <add|remove> <role>',
    userPermissionsBitField: ['ManageRoles'],
    botPermissionsBitField: ['ManageRoles'],
    premium: false,
    run: async (client, message, args) => {
        if (args.length < 2) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('Usage: roleall <add|remove> <role>')
                ]
            });
        }

        const action = args[0].toLowerCase();
        if (!['add', 'remove'].includes(action)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('Action must be add or remove')
                ]
            });
        }

        const roleQuery = args.slice(1).join(' ');
        let role = message.mentions.roles.first() || 
                  message.guild.roles.cache.find(r => r.name.toLowerCase() === roleQuery.toLowerCase()) ||
                  message.guild.roles.cache.get(roleQuery);

        if (!role) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('Role not found')
                ]
            });
        }

        if (role.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('You cannot manage this role')
                ]
            });
        }

        if (role.position >= message.guild.me.roles.highest.position) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('I cannot manage this role')
                ]
            });
        }

        const members = await message.guild.members.fetch();
        const targetMembers = action === 'add' 
            ? members.filter(member => !member.roles.cache.has(role.id) && !member.user.bot)
            : members.filter(member => member.roles.cache.has(role.id) && !member.user.bot);

        if (targetMembers.size === 0) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription(`No members to ${action} the role`)
                ]
            });
        }

        const statusMessage = await message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FFAA00')
                    .setDescription(`${action === 'add' ? 'Adding' : 'Removing'} role ${role} to ${targetMembers.size} members...`)
            ]
        });

        let success = 0;
        let failed = 0;

        for (const member of targetMembers.values()) {
            try {
                if (action === 'add') {
                    await member.roles.add(role);
                } else {
                    await member.roles.remove(role);
                }
                success++;
            } catch (error) {
                failed++;
            }
        }

        return statusMessage.edit({
            embeds: [
                new EmbedBuilder()
                    .setColor('#00FF00')
                    .setDescription(`${action === 'add' ? 'Added' : 'Removed'} role ${role} - Success: ${success}, Failed: ${failed}`)
            ]
        });
    }
};