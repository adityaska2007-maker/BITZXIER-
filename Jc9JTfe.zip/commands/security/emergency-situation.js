const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'emergency-situation',
    aliases: ['emgs'],
    category: 'security',
    description: 'Instant emergency lockdown with immediate channel restriction',
    usage: 'emergency-situation',
    userPermissionsBitField: ['Administrator'],
    botPermissionsBitField: ['ManageChannels', 'ManageRoles'],
    premium: false,
    run: async (client, message, args) => {
        const guildId = message.guild.id;
        
        // Check if already in emergency situation
        const emergencySituation = await client.db.get(`emergency_situation_${guildId}`) || false;
        
        if (emergencySituation) {
            // Disable emergency situation
            const channels = message.guild.channels.cache.filter(ch => ch.type === 'GUILD_TEXT');
            let restored = 0;

            for (const channel of channels.values()) {
                try {
                    await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                        SEND_MESSAGES: null,
                        ADD_REACTIONS: null,
                        CREATE_PUBLIC_THREADS: null,
                        CREATE_PRIVATE_THREADS: null
                    });
                    restored++;
                } catch (error) {
                    console.error(`Failed to restore channel ${channel.name}:`, error);
                }
            }

            await client.db.delete(`emergency_situation_${guildId}`);

            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#00FF00')
                        .setDescription(`Emergency situation lifted - ${restored} channels restored`)
                ]
            });
        } else {
            // Enable emergency situation - complete lockdown
            const channels = message.guild.channels.cache.filter(ch => ch.type === 'GUILD_TEXT');
            let locked = 0;

            for (const channel of channels.values()) {
                try {
                    await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                        SEND_MESSAGES: false,
                        ADD_REACTIONS: false,
                        CREATE_PUBLIC_THREADS: false,
                        CREATE_PRIVATE_THREADS: false
                    });

                    // Only allow server owner and command user
                    await channel.permissionOverwrites.edit(message.guild.ownerId, {
                        SEND_MESSAGES: true,
                        ADD_REACTIONS: true,
                        CREATE_PUBLIC_THREADS: true,
                        CREATE_PRIVATE_THREADS: true
                    });

                    if (message.author.id !== message.guild.ownerId) {
                        await channel.permissionOverwrites.edit(message.author.id, {
                            SEND_MESSAGES: true,
                            ADD_REACTIONS: true,
                            CREATE_PUBLIC_THREADS: true,
                            CREATE_PRIVATE_THREADS: true
                        });
                    }

                    locked++;
                } catch (error) {
                    console.error(`Failed to lock channel ${channel.name}:`, error);
                }
            }

            await client.db.set(`emergency_situation_${guildId}`, true);

            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription(`EMERGENCY SITUATION ACTIVATED - ${locked} channels locked`)
                ]
            });
        }
    }
};