const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'emergency',
    aliases: ['em'],
    category: 'security',
    description: 'Emergency lockdown system with role and authorization management',
    usage: 'emergency <enable|disable|role|authorise>',
    userPermissionsBitField: ['Administrator'],
    botPermissionsBitField: ['ManageChannels', 'ManageRoles'],
    premium: false,
    run: async (client, message, args) => {
        const action = args[0]?.toLowerCase();
        const guildId = message.guild.id;
        
        if (!action) {
            return showHelp(message);
        }

        switch (action) {
            case 'enable':
                return handleEnable(client, message);
            case 'disable':
                return handleDisable(client, message);
            case 'role':
                return handleRole(client, message, args.slice(1));
            case 'authorise':
            case 'authorize':
                return handleAuthorise(client, message, args.slice(1));
            default:
                return showHelp(message);
        }
    }
};

async function showHelp(message) {
    const embed = new EmbedBuilder()
        .setColor('#0099FF')
        .setTitle('Emergency System Commands')
        .addFields([
            { name: 'emergency enable', value: 'Activate emergency lockdown', inline: true },
            { name: 'emergency disable', value: 'Deactivate emergency lockdown', inline: true },
            { name: 'emergency role add <role>', value: 'Add emergency role', inline: true },
            { name: 'emergency role remove <role>', value: 'Remove emergency role', inline: true },
            { name: 'emergency role list', value: 'List emergency roles', inline: true },
            { name: 'emergency authorise add <user>', value: 'Add authorized user', inline: true },
            { name: 'emergency authorise remove <user>', value: 'Remove authorized user', inline: true },
            { name: 'emergency authorise list', value: 'List authorized users', inline: true }
        ]);
    
    return message.reply({ embeds: [embed] });
}

async function handleEnable(client, message) {
    const guildId = message.guild.id;
    const isActive = await client.db.get(`emergency_${guildId}`) || false;
    
    if (isActive) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('Emergency mode is already active')
            ]
        });
    }

    // Get emergency roles and authorized users
    const emergencyRoles = await client.db.get(`emergency_roles_${guildId}`) || [];
    const authorizedUsers = await client.db.get(`emergency_auth_${guildId}`) || [];

    // Lock all channels except for emergency roles and authorized users
    const channels = message.guild.channels.cache.filter(ch => ch.type === 'GUILD_TEXT');
    let locked = 0;

    for (const channel of channels.values()) {
        try {
            // Deny everyone first
            await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SEND_MESSAGES: false,
                ADD_REACTIONS: false,
                CREATE_PUBLIC_THREADS: false,
                CREATE_PRIVATE_THREADS: false
            });

            // Allow emergency roles
            for (const roleId of emergencyRoles) {
                const role = message.guild.roles.cache.get(roleId);
                if (role) {
                    await channel.permissionOverwrites.edit(role, {
                        SEND_MESSAGES: true,
                        ADD_REACTIONS: true,
                        CREATE_PUBLIC_THREADS: true,
                        CREATE_PRIVATE_THREADS: true
                    });
                }
            }

            // Allow authorized users
            for (const userId of authorizedUsers) {
                await channel.permissionOverwrites.edit(userId, {
                    SEND_MESSAGES: true,
                    ADD_REACTIONS: true,
                    CREATE_PUBLIC_THREADS: true,
                    CREATE_PRIVATE_THREADS: true
                });
            }

            locked++;
        } catch (error) {
            console.error(`Failed to configure channel ${channel.name}:`, error);
        }
    }

    await client.db.set(`emergency_${guildId}`, true);

    return message.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#FF0000')
                .setDescription(`Emergency lockdown activated - ${locked} channels configured`)
        ]
    });
}

async function handleDisable(client, message) {
    const guildId = message.guild.id;
    const isActive = await client.db.get(`emergency_${guildId}`) || false;
    
    if (!isActive) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#00FF00')
                    .setDescription('Emergency mode is not active')
            ]
        });
    }

    // Restore normal permissions
    const channels = message.guild.channels.cache.filter(ch => ch.type === 'GUILD_TEXT');
    let restored = 0;

    for (const channel of channels.values()) {
        try {
            // Remove emergency overrides
            const emergencyRoles = await client.db.get(`emergency_roles_${guildId}`) || [];
            const authorizedUsers = await client.db.get(`emergency_auth_${guildId}`) || [];

            // Reset everyone permissions
            await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SEND_MESSAGES: null,
                ADD_REACTIONS: null,
                CREATE_PUBLIC_THREADS: null,
                CREATE_PRIVATE_THREADS: null
            });

            // Remove emergency role overrides
            for (const roleId of emergencyRoles) {
                try {
                    await channel.permissionOverwrites.delete(roleId);
                } catch (e) {}
            }

            // Remove authorized user overrides
            for (const userId of authorizedUsers) {
                try {
                    await channel.permissionOverwrites.delete(userId);
                } catch (e) {}
            }

            restored++;
        } catch (error) {
            console.error(`Failed to restore channel ${channel.name}:`, error);
        }
    }

    await client.db.delete(`emergency_${guildId}`);

    return message.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#00FF00')
                .setDescription(`Emergency lockdown deactivated - ${restored} channels restored`)
        ]
    });
}

async function handleRole(client, message, args) {
    const guildId = message.guild.id;
    const subAction = args[0]?.toLowerCase();
    
    if (!subAction || !['add', 'remove', 'list'].includes(subAction)) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('Usage: emergency role <add|remove|list> [role]')
            ]
        });
    }

    const emergencyRoles = await client.db.get(`emergency_roles_${guildId}`) || [];

    if (subAction === 'list') {
        if (emergencyRoles.length === 0) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#0099FF')
                        .setDescription('No emergency roles configured')
                ]
            });
        }

        const roleList = emergencyRoles.map(roleId => {
            const role = message.guild.roles.cache.get(roleId);
            return role ? role.toString() : 'Unknown Role';
        }).join('\n');

        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#0099FF')
                    .setDescription(`Emergency roles:\n${roleList}`)
            ]
        });
    }

    const roleQuery = args.slice(1).join(' ');
    if (!roleQuery) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('Please specify a role')
            ]
        });
    }

    const role = message.mentions.roles.first() || 
                 message.guild.roles.cache.find(r => r.name.toLowerCase() === roleQuery.toLowerCase()) ||
                 message.guild.roles.cache.get(roleQuery);

    if (!role) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('Role not found')
            ]
        });
    }

    if (subAction === 'add') {
        if (emergencyRoles.includes(role.id)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('Role is already an emergency role')
                ]
            });
        }

        emergencyRoles.push(role.id);
        await client.db.set(`emergency_roles_${guildId}`, emergencyRoles);

        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#00FF00')
                    .setDescription(`Added ${role} as emergency role`)
            ]
        });
    }

    if (subAction === 'remove') {
        const index = emergencyRoles.indexOf(role.id);
        if (index === -1) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('Role is not an emergency role')
                ]
            });
        }

        emergencyRoles.splice(index, 1);
        await client.db.set(`emergency_roles_${guildId}`, emergencyRoles);

        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#00FF00')
                    .setDescription(`Removed ${role} from emergency roles`)
            ]
        });
    }
}

async function handleAuthorise(client, message, args) {
    const guildId = message.guild.id;
    const subAction = args[0]?.toLowerCase();
    
    if (!subAction || !['add', 'remove', 'list'].includes(subAction)) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('Usage: emergency authorise <add|remove|list> [user]')
            ]
        });
    }

    const authorizedUsers = await client.db.get(`emergency_auth_${guildId}`) || [];

    if (subAction === 'list') {
        if (authorizedUsers.length === 0) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#0099FF')
                        .setDescription('No authorized users configured')
                ]
            });
        }

        const userList = authorizedUsers.map(userId => {
            const user = client.users.cache.get(userId);
            return user ? user.toString() : 'Unknown User';
        }).join('\n');

        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#0099FF')
                    .setDescription(`Authorized users:\n${userList}`)
            ]
        });
    }

    const user = message.mentions.users.first() || await client.users.fetch(args[1]).catch(() => null);
    if (!user) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('Please mention a user or provide a valid user ID')
            ]
        });
    }

    if (subAction === 'add') {
        if (authorizedUsers.includes(user.id)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('User is already authorized')
                ]
            });
        }

        authorizedUsers.push(user.id);
        await client.db.set(`emergency_auth_${guildId}`, authorizedUsers);

        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#00FF00')
                    .setDescription(`Added ${user} as authorized user`)
            ]
        });
    }

    if (subAction === 'remove') {
        const index = authorizedUsers.indexOf(user.id);
        if (index === -1) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('User is not authorized')
                ]
            });
        }

        authorizedUsers.splice(index, 1);
        await client.db.set(`emergency_auth_${guildId}`, authorizedUsers);

        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#00FF00')
                    .setDescription(`Removed ${user} from authorized users`)
            ]
        });
    }
}