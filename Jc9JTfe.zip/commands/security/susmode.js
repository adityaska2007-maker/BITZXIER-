const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'susmode',
    aliases: ['sus', 'suspicious'],
    category: 'security',
    description: 'Enable/disable suspicious activity monitoring mode',
    usage: 'susmode <on|off|status|config>',
    userPermissionsBitField: ['Administrator'],
    botPermissionsBitField: ['ManageChannels', 'KickMembers', 'BanMembers'],
    premium: false,
    run: async (client, message, args) => {
        const action = args[0]?.toLowerCase();
        
        if (!action || !['on', 'off', 'status', 'config'].includes(action)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('Usage: susmode <on|off|status|config>')
                ]
            });
        }

        const guildId = message.guild.id;
        const currentMode = await client.db.get(`susmode_${guildId}`) || false;
        const config = await client.db.get(`susmode_config_${guildId}`) || {
            maxMessages: 10,
            timeWindow: 30000,
            autoKick: false,
            autoBan: false,
            logChannel: null
        };

        if (action === 'status') {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(currentMode ? '#FFAA00' : '#00FF00')
                        .setDescription(`Suspicious mode: ${currentMode ? 'ACTIVE' : 'INACTIVE'}`)
                        .addFields([
                            { name: 'Max Messages', value: config.maxMessages.toString(), inline: true },
                            { name: 'Time Window', value: `${config.timeWindow / 1000}s`, inline: true },
                            { name: 'Auto Actions', value: `Kick: ${config.autoKick ? 'ON' : 'OFF'} | Ban: ${config.autoBan ? 'ON' : 'OFF'}`, inline: false }
                        ])
                ]
            });
        }

        if (action === 'config') {
            const setting = args[1]?.toLowerCase();
            const value = args[2];

            if (!setting) {
                return message.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#0099FF')
                            .setDescription('Config options: messages <number>, time <seconds>, autokick <on|off>, autoban <on|off>, log <channel>')
                    ]
                });
            }

            switch (setting) {
                case 'messages':
                    if (!value || isNaN(value) || value < 1 || value > 50) {
                        return message.reply({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor('#FF0000')
                                    .setDescription('Messages must be between 1-50')
                            ]
                        });
                    }
                    config.maxMessages = parseInt(value);
                    break;

                case 'time':
                    if (!value || isNaN(value) || value < 5 || value > 300) {
                        return message.reply({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor('#FF0000')
                                    .setDescription('Time must be between 5-300 seconds')
                            ]
                        });
                    }
                    config.timeWindow = parseInt(value) * 1000;
                    break;

                case 'autokick':
                    if (!value || !['on', 'off'].includes(value)) {
                        return message.reply({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor('#FF0000')
                                    .setDescription('Autokick must be on or off')
                            ]
                        });
                    }
                    config.autoKick = value === 'on';
                    break;

                case 'autoban':
                    if (!value || !['on', 'off'].includes(value)) {
                        return message.reply({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor('#FF0000')
                                    .setDescription('Autoban must be on or off')
                            ]
                        });
                    }
                    config.autoBan = value === 'on';
                    break;

                case 'log':
                    const channel = message.mentions.channels.first() || message.guild.channels.cache.get(value);
                    if (!channel || channel.type !== 'GUILD_TEXT') {
                        return message.reply({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor('#FF0000')
                                    .setDescription('Invalid channel provided')
                            ]
                        });
                    }
                    config.logChannel = channel.id;
                    break;

                default:
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setColor('#FF0000')
                                .setDescription('Invalid config option')
                        ]
                    });
            }

            await client.db.set(`susmode_config_${guildId}`, config);
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#00FF00')
                        .setDescription(`Configuration updated: ${setting} set to ${value}`)
                ]
            });
        }

        if (action === 'on') {
            if (currentMode) {
                return message.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#FFAA00')
                            .setDescription('Suspicious mode is already active')
                    ]
                });
            }

            await client.db.set(`susmode_${guildId}`, true);
            await client.db.set(`susmode_config_${guildId}`, config);
            
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FFAA00')
                        .setDescription('Suspicious mode activated - monitoring user activity')
                ]
            });
        }

        if (action === 'off') {
            if (!currentMode) {
                return message.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#00FF00')
                            .setDescription('Suspicious mode is already inactive')
                    ]
                });
            }

            await client.db.delete(`susmode_${guildId}`);
            await client.db.delete(`susmode_activity_${guildId}`);
            
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#00FF00')
                        .setDescription('Suspicious mode deactivated')
                ]
            });
        }
    }
};