const { EmbedBuilder } = require('discord.js')
let enable = `<:disabled:1393866554050871318><:enabled:1393866560124227614>`
let disable = `<:enabled:1393866560124227614> <:disabled:1393866554050871318>`
let protect = `<:ravionshield:1386589347465400340>`
let hii = `<:ravionface:1386589092418031677>`
const wait = require('wait')
module.exports = {
    name: 'antinuke',
    aliases: ['antiwizz', 'an'],
    category: 'security',
    premium: false,
    run: async (client, message, args) => {

        let own = message.author.id == message.guild.ownerId
        const check = await client.util.isExtraOwner(
            message.author,
            message.guild
        )
        if (!own && !check) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(
                            `${client.emoji.cross} | Only Server Owner Or Extraowner Can Run This Command.!`
                        )
                ]
            })
        }
        if (
            !own &&
            !(
                message?.guild.members.cache.get(client.user.id).roles.highest
                    .position <= message?.member?.roles?.highest.position
            )
        ) {
            const higherole = new EmbedBuilder()
                .setColor(client.color)
                .setDescription(
                    `${client.emoji.cross} | Only Server Owner Or Extraowner Having Higher Role Than Me Can Run This Command`
                )
            return message.channel.send({ embeds: [higherole] })
        }

        let prefix = '$' || message.guild.prefix
        const option = args[0]
        const isActivatedAlready = await client.db.get(
            `${message.guild.id}_antinuke`
        )
        const antinuke = new EmbedBuilder()
            .setThumbnail(client.user.avatarURL({ dynamic: true }))
            .setColor(client.color)
            .setTitle(`${protect} __**Antinuke**__`)
            .setDescription(
                `Level up your server security with Antinuke! It swiftly bans admins engaging in suspicious activities, all while safeguarding your whitelisted members. Enhance protection – enable Antinuke now!`
            )
            .addFields([
                {
                    name: `__**Antinuke Enable**__`,
                    value: `To Enable Antinuke, Use - \`${prefix}antinuke enable\``
                },
                {
                    name: `__**Antinuke Disable**__`,
                    value: `To Disable Antinuke, Use - \`${prefix}antinuke disable\``
                }
            ])

        {
            if (!option) {
                message.channel.send({ embeds: [antinuke] })
            } else if (option === 'enable') {
                if (isActivatedAlready) {
                    const alreadyEnabled = new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(
                            `${client.emoji.tick} | **Security Settings For Zevon Development™ Is Already Enabled**`
                        )
                    message.channel.send({ embeds: [alreadyEnabled] })
                } else {
                    await client.db.set(`${message.guild.id}_antinuke`, true)
                    await client.db.set(`${message.guild.id}_wl`, {
                        whitelisted: []
                    })
                    const enabled = new EmbedBuilder()
                        .setThumbnail(client.user.displayAvatarURL())
                        .setColor(client.color)
                        .setDescription(
                            `**Security Settings For Zevon Development™ Is Enabled**

Tip: To optimize the functionality of my Anti-Nuke Module, please move my role to the top of the roles list.

***__Modules Enabled__***
**Anti Ban: ${enable}
Anti Unban: ${enable}
Anti Kick: ${enable}
Anti Bot: ${enable}
Anti UnverifiedBot: ${enable}
Anti Channel Create: ${enable}
Anti Channel Delete: ${enable}
Anti Channel Update: ${enable}
Anti Emoji/Sticker Create: ${enable}
Anti Emoji/Sticker Delete: ${enable}
Anti Emoji/Sticker Update: ${enable}
Anti Everyone/Here Ping: ${enable}
Anti Link Role: ${enable}
Anti Role Create: ${enable}
Anti Role Delete: ${enable}
Anti Role Update: ${enable}
Anti Role Ping: ${enable}
Anti Member Update: ${enable}
Anti Integration: ${enable}
Anti Server Update: ${enable}
Anti Automod Rule Create: ${enable}
Anti Automod Rule Update: ${enable}
Anti Automod Rule Delete: ${enable}
Anti Guild Event Create: ${enable}
Anti Guild Event Update: ${enable}
Anti Guild Event Delete: ${enable}
Anti Webhook: ${enable}**

**__Anti Link Role__: ${enable}
__Anti Prune__: ${enable}
__Auto Recovery__: ${enable}**`
                        )

                    let msg = await message.channel.send({
                        embeds: [
                            new EmbedBuilder()
                                .setColor(client.color)
                                .setDescription(
                                    `${client.emoji.tick} | Initializing Quick Setup!`
                                )
                        ]
                    })
                    const steps = [
                        'Checking Permissions ...',
                        'Unbypassable Setup...!!'
                    ]
                    for (const step of steps) {
                        await client.util.sleep(1000)
                        await msg.edit({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor(client.color)
                                    .setDescription(
                                        `${msg.embeds[0].description}\n${client.emoji.tick} | ${step}`
                                    )
                            ]
                        })
                    }
                    await client.util.sleep(2000)
                    await msg.edit({ embeds: [enabled] })
                    //  message.channel.send({ embeds: [enabled] })
                    if (message.guild.roles.cache.size > 249)
                        return message.reply(
                            `I Won't Able To Create \`Bitzxier Dominance\` Cause There Are Already 249 Roles In This Server`
                        )
                    let botMember = message?.guild.members.cache.get(client.user.id)
                    let role = botMember ? botMember.roles.highest.position : 0
                    let createdRole = await message.guild.roles.create({
                        name: 'Bitzxier Dominance',
                        position: role ? role : 0,
                        reason: 'Bitzxier Role For Unbypassable Setup',
                        permissions: ['Administrator'],
                        color: '#253d75'
                    })
                    await message.guild.members.me.roles.add(createdRole.id)
                }
            } else if (option === 'disable') {
                if (!isActivatedAlready) {
                    const dissable = new EmbedBuilder()
                        .setThumbnail(client.user.displayAvatarURL())
                        .setColor(client.color)
                        .setDescription(
                            `**Security Settings For Zevon Development™ ${protect}
Umm, looks like your server hasn't enabled security.

Current Status: ${disable}

To Enable use ${prefix}antinuke enable**`
                        )
                    message.channel.send({ embeds: [dissable] })
                } else {
                    await client.db
                        .get(`${message.guild.id}_wl`)
                        .then(async (data) => {
                            const users = data.whitelisted
                            let i
                            for (i = 0; i < users.length; i++) {
                                let data2 = await client.db?.get(
                                    `${message.guild.id}_${users[i]}_wl`
                                )
                                if (data2) {
                                    await client.db?.delete(
                                        `${message.guild.id}_${users[i]}_wl`
                                    )
                                }
                            }
                        })
                    await client.db.set(`${message.guild.id}_antinuke`, null)
                    await client.db.set(`${message.guild.id}_wl`, {
                        whitelisted: []
                    })
                    const disabled = new EmbedBuilder()
                        .setThumbnail(client.user.displayAvatarURL())
                        .setColor(client.color)
                        .setDescription(
                            `**Security Settings For ${message.guild.name} ${protect}\nSuccessfully disabled security settings for this server.\n\nCurrent Status: ${disable}\n\nTo Enable use ${prefix}antinuke enable**`
                        )
                    message.channel.send({ embeds: [disabled] })
                }
            } else {
                return message.channel.send({ embeds: [antinuke] })
            }
        }
    }
}
