const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js')

module.exports = {
    name: 'wlisted',
    aliases: ['wlist', 'whitelisted'],
    category: 'security',
    premium: false,
    run: async (client, message, args) => {
        let own = message.author.id == message.guild.ownerId
        const check = await client.util.isExtraOwner(
            message.author,
            message.guild
        )
        if (!own && !check) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(
                            `<:enabled:1393866560124227614> <:disabled:1393866554050871318> | Only Server Owner Or Extraowner Can Run This Command.!`
                        )
                ]
            })
        }
        if (
            !own &&
            !(
                message?.guild.members.cache.get(client.user.id).roles.highest
                    .position <= message?.member?.roles?.highest.position
            )
        ) {
            const higherole = new EmbedBuilder()
                .setColor(client.color)
                .setDescription(
                    `<:enabled:1393866560124227614> <:disabled:1393866554050871318> | Only Server Owner Or Extraowner Having Higher Role Than Me Can Run This Command`
                )
            return message.channel.send({ embeds: [higherole] })
        }

        const antinuke = await client.db.get(`${message.guild.id}_antinuke`)
        if (!antinuke) {
            message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(
                            `<:enabled:1393866560124227614> <:disabled:1393866554050871318> | Seems that antinuke module is not enabled in this server.`
                        )
                ]
            })
        } else {
            await client.db.get(`${message.guild.id}_wl`).then(async (data) => {
                if (!data) {
                    await client.db.set(`${message.guild.id}_wl`, {
                        whitelisted: []
                    })
                    let users = data.whitelisted
                    let i
                    for (i = 0; i < users.length; i++) {
                        let data2 = await client.db?.get(
                            `${message.guild.id}_${users[i]}_wl`
                        )
                        if (data2) {
                            client.db?.delete(
                                `${message.guild.id}_${users[i]}_wl`
                            )
                        }
                    }
                    message.channel.send({
                        embeds: [
                            new EmbedBuilder()
                                .setColor(client.color)
                                .setDescription(
                                    `<:enabled:1393866560124227614> <:disabled:1393866554050871318> | Please again run this command as the database was earlier not assigned.`
                                )
                        ]
                    })
                } else {
                    const users = data.whitelisted
                    
                    // Get all antinuke module statuses
                    const guildData = await client.db.get(`${message.guild.id}_antinuke`)
                    const antibanData = await client.db.get(`${message.guild.id}_antiban`)
                    const antikickData = await client.db.get(`${message.guild.id}_antikick`)
                    const antipruneData = await client.db.get(`${message.guild.id}_antiprune`)
                    const antibotData = await client.db.get(`${message.guild.id}_antibot`)
                    const antiguildData = await client.db.get(`${message.guild.id}_antiguild`)
                    const antimemberData = await client.db.get(`${message.guild.id}_antimember`)
                    const antichannelcreateData = await client.db.get(`${message.guild.id}_antichannelcreate`)
                    const antichanneldeleteData = await client.db.get(`${message.guild.id}_antichanneldelete`)
                    const antichannelupdateData = await client.db.get(`${message.guild.id}_antichannelupdate`)
                    const antirolecreateData = await client.db.get(`${message.guild.id}_antirolecreate`)
                    const antiroledeleteData = await client.db.get(`${message.guild.id}_antiroledelete`)
                    const antiroleupdateData = await client.db.get(`${message.guild.id}_antiroleupdate`)
                    const antieueryoneData = await client.db.get(`${message.guild.id}_antieveryone`)
                    const antiwebhookData = await client.db.get(`${message.guild.id}_antiwebhook`)
                    
                    // Function to get emoji based on module status
                    const getStatusEmoji = (moduleData) => {
                        return moduleData ? '<:disabled:1393866554050871318> <:enabled:1393866560124227614>' : '<:enabled:1393866560124227614> <:disabled:1393866554050871318>'
                    }
                    
                    const moduleStatus = new EmbedBuilder()
                        .setColor(client.color)
                        .setTitle('**Security Module Status**')
                        .setDescription(
                            `${getStatusEmoji(antibanData)} : **Ban**
${getStatusEmoji(antikickData)} : **Kick**
${getStatusEmoji(antipruneData)} : **Prune**
${getStatusEmoji(antibotData)} : **Bot Add**
${getStatusEmoji(antiguildData)} : **Server Update**
${getStatusEmoji(antimemberData)} : **Member Role Update**
${getStatusEmoji(antichannelcreateData)} : **Channel Create**
${getStatusEmoji(antichanneldeleteData)} : **Channel Delete**
${getStatusEmoji(antichannelupdateData)} : **Channel Update**
${getStatusEmoji(antirolecreateData)} : **Role Create**
${getStatusEmoji(antiroledeleteData)} : **Role Delete**
${getStatusEmoji(antiroleupdateData)} : **Role Update**
${getStatusEmoji(antieueryoneData)} : **Mention @everyone**
${getStatusEmoji(antiwebhookData)} : **Webhook Management**
${getStatusEmoji(guildData)} : **Emojis & Stickers Management**`
                        )
                    
                    const mentions = []
                    if (users.length !== 0) {
                        users.forEach((userId) =>
                            mentions.push(
                                `${client.emoji.dot} <@${userId}> (${userId})`
                            )
                        )
                        const whitelisted = new EmbedBuilder()
                            .setColor(client.color)
                            .setTitle(`__**Whitelisted Users**__`)
                            .setDescription(mentions.join('\n'))
                        message.channel.send({ embeds: [moduleStatus, whitelisted] })
                    } else {
                        message.channel.send({ embeds: [moduleStatus] })
                    }
                }
            })
        }
    }
}
