
const { EmbedBuilder } = require('discord.js')
let enable = `<:disabled:1393866554050871318><:enabled:1393866560124227614>`
let disable = `<:enabled:1393866560124227614>`
let protect = `<a:protection:1324707112156397689>`
let hii = `<a:cyan_dot:1340585319480688672>`
const wait = require('wait')

module.exports = {
    name: 'automod',
    aliases: [],
    cooldown: 5,
    category: 'automod',
    subcommand: ['bypass user', 'bypass role','bypass channel'],
    premium: false,
    run: async (client, message, args) => {
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setAuthor({
                name: message.author.tag,
                iconURL: message.author.displayAvatarURL({ dynamic: true })
            })
            .setThumbnail(message.guild.iconURL({ dynamic: true }))
            .setTitle(`${protect} Automod Configuration`)
            .setDescription(`**Configure your server's automod settings below:**\n\n${hii} **Available Commands:**`)
            .addFields([
                {
                    name: `\`automod bypass user add <user>\``,
                    value: `**Adds a user to automod bypass list**`
                },
                {
                    name: `\`automod bypass user remove <user>\``,
                    value: `**Removes a user from automod bypass list**`
                },
                {
                    name: `\`automod bypass user list\``,
                    value: `**Shows automod bypass user list**`
                },
                {
                    name: `\`automod bypass user reset\``,
                    value: `**Resets automod bypass user list**`
                },
                {
                    name: `\`automod bypass role add <role>\``,
                    value: `**Adds a role to automod bypass list**`
                },
                {
                    name: `\`automod bypass role remove <role>\``,
                    value: `**Removes a role from automod bypass list**`
                },
                {
                    name: `\`automod bypass role list\``,
                    value: `**Shows automod bypass role list**`
                },
                {
                    name: `\`automod bypass role reset\``,
                    value: `**Resets automod bypass role list**`
                },
                {
                    name: `\`automod bypass channel add <channel>\``,
                    value: `**Adds a channel to automod bypass list**`
                },
                {
                    name: `\`automod bypass channel remove <channel>\``,
                    value: `**Removes a channel from automod bypass list**`
                },
                {
                    name: `\`automod bypass channel list\``,
                    value: `**Shows automod bypass channel list**`
                },
                {
                    name: `\`automod bypass channel reset\``,
                    value: `**Resets automod bypass channel list**`
                }
            ])
            .setFooter({
                text: `Requested by ${message.author.tag}`,
                iconURL: message.author.displayAvatarURL({ dynamic: true })
            })
            .setTimestamp()

        return message.channel.send({ embeds: [embed] })
    }
}
