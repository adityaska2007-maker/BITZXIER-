const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');

module.exports = {
    name: 'gresume',
    aliases: ['giveaway-resume'],
    category: 'giveaway',
    premium: false,
    cooldown: 3,
    run: async (client, message, args) => {
        if (!message.member.permissions.has('ManageMessages')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | You need \`Manage Messages\` permission to resume giveaways.`)
                ]
            });
        }

        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | Please provide a giveaway message ID.\n\nUsage: \`gresume <messageId>\``)
                ]
            });
        }

        const messageId = args[0];
        const giveawayData = await client.db.get(`giveaway_${messageId}`);

        if (!giveawayData) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | No giveaway found with that message ID.`)
                ]
            });
        }

        if (giveawayData.ended) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | This giveaway has already ended.`)
                ]
            });
        }

        if (!giveawayData.paused) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | This giveaway is not paused.`)
                ]
            });
        }

        if (giveawayData.hostId !== message.author.id && !message.member.permissions.has('Administrator')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | You can only resume giveaways you created or you need Administrator permission.`)
                ]
            });
        }

        try {
            const channel = client.channels.cache.get(giveawayData.channelId);
            if (!channel) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color)
                            .setDescription(`${client.emoji.cross} | Giveaway channel not found.`)
                    ]
                });
            }

            const giveawayMessage = await channel.messages.fetch(messageId).catch(() => null);
            if (!giveawayMessage) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color)
                            .setDescription(`${client.emoji.cross} | Giveaway message not found.`)
                    ]
                });
            }

            // Resume the giveaway
            giveawayData.paused = false;
            await client.db.set(`giveaway_${messageId}`, giveawayData);

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🎉 GIVEAWAY 🎉')
                .setDescription(`**Prize:** ${giveawayData.prize}\n**Winners:** ${giveawayData.winners}\n**Ends:** <t:${Math.floor(giveawayData.endTime / 1000)}:R>\n**Hosted by:** <@${giveawayData.hostId}>`)
                .setFooter({ text: `Giveaway ID: ${giveawayData.messageId}` })
                .setTimestamp(giveawayData.endTime);

            const button = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`giveaway_enter_giveaway_${giveawayData.guildId}_${Date.now()}`)
                        .setLabel('🎉 Enter Giveaway')
                        .setStyle(3)
                );

            await giveawayMessage.edit({ embeds: [embed], components: [button] });

            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.tick} | Giveaway resumed successfully.`)
                ]
            });

        } catch (error) {
            console.error('Error resuming giveaway:', error);
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | An error occurred while resuming the giveaway.`)
                ]
            });
        }
    }
};