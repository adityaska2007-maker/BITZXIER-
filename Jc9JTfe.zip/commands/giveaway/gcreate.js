
const { EmbedBuilder } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'gcreate',
    aliases: ['giveaway-create', 'gstart'],
    category: 'giveaway',
    premium: false,
    cooldown: 5,
    run: async (client, message, args) => {
        // Delete the command message
        message.delete().catch(e => console.error('Could not delete giveaway command message:', e));

        if (!message.member.permissions.has('ManageMessages')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | You need \`Manage Messages\` permission to create giveaways.`)
                ]
            });
        }

        if (args.length < 3) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setTitle('Giveaway Creation')
                        .setDescription(`Usage: \`gcreate <duration> <winners> <prize>\`\n\nExample: \`gcreate 1d 1 Discord Nitro\``)
                        .addFields(
                            { name: 'Duration Examples', value: '`1m` `30s` `1h` `1d` `1w`', inline: true },
                            { name: 'Winners', value: 'Number of winners (1-10)', inline: true }
                        )
                ]
            });
        }

        const duration = args[0];
        const winnerCount = parseInt(args[1]);
        const prize = args.slice(2).join(' ');

        // Validate duration
        const time = ms(duration);
        if (!time || time < 1000) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | Invalid duration. Use formats like \`1m\`, \`1h\`, \`1d\`.`)
                ]
            });
        }

        // Validate winner count
        if (!winnerCount || winnerCount < 1 || winnerCount > 10) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | Winner count must be between 1 and 10.`)
                ]
            });
        }

        // Validate prize
        if (prize.length < 1 || prize.length > 100) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | Prize must be between 1 and 100 characters.`)
                ]
            });
        }

        const endTime = Date.now() + time;
        const giveawayId = `reaction_giveaway_${message.guild.id}_${Date.now()}`;

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle(`<a:Gift:1362704453945262221> ${prize} <a:Gift:1362704453945262221>`)
            .setDescription(
                `• **Ends:** <t:${Math.floor(endTime / 1000)}:R>\n` +
                `• **Hosted by:** ${message.author}\n\n` +
                `• React with <a:giveaway:1362716687895494791> to participate!`
            )
            .setFooter({ text: `Ends` })
            .setTimestamp(endTime);

        const giveawayMessage = await message.channel.send({
            content: '**<a:girl_dance:1362711059374407742> GIVEAWAY STARTED <a:girl_dance:1362711059374407742>**',
            embeds: [embed]
        });

        // Add the reaction
        await giveawayMessage.react('1362716687895494791');

        // Store giveaway data
        const giveawayData = {
            messageId: giveawayMessage.id,
            channelId: message.channel.id,
            guildId: message.guild.id,
            hostId: message.author.id,
            prize: prize,
            winners: winnerCount,
            endTime: endTime,
            entries: [],
            ended: false,
            paused: false,
            type: 'reaction'
        };

        await client.db.set(`giveaway_${giveawayMessage.id}`, giveawayData);

        // Create reaction collector
        const filter = (reaction, user) => reaction.emoji.id === '1362716687895494791' && !user.bot;
        const collector = giveawayMessage.createReactionCollector({ filter, time });

        collector.on('collect', async (reaction, user) => {
            const data = await client.db.get(`giveaway_${giveawayMessage.id}`);
            if (data && !data.entries.includes(user.id)) {
                data.entries.push(user.id);
                await client.db.set(`giveaway_${giveawayMessage.id}`, data);
            }
        });

        collector.on('remove', async (reaction, user) => {
            const data = await client.db.get(`giveaway_${giveawayMessage.id}`);
            if (data && data.entries.includes(user.id)) {
                data.entries = data.entries.filter(id => id !== user.id);
                await client.db.set(`giveaway_${giveawayMessage.id}`, data);
            }
        });

        collector.on('end', async () => {
            await endReactionGiveaway(client, giveawayMessage.id);
        });

        return message.channel.send({
            embeds: [
                new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`${client.emoji.tick} | Reaction giveaway created successfully!`)
            ]
        }).then(msg => {
            setTimeout(() => msg.delete().catch(() => {}), 5000);
        });
    }
};

async function endReactionGiveaway(client, messageId) {
    try {
        const data = await client.db.get(`giveaway_${messageId}`);
        if (!data || data.ended) return;

        const channel = client.channels.cache.get(data.channelId);
        if (!channel) return;

        const message = await channel.messages.fetch(messageId).catch(() => null);
        if (!message) return;

        data.ended = true;
        await client.db.set(`giveaway_${messageId}`, data);

        if (data.entries.length === 0) {
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle(`<a:Gift:1362704453945262221> ${data.prize} <a:Gift:1362704453945262221>`)
                .setDescription(
                    `• **Ended:** <t:${Math.floor(Date.now() / 1000)}:R>\n` +
                    `• **Hosted by:** <@${data.hostId}>\n\n` +
                    `• **Winners:** No valid entries`
                )
                .setFooter({ text: 'Giveaway ended' })
                .setTimestamp();

            return message.edit({ 
                content: '**<a:girl_dance:1362711059374407742> GIVEAWAY ENDED <a:girl_dance:1362711059374407742>**',
                embeds: [embed] 
            });
        }

        // Select random winners
        const winners = [];
        const entries = [...data.entries];
        
        for (let i = 0; i < Math.min(data.winners, entries.length); i++) {
            const randomIndex = Math.floor(Math.random() * entries.length);
            winners.push(entries.splice(randomIndex, 1)[0]);
        }

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle(`<a:Gift:1362704453945262221> ${data.prize} <a:Gift:1362704453945262221>`)
            .setDescription(
                `• **Ended:** <t:${Math.floor(Date.now() / 1000)}:R>\n` +
                `• **Hosted by:** <@${data.hostId}>\n\n` +
                `• **Winners:** ${winners.map(w => `<@${w}>`).join(', ')}`
            )
            .setFooter({ text: 'Giveaway ended' })
            .setTimestamp();

        message.edit({ 
            content: '**<a:girl_dance:1362711059374407742> GIVEAWAY ENDED <a:girl_dance:1362711059374407742>**',
            embeds: [embed] 
        });

        // Announce winners
        channel.send({
            content: `<a:giveaway:1362716687895494791> Congratulations ${winners.map(w => `<@${w}>`).join(', ')}! You won **${data.prize}**!`
        });

    } catch (error) {
        console.error('Error ending reaction giveaway:', error);
    }
}
