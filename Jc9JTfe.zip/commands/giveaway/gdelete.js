const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'gdelete',
    aliases: ['giveaway-delete', 'gremove'],
    category: 'giveaway',
    premium: false,
    cooldown: 3,
    run: async (client, message, args) => {
        if (!message.member.permissions.has('ManageMessages')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | You need \`Manage Messages\` permission to delete giveaways.`)
                ]
            });
        }

        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | Please provide a giveaway message ID.\n\nUsage: \`gdelete <messageId>\``)
                ]
            });
        }

        const messageId = args[0];
        const giveawayData = await client.db.get(`giveaway_${messageId}`);

        if (!giveawayData) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | No giveaway found with that message ID.`)
                ]
            });
        }

        if (giveawayData.hostId !== message.author.id && !message.member.permissions.has('Administrator')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | You can only delete giveaways you created or you need Administrator permission.`)
                ]
            });
        }

        try {
            const channel = client.channels.cache.get(giveawayData.channelId);
            if (channel) {
                const giveawayMessage = await channel.messages.fetch(messageId).catch(() => null);
                if (giveawayMessage) {
                    await giveawayMessage.delete().catch(() => {});
                }
            }

            // Remove from database
            await client.db.delete(`giveaway_${messageId}`);

            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.tick} | Giveaway deleted successfully.`)
                ]
            });

        } catch (error) {
            console.error('Error deleting giveaway:', error);
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | An error occurred while deleting the giveaway.`)
                ]
            });
        }
    }
};