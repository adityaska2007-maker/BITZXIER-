const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'gend',
    aliases: ['giveaway-end', 'gstop'],
    category: 'giveaway',
    premium: false,
    cooldown: 3,
    run: async (client, message, args) => {
        if (!message.member.permissions.has('ManageMessages')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | You need \`Manage Messages\` permission to end giveaways.`)
                ]
            });
        }

        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | Please provide a giveaway message ID.\n\nUsage: \`gend <messageId>\``)
                ]
            });
        }

        const messageId = args[0];
        const giveawayData = await client.db.get(`giveaway_${messageId}`);

        if (!giveawayData) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | No giveaway found with that message ID.`)
                ]
            });
        }

        if (giveawayData.ended) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | This giveaway has already ended.`)
                ]
            });
        }

        if (giveawayData.hostId !== message.author.id && !message.member.permissions.has('Administrator')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | You can only end giveaways you created or you need Administrator permission.`)
                ]
            });
        }

        try {
            const channel = client.channels.cache.get(giveawayData.channelId);
            if (!channel) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color)
                            .setDescription(`${client.emoji.cross} | Giveaway channel not found.`)
                    ]
                });
            }

            const giveawayMessage = await channel.messages.fetch(messageId).catch(() => null);
            if (!giveawayMessage) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color)
                            .setDescription(`${client.emoji.cross} | Giveaway message not found.`)
                    ]
                });
            }

            // Mark as ended
            giveawayData.ended = true;
            await client.db.set(`giveaway_${messageId}`, giveawayData);

            if (giveawayData.entries.length === 0) {
                const embed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('🎉 GIVEAWAY ENDED 🎉')
                    .setDescription(`**Prize:** ${giveawayData.prize}\n**Winners:** No valid entries\n**Hosted by:** <@${giveawayData.hostId}>`)
                    .setFooter({ text: 'Giveaway ended early' })
                    .setTimestamp();

                await giveawayMessage.edit({ embeds: [embed], components: [] });

                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color)
                            .setDescription(`${client.emoji.tick} | Giveaway ended successfully. No winners due to no entries.`)
                    ]
                });
            }

            // Select random winners
            const winners = [];
            const entries = [...giveawayData.entries];
            
            for (let i = 0; i < Math.min(giveawayData.winners, entries.length); i++) {
                const randomIndex = Math.floor(Math.random() * entries.length);
                winners.push(entries.splice(randomIndex, 1)[0]);
            }

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🎉 GIVEAWAY ENDED 🎉')
                .setDescription(`**Prize:** ${giveawayData.prize}\n**Winners:** ${winners.map(w => `<@${w}>`).join(', ')}\n**Hosted by:** <@${giveawayData.hostId}>`)
                .setFooter({ text: 'Giveaway ended early' })
                .setTimestamp();

            await giveawayMessage.edit({ embeds: [embed], components: [] });

            // Announce winners
            await channel.send({
                content: `🎉 Congratulations ${winners.map(w => `<@${w}>`).join(', ')}! You won **${giveawayData.prize}**!`
            });

            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.tick} | Giveaway ended successfully! Winners: ${winners.map(w => `<@${w}>`).join(', ')}`)
                ]
            });

        } catch (error) {
            console.error('Error ending giveaway:', error);
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | An error occurred while ending the giveaway.`)
                ]
            });
        }
    }
};