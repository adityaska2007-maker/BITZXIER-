const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'glist',
    aliases: ['giveaway-list', 'giveaways'],
    category: 'giveaway',
    premium: false,
    cooldown: 5,
    run: async (client, message, args) => {
        if (!message.member.permissions.has('ManageMessages')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | You need \`Manage Messages\` permission to view giveaway list.`)
                ]
            });
        }

        try {
            // Get all giveaway data for this guild
            const allData = await client.db.all();
            const guildGiveaways = allData.filter(item => 
                item.ID.startsWith('giveaway_') && 
                item.data && 
                item.data.guildId === message.guild.id
            );

            if (guildGiveaways.length === 0) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color)
                            .setTitle('🎉 Giveaway List')
                            .setDescription('No giveaways found in this server.')
                            .setTimestamp()
                    ]
                });
            }

            // Separate active and ended giveaways
            const activeGiveaways = guildGiveaways.filter(g => !g.data.ended && !g.data.paused);
            const pausedGiveaways = guildGiveaways.filter(g => !g.data.ended && g.data.paused);
            const endedGiveaways = guildGiveaways.filter(g => g.data.ended);

            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('🎉 Giveaway List')
                .setTimestamp();

            // Add active giveaways
            if (activeGiveaways.length > 0) {
                const activeList = activeGiveaways.slice(0, 5).map(g => {
                    const endTime = Math.floor(g.data.endTime / 1000);
                    return `**${g.data.prize}** - <#${g.data.channelId}>\nEnds: <t:${endTime}:R> | Entries: ${g.data.entries.length}\nID: \`${g.data.messageId}\``;
                }).join('\n\n');

                embed.addFields({
                    name: `🟢 Active Giveaways (${activeGiveaways.length})`,
                    value: activeList + (activeGiveaways.length > 5 ? `\n\n*... and ${activeGiveaways.length - 5} more*` : ''),
                    inline: false
                });
            }

            // Add paused giveaways
            if (pausedGiveaways.length > 0) {
                const pausedList = pausedGiveaways.slice(0, 3).map(g => {
                    const endTime = Math.floor(g.data.endTime / 1000);
                    return `**${g.data.prize}** - <#${g.data.channelId}>\nWas ending: <t:${endTime}:R> | Entries: ${g.data.entries.length}\nID: \`${g.data.messageId}\``;
                }).join('\n\n');

                embed.addFields({
                    name: `⏸️ Paused Giveaways (${pausedGiveaways.length})`,
                    value: pausedList + (pausedGiveaways.length > 3 ? `\n\n*... and ${pausedGiveaways.length - 3} more*` : ''),
                    inline: false
                });
            }

            // Add recent ended giveaways
            if (endedGiveaways.length > 0) {
                const recentEnded = endedGiveaways
                    .sort((a, b) => b.data.endTime - a.data.endTime)
                    .slice(0, 3)
                    .map(g => {
                        const endTime = Math.floor(g.data.endTime / 1000);
                        return `**${g.data.prize}** - <#${g.data.channelId}>\nEnded: <t:${endTime}:R> | Entries: ${g.data.entries.length}\nID: \`${g.data.messageId}\``;
                    }).join('\n\n');

                embed.addFields({
                    name: `🔴 Recent Ended Giveaways (${endedGiveaways.length} total)`,
                    value: recentEnded + (endedGiveaways.length > 3 ? `\n\n*... and ${endedGiveaways.length - 3} more*` : ''),
                    inline: false
                });
            }

            embed.setFooter({ 
                text: `Total: ${guildGiveaways.length} giveaways | Use ginfo <messageId> for details` 
            });

            return message.channel.send({ embeds: [embed] });

        } catch (error) {
            console.error('Error listing giveaways:', error);
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | An error occurred while fetching giveaway list.`)
                ]
            });
        }
    }
};