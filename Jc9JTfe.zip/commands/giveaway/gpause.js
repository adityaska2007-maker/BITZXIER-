const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'gpause',
    aliases: ['giveaway-pause'],
    category: 'giveaway',
    premium: false,
    cooldown: 3,
    run: async (client, message, args) => {
        if (!message.member.permissions.has('ManageMessages')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | You need \`Manage Messages\` permission to pause giveaways.`)
                ]
            });
        }

        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | Please provide a giveaway message ID.\n\nUsage: \`gpause <messageId>\``)
                ]
            });
        }

        const messageId = args[0];
        const giveawayData = await client.db.get(`giveaway_${messageId}`);

        if (!giveawayData) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | No giveaway found with that message ID.`)
                ]
            });
        }

        if (giveawayData.ended) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | This giveaway has already ended.`)
                ]
            });
        }

        if (giveawayData.paused) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | This giveaway is already paused.`)
                ]
            });
        }

        if (giveawayData.hostId !== message.author.id && !message.member.permissions.has('Administrator')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | You can only pause giveaways you created or you need Administrator permission.`)
                ]
            });
        }

        try {
            const channel = client.channels.cache.get(giveawayData.channelId);
            if (!channel) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color)
                            .setDescription(`${client.emoji.cross} | Giveaway channel not found.`)
                    ]
                });
            }

            const giveawayMessage = await channel.messages.fetch(messageId).catch(() => null);
            if (!giveawayMessage) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color)
                            .setDescription(`${client.emoji.cross} | Giveaway message not found.`)
                    ]
                });
            }

            // Mark as paused
            giveawayData.paused = true;
            await client.db.set(`giveaway_${messageId}`, giveawayData);

            // Update the embed to show paused status
            const embed = new EmbedBuilder()
                .setColor('#ffaa00')
                .setTitle('⏸️ GIVEAWAY PAUSED ⏸️')
                .setDescription(`**Prize:** ${giveawayData.prize}\n**Winners:** ${giveawayData.winners}\n**Was ending:** <t:${Math.floor(giveawayData.endTime / 1000)}:R>\n**Hosted by:** <@${giveawayData.hostId}>`)
                .setFooter({ text: `Giveaway ID: ${giveawayData.messageId} | PAUSED` })
                .setTimestamp();

            await giveawayMessage.edit({ embeds: [embed], components: [] });

            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.tick} | Giveaway paused successfully.`)
                ]
            });

        } catch (error) {
            console.error('Error pausing giveaway:', error);
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(`${client.emoji.cross} | An error occurred while pausing the giveaway.`)
                ]
            });
        }
    }
};