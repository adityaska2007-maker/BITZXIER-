const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: '8ball',
    category: 'fun',
    description: 'Ask the magic 8ball a question and receive mysterious answers',
    run: async (client, message, args) => {
        if (!args.length) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`<:cross:1387502959444758580> Please ask a question to the magic 8ball!`)]
            });
        }
        
        // Get the question from arguments
        const question = args.join(' ');
        
        // Create initial "thinking" embed with animation effect
        const thinkingEmbed = new EmbedBuilder()
            .setColor('#9966CC') // Purple for mystical effect
            .setTitle(`${client.emoji.time} The Magic 8Ball is thinking...`)
            .setDescription(`${client.emoji.member} **${message.author.username}** asked:\n*"${question}"*\n\nShaking the 8ball...`)
            .setFooter({ text: 'Consulting the cosmic forces...' });
            
        const msg = await message.channel.send({ embeds: [thinkingEmbed] });
        
        // Set up a short animation sequence
        setTimeout(() => {
            const shakingEmbed = new EmbedBuilder()
                .setColor('#9966CC')
                .setTitle(`${client.emoji.time} The Magic 8Ball is vibrating...`)
                .setDescription(`${client.emoji.member} **${message.author.username}** asked:\n*"${question}"*\n\nThe answer is becoming clear...`)
                .setFooter({ text: 'The mystical energies are aligning...' });
                
            msg.edit({ embeds: [shakingEmbed] });
            
            // Define possible responses with categories and thematic emojis
            const responses = [
                // Positive answers (0-9)
                { text: "It is certain.", emoji: client.emoji.tick },
                { text: "It is decidedly so.", emoji: client.emoji.tick },
                { text: "Without a doubt.", emoji: client.emoji.tick },
                { text: "Yes definitely.", emoji: client.emoji.tick },
                { text: "You may rely on it.", emoji: client.emoji.tick },
                { text: "As I see it, yes.", emoji: client.emoji.tick },
                { text: "Most likely.", emoji: client.emoji.tick },
                { text: "Outlook good.", emoji: client.emoji.tick },
                { text: "Yes.", emoji: client.emoji.tick },
                { text: "Signs point to yes.", emoji: client.emoji.tick },
                
                // Neutral answers (10-14)
                { text: "Reply hazy, try again.", emoji: client.emoji.warning },
                { text: "Ask again later.", emoji: client.emoji.warning },
                { text: "Better not tell you now.", emoji: client.emoji.warning },
                { text: "Cannot predict now.", emoji: client.emoji.warning },
                { text: "Concentrate and ask again.", emoji: client.emoji.warning },
                
                // Negative answers (15-19)
                { text: "Don't count on it.", emoji: '<:cross:1387502959444758580>' },
                { text: "My reply is no.", emoji: '<:cross:1387502959444758580>' },
                { text: "My sources say no.", emoji: '<:cross:1387502959444758580>' },
                { text: "Outlook not so good.", emoji: '<:cross:1387502959444758580>' },
                { text: "Very doubtful.", emoji: '<:cross:1387502959444758580>' }
            ];
            
            // Select a random response
            const responseIndex = Math.floor(Math.random() * responses.length);
            const response = responses[responseIndex];
            
            // Final reveal after a delay
            setTimeout(() => {
                // Determine response type and theming
                let responseType, color, title;
                
                if (responseIndex < 10) {
                    responseType = 'Positive';
                    color = '#00FF00'; // Green for positive
                    title = `${client.emoji.success} The Magic 8Ball Predicts Success!`;
                } else if (responseIndex < 15) {
                    responseType = 'Uncertain';
                    color = '#FFFF00'; // Yellow for neutral
                    title = `${client.emoji.warning} The Magic 8Ball Is Uncertain...`;
                } else {
                    responseType = 'Negative';
                    color = '#FF0000'; // Red for negative
                    title = `${client.emoji.cross} The Magic 8Ball Advises Caution!`;
                }
                
                // Format the response with the appropriate emoji
                const formattedResponse = `${response.emoji} **${response.text}**`;
                
                // Add some flavor text based on the response type
                let flavorText;
                if (responseType === 'Positive') {
                    flavorText = [
                        "The cosmic energies are aligned in your favor!",
                        "Fortune smiles upon this query!",
                        "The stars predict a favorable outcome!",
                        "The spirit realm nods in agreement!"
                    ][Math.floor(Math.random() * 4)];
                } else if (responseType === 'Uncertain') {
                    flavorText = [
                        "The mists of fate are still swirling...",
                        "The cosmic balance is in flux for this question.",
                        "The answer is shrouded in mystery for now.",
                        "The spirits are undecided on this matter."
                    ][Math.floor(Math.random() * 4)];
                } else {
                    flavorText = [
                        "The omens do not favor this path.",
                        "The mystical signs point to challenges ahead.",
                        "The cosmic vibrations sense obstacles in your way.",
                        "The ethereal whispers bring words of caution."
                    ][Math.floor(Math.random() * 4)];
                }
                
                // Create the final prediction embed
                const predictionEmbed = new EmbedBuilder()
                    .setColor(color)
                    .setTitle(title)
                    .setDescription(`${client.emoji.member} **${message.author.username}** asked:\n*"${question}"*\n\n${formattedResponse}\n\n*${flavorText}*`)
                    .setFooter({ text: `The mystical 8ball has spoken • Try again with ${message.guild.prefix || '!'}8ball [question]`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
                    .setTimestamp();
                    
                msg.edit({ embeds: [predictionEmbed] });
            }, 2000);
        }, 1500);
    }
};