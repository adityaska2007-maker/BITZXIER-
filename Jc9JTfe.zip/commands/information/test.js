const { EmbedBuilder } = require('discord.js')

module.exports = {
    name: 'test',
    aliases: ['t'],
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        return message.channel.send({
            embeds: [
                new EmbedBuilder()
                    .setColor('#00FF00')
                    .setDescription('✅ Test command working! Bot is responding to commands.')
            ]
        })
    }
}