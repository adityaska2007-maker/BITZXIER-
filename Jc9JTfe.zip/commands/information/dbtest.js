
const { EmbedBuilder } = require('discord.js')

module.exports = {
    name: 'dbtest',
    aliases: ['testdb'],
    category: 'information',
    premium: false,
    run: async (client, message, args) => {
        try {
            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('Database Test')
            
            // Test MongoDB connection
            let mongoStatus = '❌ Not Connected'
            try {
                if (client.db && client.db.ready) {
                    await client.db.set('test_key', 'test_value')
                    const testValue = await client.db.get('test_key')
                    if (testValue === 'test_value') {
                        mongoStatus = '✅ Connected & Working'
                        await client.db.delete('test_key')
                    }
                }
            } catch (error) {
                mongoStatus = `❌ Error: ${error.message}`
            }
            
            embed.addField('MongoDB Status', mongoStatus, false)
            embed.addField('Bot Status', '✅ Online', false)
            embed.setTimestamp()
            
            await message.channel.send({ embeds: [embed] })
        } catch (error) {
            console.error('Database test error:', error)
            message.channel.send('❌ An error occurred while testing the database.').catch(() => {})
        }
    }
}
