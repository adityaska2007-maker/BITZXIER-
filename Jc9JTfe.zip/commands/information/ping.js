const { EmbedBuilder } = require('discord.js')

module.exports = {
    name: 'ping',
    aliases: ['latency'],
    category: 'information',
    premium: false,
    run: async (client, message, args) => {
        try {
            // High-precision timing
            const start = process.hrtime.bigint()
            const msg = await message.channel.send('Pinging...')
            const end = process.hrtime.bigint()
            
            // Convert nanoseconds to milliseconds with high precision
            const latency = Math.round(Number(end - start) / 1000000)
            
            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setFooter({ text: `Pong | ${latency}ms` })

            await msg.edit({ content: null, embeds: [embed] })
        } catch (error) {
            console.error('Ping command error:', error)
            message.channel.send('An error occurred while executing the ping command.').catch(() => {})
        }
    }
}