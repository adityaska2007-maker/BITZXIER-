const { EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js')
const moment = require('moment')
const os = require('os')
module.exports = {
    name: 'stats',
    category: 'info',
    aliases: ['botinfo', 'bi'],
    usage: 'stats',
    run: async (client, message, args) => {
        let button = new ButtonBuilder()
            .setLabel('Team Info')
            .setCustomId('team')
            .setStyle(2)
        let button1 = new ButtonBuilder()
            .setLabel('General Info')
            .setCustomId('general')
            .setStyle(2)
            .setDisabled(true)
        let button2 = new ButtonBuilder()
            .setLabel('System Info')
            .setCustomId('system')
            .setStyle(2)
        let button3 = new ButtonBuilder()
            .setLabel('Partners ')
            .setCustomId('partners')
            .setStyle(2)
        const row = new ActionRowBuilder().addComponents([
            button,
            button1,
            button2,
            button3
        ])
        const uptime = Math.round(Date.now() - client.uptime)
        let guilds1 = client.guilds.cache.size
        let member1 = client.guilds.cache.reduce((x, y) => x + y.memberCount, 0)
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setAuthor({
                name: 'BITZXIER Informations',
                iconURL: client.user.displayAvatarURL({ dynamic: true })
            })
            .setDescription(
                `**__General Informations__**\nBot's Mention: <@!${
                    client.user.id
                }>\nBot's Tag: ${
                    client.user.tag
                }\nBot's Version: Discord.js v${require('discord.js').version.split('.')[0]}\nTotal Servers: ${guilds1}\nTotal Users: ${member1} (${
                    client.users.cache.size
                } Cached)\nTotal Channels: ${
                    client.channels.cache.size
                }\nLast Rebooted: ${moment(uptime).fromNow()}`
            )
            .setThumbnail(client.user.displayAvatarURL())
            .setFooter({
                text: `Requested By ${message.author.tag}`,
                iconURL: message.author.displayAvatarURL({ dynamic: true })
            })
        let msg = await message.channel.send(
            { embeds: [embed], components: [row] },
            message
        )

        const collector = msg.createMessageComponentCollector({
            filter: (i) => i.user && i.isButton(),
            time: 60000
        })
        collector.on('collect', async (i) => {
            if (i.user.id !== message.author.id)
                return i.reply({
                    content: "> This isn't for you.",
                    ephemeral: true
                })
            if (i.isButton()) {
                if (i.customId == 'partners') {
                    i.deferUpdate()
                    const em = new EmbedBuilder()
                        .setColor(client.color)
                        .setAuthor({
                            name: "BITZXIER Partnership",
                            iconURL: client.user.displayAvatarURL()
                        })
                        .setDescription(
                            `If you're interested in partnering with us,\nplease contact the bot owners directly.\n\n[SUPPORT SERVER](https://discord.gg/bMY4UA6fs9)`
                        )
                        .setFooter({
                            text: `Partnership inquiries welcome`,
                            iconURL: client.user.displayAvatarURL()
                        })
                    button = button.setDisabled(false)
                    button1 = button1.setDisabled(false)
                    button2 = button2.setDisabled(false)
                    button3 = button3.setDisabled(true)
                    const row1 = new ActionRowBuilder().addComponents([
                        button,
                        button1,
                        button2,
                        button3
                    ])
                    if (msg)
                        return msg.edit(
                            { embeds: [em], components: [row1] },
                            message,
                            msg
                        )
                }
                if (i.customId == 'team') {
                    i.deferUpdate()
                    const em = new EmbedBuilder()
                        .setDescription(
                            `**__Developers__**\n[\`1\`] [Predator](https://discord.gg/users/1066827447129088111)\n\n**__Core Team__**\n[\`1\`] [Predator](https://discord.gg/users/1066827447129088111)\n\n**__Contributors__**\n[\`1\`] [Predator](https://discord.gg/users/1066827447129088111)`
                        )
                        .setColor(client.color)
                        .setAuthor({
                            name: 'BITZXIER Informations',
                            iconURL: client.user.displayAvatarURL({ dynamic: true })
                        })
                        .setFooter({
                            text: `Requested By ${message.author.tag}`,
                            iconURL: message.author.displayAvatarURL({
                                dynamic: true
                            })
                        })
                        .setThumbnail(client.user.displayAvatarURL())
                    button = button.setDisabled(true)
                    button1 = button1.setDisabled(false)
                    button2 = button2.setDisabled(false)
                    button3 = button3.setDisabled(false)
                    const row1 = new ActionRowBuilder().addComponents([
                        button,
                        button1,
                        button2,
                        button3
                    ])
                    if (msg)
                        return msg.edit(
                            { embeds: [em], components: [row1] },
                            message,
                            msg
                        )
                }
                if (i.customId == 'general') {
                    i.deferUpdate()
                    let member = client.guilds.cache.reduce(
                        (x, y) => x + y.memberCount,
                        0
                    )
                    if (member >= 1000 && member < 1000000)
                        member = (member / 1000).toFixed(1) + 'k'
                    else if (member >= 1000000)
                        member = (member / 1000000).toFixed(1) + 'm'
                    else member1 = member1
                    let guilds = client.guilds.cache.size
                    const embed = new EmbedBuilder()
                        .setColor(client.color)
                        .setAuthor({
                            name: 'BITZXIER Informations',
                            iconURL: client.user.displayAvatarURL({ dynamic: true })
                        })
                        .setDescription(
                            `**__General Informations__**\nBot's Mention: <@!${
                                client.user.id
                            }>\nBot's Tag: ${client.user.tag}\nBot's Version: Discord.js v${
                               require('discord.js').version.split('.')[0]
                            }\nTotal Servers: ${guilds}\nTotal Users: ${member} (${
                                client.users.cache.size
                            } Cached)\nTotal Channels: ${
                                client.channels.cache.size
                            }\nLast Rebooted: ${moment(uptime).fromNow()}`
                        )
                        .setThumbnail(client.user.displayAvatarURL())
                        .setFooter({
                            text: `Requested By ${message.author.tag}`,
                            iconURL: message.author.displayAvatarURL({
                                dynamic: true
                            })
                        })
                    button = button.setDisabled(false)
                    button1 = button1.setDisabled(true)
                    button2 = button2.setDisabled(false)
                    button3 = button3.setDisabled(false)
                    const row1 = new ActionRowBuilder().addComponents([
                        button,
                        button1,
                        button2,
                        button3
                    ])
                    if (msg)
                        return msg.edit(
                            { embeds: [embed], components: [row1] },
                            message,
                            msg
                        )
                }
                if (i.customId == 'system') {
                    i.deferUpdate()
                    if (msg)
                        msg.edit({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor(client.color)
                                    .setAuthor({
                                        name: 'BITZXIER Informations',
                                        iconURL: client.user.displayAvatarURL({ dynamic: true })
                                    })
                                    .setFooter({
                                        text: `Requested By ${message.author.tag}`,
                                        iconURL:
                                            message.author.displayAvatarURL({
                                                dynamic: true
                                            })
                                    })
                                    .setDescription(
                                        '⚙️ | **Fetching** all the **resources**...'
                                    )
                            ]
                        })
                    const totalMemoryBytes = os.totalmem()
                    const cpuCount = os.cpus().length
                    const freeMemoryBytes = os.freemem()
                    const memoryUsageBytes = totalMemoryBytes - freeMemoryBytes

                    let totalMemoryGB = totalMemoryBytes / (1024 * 1024 * 1024)
                    let memoryUsageGB = memoryUsageBytes / (1024 * 1024 * 1024)

                    if (
                        totalMemoryGB >=
                        totalMemoryBytes / (1024 * 1024 * 1024)
                    )
                        totalMemoryGB = totalMemoryGB.toFixed(2) + ' GB'
                    else
                        totalMemoryGB =
                            (totalMemoryBytes / (1024 * 1024)).toFixed(2) +
                            ' MB'

                    if (
                        memoryUsageGB >=
                        memoryUsageBytes / (1024 * 1024 * 1024)
                    )
                        memoryUsageGB = memoryUsageGB.toFixed(2) + ' GB'
                    else
                        memoryUsageGB =
                            memoryUsageBytes / (1024 * 1024).toFixed(2) + ' MB'

                    const processors = os.cpus()

                    const cpuUsage1 = os.cpus()[0].times
                    const startUsage1 =
                        cpuUsage1.user +
                        cpuUsage1.nice +
                        cpuUsage1.sys +
                        cpuUsage1.irq
                    let cpuUsage2
                    setTimeout(async () => {
                        cpuUsage2 = os.cpus()[0].times
                        const endUsage1 =
                            cpuUsage2?.user +
                            cpuUsage2?.nice +
                            cpuUsage2?.sys +
                            cpuUsage2?.irq

                        const totalUsage = endUsage1 - startUsage1

                        let idleUsage = 0
                        let totalIdle = 0

                        for (let i = 0; i < cpuCount; i++) {
                            const cpuUsage = os.cpus()[i].times
                            totalIdle += cpuUsage.idle
                        }

                        idleUsage =
                            totalIdle - (cpuUsage2.idle - cpuUsage1.idle)
                        const cpuUsagePercentage =
                            (totalUsage / (totalUsage + idleUsage)) * 100
                             const startTime = process.cpuUsage();
const endTime = process.cpuUsage();
const usedTime = endTime.user - startTime.user + endTime.system - startTime.system;
                        const ping = await client?.db?.ping()
                        const embed1 = new EmbedBuilder()
                            .setColor(client.color)
                            .setAuthor({
                                name: 'BITZXIER Informations',
                                iconURL: client.user.displayAvatarURL({ dynamic: true })
                            })
                            .setDescription(
                                `**__System Informations__**\nSystem Latency: ${
                                    client.ws.ping
                                }ms\nPlatform: ${
                                    process.platform
                                }\nArchitecture: ${
                                    process.arch
                                }\nMemory Usage: ${memoryUsageGB}/${totalMemoryGB}\nProcessor 1:\n> Model: ${
                                    processors[0].model
                                }\n> Speed: ${
                                    processors[0].speed
                                } MHz\nTimes:\n> User: ${
                                    cpuUsage2.user
                                } ms\n> Nice: ${cpuUsage2.nice} ms\n> Sys: ${
                                    cpuUsage2.sys
                                } ms\n> Idle: ${cpuUsage2.idle} ms\n> IRQ: ${
                                    cpuUsage2.irq
                                } ms\nDatabase Latency: ${
                                    ping?.toFixed(2) || '0'
                                }ms`
                            )
                            .setThumbnail(client.user.displayAvatarURL())
                            .setFooter({
                                text: `Requested By ${message.author.tag}`,
                                iconURL: message.author.displayAvatarURL({
                                    dynamic: true
                                })
                            })
                        button = button.setDisabled(false)
                        button1 = button1.setDisabled(false)
                        button2 = button2.setDisabled(true)
                        button3 = button3.setDisabled(false)
                        const row1 = new ActionRowBuilder().addComponents([
                            button,
                            button1,
                            button2,
                            button3
                        ])
                        if (msg)
                            return msg.edit(
                                { embeds: [embed1], components: [row1] },
                                message,
                                msg
                            )
                    }, 2000)
                }
            }
        })
        collector.on('end', () => {
            if (msg) {
                button = button.setDisabled(true)
                button1 = button1.setDisabled(true)
                button2 = button2.setDisabled(true)
                button3 = button3.setDisabled(true)
                const row1 = new ActionRowBuilder().addComponents([
                    button,
                    button1,
                    button2,
                    button3
                ])
                return msg.edit({ components: [row1] })
            }
        })
    }
}