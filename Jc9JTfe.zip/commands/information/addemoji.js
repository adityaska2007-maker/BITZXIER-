const { Message, Client, EmbedBuilder } = require('discord.js')

module.exports = {
    name: 'addemoji',
    aliases: ['addemote', 'steal'],
    cooldown: 5,
    category: 'info',
    run: async (client, message, args) => {
        if (!message.member.permissions.has('MANAGE_EMOJIS_AND_STICKERS')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(
                            `<:cross:1387502959444758580> | You must have \`Manage Emoji\` perms to use this command.`
                        )
                ]
            })
        }
        if (!message.guild.members.me.permissions.has('MANAGE_EMOJIS_AND_STICKERS')) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(
                            `<:cross:1387502959444758580> | I must have \`Manage Emoji\` perms to use this command.`
                        )
                ]
            })
        }
        let emoji = args[0]
        if (!emoji) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(
                            `<:cross:1387502959444758580> | You didn't provided any emoji to add.`
                        )
                ]
            })
        }
        let emojiId = null
        try {
            emojiId = emoji.match(/([0-9]+)/)[0]
        } catch (err) {}
        if (!emojiId) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(
                            `<:cross:1387502959444758580> | You provided an invalid emoji.`
                        )
                ]
            })
        }
        let name = args[1] || 'stolen_emoji'
        let link = `https://cdn.discordapp.com/emojis/${emojiId}`
        try {
            await message.guild.emojis.create(link, name).then((newEmoji) => {
                message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color)
                            .setDescription(
                                `<:tick:1387502929115877436> | Successfully added the emoji ${newEmoji.toString()}.`
                            )
                    ]
                })
            })
        } catch (err) {
            message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color)
                        .setDescription(
                            `<:cross:1387502959444758580> | I was unable to add the emoji.\nPossible Reasons: \`Mass emojis added\`, \`Slots are Full\`.`
                        )
                ]
            })
        }
    }
}
