const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'help',
    aliases: ['h'],
    category: 'information',
    premium: false,
    cooldown: 3, // Prevent spam
    run: async (client, message, args) => {
        const prefix = message.guild?.prefix || '&'; // Default prefix if not set

        // Embed message
        const embed = new EmbedBuilder()
            .setColor(client.color) // Red color for the embed
            .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .setDescription(
                `Hello! I'm ${client.user.username}, your server security bot with powerful Antinuke features.\n\nPrefix for this server \`${prefix}\`\nTotal Commands: \`${client.commands.size}\`\n Type \`${prefix}antinuke enable\``
            )
            .addFields([
                {
                    name: '__Main Modules__',
                    value: `${client.emoji.shield} **AntiNuke**\n${client.emoji.mod} **Moderation**\n${client.emoji.info} **Logging**\n${client.emoji.util} **Utility**\n${client.emoji.member} **Welcomer**`,
                    inline: true
                },
                {
                    name: '__Extra Modules__',
                    value: `${client.emoji.vc} **Voice**\n${client.emoji.settings} **Custom Role**\n${client.emoji.automod} **Automod**\n${client.emoji.reply} **Autoresponder**\n${client.emoji.trophy} **Giveaway**\n${client.emoji.games} **Fun**`,
                    inline: true
                },
                {
                    name: '**Links**',
                    value: `[Support](https://discord.gg/4ZKhqpFze8) **|** [Invite Me](https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot)`,
                    inline: false
                }
            ])
            .setTimestamp();

        // Create action row with buttons (removed home button)
        const actionRow = new ActionRowBuilder();

        // First dropdown menu (Main categories)
        const selectMenu1 = new StringSelectMenuBuilder()
            .setCustomId('categorySelect1')
            .setPlaceholder('BITZXIER Get Started')
            .addOptions([
                {
                    label: 'Home',
                    value: 'home',
                    description: 'Return to the help menu',
                    emoji: client.emoji.home
                },
                {
                    label: 'All Commands',
                    value: 'all',
                    description: 'Show all commands',
                    emoji: client.emoji.search
                },
                {
                    label: 'AntiNuke',
                    value: 'antinuke',
                    description: 'Commands related to AntiNuke',
                    emoji: client.emoji.shield
                },
                {
                    label: 'Moderation',
                    value: 'mod',
                    description: 'Commands related to Moderation',
                    emoji: client.emoji.mod
                },
                {
                    label: 'Logging',
                    value: 'logging',
                    description: 'Commands for Logging',
                    emoji: client.emoji.info
                },
                {
                    label: 'Utility',
                    value: 'info',
                    description: 'Utility commands',
                    emoji: client.emoji.util
                },
                {
                    label: 'Welcomer',
                    value: 'welcomer',
                    description: 'Commands for Welcomer',
                    emoji: client.emoji.member
                }
            ]);

        // Second dropdown menu (Extra categories)
        const selectMenu2 = new StringSelectMenuBuilder()
            .setCustomId('categorySelect2')
            .setPlaceholder('BITZXIER Get Started')
            .addOptions([
                {
                    label: 'Voice',
                    value: 'voice',
                    description: 'Commands related to Voice',
                    emoji: client.emoji.vc
                },
                {
                    label: 'Custom Role',
                    value: 'customrole',
                    description: 'Commands for Custom Roles',
                    emoji: client.emoji.settings
                },
                {
                    label: 'Automod',
                    value: 'automod',
                    description: 'Commands for Automod',
                    emoji: client.emoji.automod
                },
                {
                    label: 'Autoresponder',
                    value: 'autoresponder',
                    description: 'Commands for Autoresponder',
                    emoji: client.emoji.reply
                },
                {
                    label: 'Giveaway',
                    value: 'giveaway',
                    description: 'Commands for Giveaway',
                    emoji: client.emoji.trophy
                },
                {
                    label: 'Fun',
                    value: 'fun',
                    description: 'Fun commands',
                    emoji: client.emoji.games
                }
            ]);

        // Send the initial help message
        const helpMessage = await message.channel.send({
            embeds: [embed],
            components: [
                new ActionRowBuilder().addComponents(selectMenu1),
                new ActionRowBuilder().addComponents(selectMenu2)
            ]
        });

        // Component collector for interactions
        const collector = helpMessage.createMessageComponentCollector({
            filter: (i) => i.user.id === message.author.id,
            time: 300000 // 5 minutes
        });

        collector.on('collect', async (i) => {
            if (i.values?.[0] === 'home') {
                await i.deferUpdate();
                return helpMessage.edit({
                    embeds: [embed],
                    components: [
                        new ActionRowBuilder().addComponents(selectMenu1),
                        new ActionRowBuilder().addComponents(selectMenu2)
                    ]
                });
            }

            await i.deferUpdate();

            const category = i.values[0];
            let commands = [];

            if (category === 'all') {
                commands = client.commands.map((x) => `\`${x.name}\``);
            } else {
                const categoryMap = {
                    antinuke: 'antinuke',
                    mod: 'moderation',
                    info: 'information',
                    welcomer: 'welcomer',
                    voice: 'voice',
                    automod: 'automod',
                    customrole: 'coustomrole',
                    logging: 'logs',
                    premium: 'premium',
                    autoresponder: 'autoresponder',
                    giveaway: 'giveaway',
                    fun: 'fun'
                };
                const filteredCategory = categoryMap[category];
                
                if (category === 'antinuke') {
                    commands = [
                        '`antinuke`', '`antinuke enable`', '`antinuke disable`',
                        '`whitelist`', '`whitelist add @user`', '`whitelist remove @user`',
                        '`whitelisted`', '`extraowner`', '`extraowner add @user`',
                        '`extraowner remove @user`', '`mainrole`', '`nightmode`',
                        '`unwhitelist @user`', '`whitelistreset`'
                    ];
                } else if (category === 'autoresponder') {
                    commands = [
                        '`autoreactor`', '`autoreactor add #channel <emoji>`',
                        '`autoreactor remove #channel`', '`autoreactor user @user <emoji>`',
                        '`autoreactor keyword <word> <emoji>`', '`autoresponder`',
                        '`autoresponder create keyword <word> <response>`',
                        '`autoresponder create user @user <response>`',
                        '`autoresponder create channel #channel <response>`',
                        '`autoresponder delete <id>`', '`autoresponder list`'
                    ];
                } else if (category === 'logging') {
                    commands = [
                        '`autologs`', '`logall enable`', '`logall disable`',
                        '`modlog #channel`', '`memberlog #channel`', '`messagelog #channel`',
                        '`channellog #channel`', '`rolelog #channel`', '`vclogs #channel`',
                        '`showlogs`', '`resetlogs`'
                    ];
                } else if (category === 'fun') {
                    commands = [
                        '`8ball <question>`', '`coinflip`', '`dice`', '`joke`',
                        '`meme`', '`quote`', '`fact`', '`riddle`',
                        '`compliment @user`', '`roast @user`'
                    ];
                } else if (category === 'giveaway') {
                    commands = [
                        '`gcreate`', '`gcreate <time> <winners> <prize>`',
                        '`gend <messageId>`', '`greroll <messageId>`', '`glist`',
                        '`gdelete <messageId>`', '`gpause <messageId>`', '`gresume <messageId>`'
                    ];
                } else {
                    commands = client.commands
                        .filter((x) => x.category === filteredCategory)
                        .map((x) => `\`${x.name}\``);
                }
            }

            const categoryEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL() })
                .setDescription(
                    `**${category.charAt(0).toUpperCase() + category.slice(1)} Commands**\n${commands.join(', ') || 'No commands found in this category'}`
                );

            helpMessage.edit({
                embeds: [categoryEmbed],
                components: [
                    new ActionRowBuilder().addComponents(selectMenu1),
                    new ActionRowBuilder().addComponents(selectMenu2)
                ]
            });
        });

        collector.on('end', () => {
            helpMessage.edit({
                components: []
            }).catch(() => {});
        });
    }
}