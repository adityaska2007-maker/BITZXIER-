const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'autoreactor',
    aliases: ['ar', 'autoreact'],
    category: 'autoresponder',
    premium: false,
    run: async (client, message, args) => {
        if (!message.member.permissions.has('Administrator')) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> You need Administrator permission to use this command.')
                ]
            });
        }

        const subcommand = args[0]?.toLowerCase();
        
        // Handle simple syntax: autoreact @user <emoji>
        if (args[0] && args[0].match(/^<@!?(\d+)>$/)) {
            const target = getUserFromMention(message, args[0]);
            const emoji = args[1];
            
            if (!target) {
                return message.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#FF0000')
                            .setDescription('<:cross:1387502959444758580> Please mention a valid user.')
                    ]
                });
            }
            
            if (!emoji) {
                return message.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#FF0000')
                            .setDescription('<:cross:1387502959444758580> Please provide an emoji.')
                    ]
                });
            }
            
            // Test if emoji is valid
            try {
                await message.react(emoji);
                await message.reactions.cache.get(emoji)?.users.remove(client.user.id);
            } catch (error) {
                return message.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#FF0000')
                            .setDescription('<:cross:1387502959444758580> Invalid emoji. Please use a valid emoji.')
                    ]
                });
            }
            
            // Create autoreactor data
            const autoreactor = {
                type: 'user',
                target: target.id,
                emoji: emoji,
                mode: null,
                keyword: null,
                createdBy: message.author.id,
                createdAt: new Date()
            };
            
            const key = `${message.guild.id}_autoreactor_user_${target.id}`;
            await client.db.set(key, autoreactor);
            
            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('<:tick:1387502929115877436> AutoReactor Created')
                .setDescription(`**Type:** user\n**Target:** ${target}\n**Emoji:** ${emoji}`)
                .setFooter({
                    text: `Created by ${message.author.tag}`
                });
            
            return message.reply({ embeds: [embed] });
        }
        
        if (!subcommand) {
            return showHelp(message, client);
        }

        switch (subcommand) {
            case 'create':
                return handleCreate(client, message, args);
            case 'remove':
                return handleRemove(client, message, args);
            case 'list':
                return handleList(client, message, args);
            case 'reset':
                return handleReset(client, message, args);
            default:
                return showHelp(message, client);
        }
    }
};

async function showHelp(message, client) {
    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('AutoReactor Module')
        .setDescription('Simple syntax: `autoreact @user <emoji>` - React to messages from specific users.\n\nAdvanced usage available with subcommands:')
        .addFields(
            {
                name: 'Create Auto-Reactions',
                value: '`create channel <#channel> <emoji>`\n`create user <@user> <emoji>`\n`create role <@role> <emoji>`\n`create keyword <include|exact> <keyword> <emoji>`',
                inline: false
            },
            {
                name: 'Remove Auto-Reactions',
                value: '`remove channel <#channel>`\n`remove user <@user>`\n`remove role <@role>`\n`remove keyword <keyword>`',
                inline: false
            },
            {
                name: 'List Auto-Reactions',
                value: '`list channels` - Show channel reactions\n`list users` - Show user reactions\n`list roles` - Show role reactions\n`list keywords` - Show keyword reactions\n`list all` - Show all reactions',
                inline: false
            },
            {
                name: 'Reset Auto-Reactions',
                value: '`reset channels` - Clear channel reactions\n`reset users` - Clear user reactions\n`reset roles` - Clear role reactions\n`reset keywords` - Clear keyword reactions\n`reset all` - Clear all reactions',
                inline: false
            }
        )
        .setFooter({
            text: `Developed by ${client.user.username} Development`
        });

    return message.reply({ embeds: [embed] });
}

async function handleCreate(client, message, args) {
    const type = args[1]?.toLowerCase();
    if (!['channel', 'user', 'role', 'keyword'].includes(type)) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Invalid type. Use: `channel`, `user`, `role`, or `keyword`.')
            ]
        });
    }

    let target, emoji, mode, keyword;
    
    if (type === 'channel') {
        target = getChannelFromMention(message, args[2]);
        if (!target) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a valid channel.')
                ]
            });
        }
        emoji = args[3];
    } else if (type === 'user') {
        target = getUserFromMention(message, args[2]);
        if (!target) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a valid user.')
                ]
            });
        }
        emoji = args[3];
    } else if (type === 'role') {
        target = getRoleFromMention(message, args[2]);
        if (!target) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a valid role.')
                ]
            });
        }
        emoji = args[3];
    } else if (type === 'keyword') {
        mode = args[2]?.toLowerCase();
        if (!['include', 'exact'].includes(mode)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Keyword mode must be `include` or `exact`.')
                ]
            });
        }
        keyword = args[3]?.toLowerCase();
        emoji = args[4];
    }

    if (!emoji) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Please provide an emoji.')
            ]
        });
    }

    // Test if emoji is valid
    try {
        await message.react(emoji);
        await message.reactions.cache.get(emoji)?.users.remove(client.user.id);
    } catch (error) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Invalid emoji. Please use a valid emoji.')
            ]
        });
    }

    // Create autoreactor data
    const autoreactor = {
        type: type,
        target: target ? target.id : null,
        emoji: emoji,
        mode: mode || null,
        keyword: keyword || null,
        createdBy: message.author.id,
        createdAt: new Date()
    };

    // Generate unique key
    let key;
    if (type === 'keyword') {
        key = `${message.guild.id}_autoreactor_${type}_${keyword}`;
    } else {
        key = `${message.guild.id}_autoreactor_${type}_${target.id}`;
    }

    // Save to database
    await client.db.set(key, autoreactor);

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('<:tick:1387502929115877436> AutoReactor Created')
        .setDescription(`**Type:** ${type}\n**Target:** ${target ? target : keyword}\n**Emoji:** ${emoji}${mode ? `\n**Mode:** ${mode}` : ''}`)
        .setFooter({
            text: `Created by ${message.author.tag}`
        });

    return message.reply({ embeds: [embed] });
}

async function handleRemove(client, message, args) {
    const type = args[1]?.toLowerCase();
    if (!['channel', 'user', 'role', 'keyword'].includes(type)) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Invalid type. Use: `channel`, `user`, `role`, or `keyword`.')
            ]
        });
    }

    let target, keyword, key;
    
    if (type === 'channel') {
        target = getChannelFromMention(message, args[2]);
        if (!target) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a valid channel.')
                ]
            });
        }
        key = `${message.guild.id}_autoreactor_${type}_${target.id}`;
    } else if (type === 'user') {
        target = getUserFromMention(message, args[2]);
        if (!target) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a valid user.')
                ]
            });
        }
        key = `${message.guild.id}_autoreactor_${type}_${target.id}`;
    } else if (type === 'role') {
        target = getRoleFromMention(message, args[2]);
        if (!target) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a valid role.')
                ]
            });
        }
        key = `${message.guild.id}_autoreactor_${type}_${target.id}`;
    } else if (type === 'keyword') {
        keyword = args[2]?.toLowerCase();
        if (!keyword) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please provide a keyword.')
                ]
            });
        }
        key = `${message.guild.id}_autoreactor_${type}_${keyword}`;
    }

    const existing = await client.db.get(key);
    if (!existing) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> AutoReactor not found.')
            ]
        });
    }

    await client.db.delete(key);

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('<:tick:1387502929115877436> AutoReactor Removed')
        .setDescription(`**Type:** ${type}\n**Target:** ${target ? target : keyword}`)
        .setFooter({
            text: `Removed by ${message.author.tag}`
        });

    return message.reply({ embeds: [embed] });
}

async function handleList(client, message, args) {
    const category = args[1]?.toLowerCase();
    if (!['channels', 'users', 'roles', 'keywords', 'all'].includes(category)) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Invalid category. Use: `channels`, `users`, `roles`, `keywords`, or `all`.')
            ]
        });
    }

    const allKeys = await client.db.all();
    let autoreactors = allKeys.filter(item => 
        item.ID.startsWith(`${message.guild.id}_autoreactor_`)
    );

    if (category !== 'all') {
        const filterType = category.slice(0, -1); // Remove 's' from end
        autoreactors = autoreactors.filter(item => item.data.type === filterType);
    }

    if (autoreactors.length === 0) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> No autoreactors found.')
            ]
        });
    }

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle(`<:ravionshield:1386589347465400340> AutoReactors - ${category.charAt(0).toUpperCase() + category.slice(1)}`)
        .setDescription(`Found ${autoreactors.length} autoreactor(s)`)
        .setFooter({
            text: `Developed by ${client.user.username} Development`
        });

    let description = '';
    for (const item of autoreactors.slice(0, 15)) {
        const data = item.data;
        let targetName = '';
        
        if (data.type === 'channel') {
            const channel = message.guild.channels.cache.get(data.target);
            targetName = channel ? `#${channel.name}` : 'Unknown Channel';
        } else if (data.type === 'user') {
            const user = await client.users.fetch(data.target).catch(() => null);
            targetName = user ? user.tag : 'Unknown User';
        } else if (data.type === 'role') {
            const role = message.guild.roles.cache.get(data.target);
            targetName = role ? `@${role.name}` : 'Unknown Role';
        } else if (data.type === 'keyword') {
            targetName = `${data.keyword} (${data.mode})`;
        }

        description += `**${data.type}** - ${targetName} → ${data.emoji}\n`;
    }

    if (autoreactors.length > 15) {
        description += `\n... and ${autoreactors.length - 15} more`;
    }

    embed.setDescription(description);
    return message.reply({ embeds: [embed] });
}

async function handleReset(client, message, args) {
    const category = args[1]?.toLowerCase();
    if (!['channels', 'users', 'roles', 'keywords', 'all'].includes(category)) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Invalid category. Use: `channels`, `users`, `roles`, `keywords`, or `all`.')
            ]
        });
    }

    const allKeys = await client.db.all();
    let autoreactors = allKeys.filter(item => 
        item.ID.startsWith(`${message.guild.id}_autoreactor_`)
    );

    if (category !== 'all') {
        const filterType = category.slice(0, -1); // Remove 's' from end
        autoreactors = autoreactors.filter(item => item.data.type === filterType);
    }

    if (autoreactors.length === 0) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> No autoreactors to reset.')
            ]
        });
    }

    for (const item of autoreactors) {
        await client.db.delete(item.ID);
    }

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('<:tick:1387502929115877436> AutoReactors Reset')
        .setDescription(`**Category:** ${category}\n**Deleted:** ${autoreactors.length} autoreactor(s)`)
        .setFooter({
            text: `Reset by ${message.author.tag}`
        });

    return message.reply({ embeds: [embed] });
}

// Helper functions
function getUserFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<@!?(\d+)>$/);
    if (!matches) return null;
    return message.guild.members.cache.get(matches[1]);
}

function getRoleFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<@&(\d+)>$/);
    if (!matches) return null;
    return message.guild.roles.cache.get(matches[1]);
}

function getChannelFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<#(\d+)>$/);
    if (!matches) return null;
    return message.guild.channels.cache.get(matches[1]);
}