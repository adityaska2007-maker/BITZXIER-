const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'autoresponder',
    aliases: ['ar', 'autoresponse'],
    category: 'autoresponder',
    premium: false,
    run: async (client, message, args) => {
        if (!message.member.permissions.has('Administrator')) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> You need Administrator permission to use this command.')
                ]
            });
        }

        const subcommand = args[0]?.toLowerCase();

        if (!subcommand) {
            return showHelp(message, client);
        }

        switch (subcommand) {
            case 'create':
                return handleCreate(client, message, args);
            case 'delete':
                return handleDelete(client, message, args);
            case 'list':
                return handleList(client, message);
            case 'setmode':
                return handleSetMode(client, message, args);
            case 'autodel':
                return handleAutoDelete(client, message, args);
            case 'reply':
                return handleReply(client, message, args);
            case 'variables':
                return showVariables(message, client);
            case 'reset':
                return handleReset(client, message);
            case 'ignore':
                return handleIgnore(client, message, args);
            default:
                return showHelp(message, client);
        }
    }
};

async function showHelp(message, client) {
    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('Autoresponder Module')
        .setDescription('Automatically respond to messages based on triggers.')
        .addFields(
            {
                name: 'Create Autoresponders',
                value: '`create channel <#channel> <trigger> <reply>`\n`create user <@user> <trigger> <reply>`\n`create role <@role> <trigger> <reply>`\n`create global <trigger> <reply>`',
                inline: false
            },
            {
                name: 'Delete Autoresponders',
                value: '`delete <type> <trigger>`',
                inline: false
            },
            {
                name: 'Configuration',
                value: '`mode <trigger> <include|exact>`\n`autodel <trigger> <seconds>`\n`reply <trigger> <true|false>`',
                inline: false
            },
            {
                name: 'Management',
                value: '`list` - Show all autoresponders\n`reset` - Clear all autoresponders\n`variables` - Show available variables\n`ignore <add|remove|list> <user|role> <@mention>`',
                inline: false
            }
        )
        .setFooter({
            text: `Developed by ${client.user.username} Development`
        });

    return message.reply({ embeds: [embed] });
}

async function handleCreate(client, message, args) {
    const type = args[1]?.toLowerCase();
    if (!['keyword', 'user', 'role', 'channel'].includes(type)) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Invalid type. Use: `keyword`, `user`, `role`, or `channel`.')
            ]
        });
    }

    let target, trigger, reply;

    if (type === 'keyword') {
        trigger = args[2];
        reply = args.slice(3).join(' ');
    } else if (type === 'user') {
        target = getUserFromMention(message, args[2]);
        if (!target) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a valid user.')
                ]
            });
        }
        trigger = args[3];
        reply = args.slice(4).join(' ');
    } else if (type === 'role') {
        target = getRoleFromMention(message, args[2]);
        if (!target) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a valid role.')
                ]
            });
        }
        trigger = args[3];
        reply = args.slice(4).join(' ');
    } else if (type === 'channel') {
        target = getChannelFromMention(message, args[2]);
        if (!target) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a valid channel.')
                ]
            });
        }
        trigger = args[3];
        reply = args.slice(4).join(' ');
    }

    if (!trigger || !reply) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Please provide both trigger and reply.')
            ]
        });
    }

    // Create autoresponder data
    const autoresponder = {
        type: type,
        trigger: trigger.toLowerCase(),
        reply: reply,
        target: target ? target.id : null,
        mode: 'include',
        autoDelete: 0,
        replyToUser: false,
        createdBy: message.author.id,
        createdAt: new Date()
    };

    // Save to database
    await client.db.set(`${message.guild.id}_autoresponder_${type}_${trigger.toLowerCase()}`, autoresponder);

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('<:tick:1387502929115877436> Autoresponder Created')
        .setDescription(`**Type:** ${type}\n**Trigger:** ${trigger}\n**Reply:** ${reply}${target ? `\n**Target:** ${target}` : ''}`)
        .setFooter({
            text: `Created by ${message.author.tag}`
        });

    return message.reply({ embeds: [embed] });
}

async function handleDelete(client, message, args) {
    const type = args[1]?.toLowerCase();
    const trigger = args[2]?.toLowerCase();

    if (!type || !trigger) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Please provide type and trigger.')
            ]
        });
    }

    const key = `${message.guild.id}_autoresponder_${type}_${trigger}`;
    const existing = await client.db.get(key);

    if (!existing) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Autoresponder not found.')
            ]
        });
    }

    await client.db.delete(key);

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('<:tick:1387502929115877436> Autoresponder Deleted')
        .setDescription(`**Type:** ${type}\n**Trigger:** ${trigger}`)
        .setFooter({
            text: `Deleted by ${message.author.tag}`
        });

    return message.reply({ embeds: [embed] });
}

async function handleList(client, message) {
    const allKeys = await client.db.all();
    const autoresponders = allKeys.filter(item => 
        item.ID.startsWith(`${message.guild.id}_autoresponder_`)
    );

    if (autoresponders.length === 0) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> No autoresponders found.')
            ]
        });
    }

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('Autoresponders List')
        .setDescription(`Found ${autoresponders.length} autoresponder(s)`)
        .setFooter({
            text: `Developed by ${client.user.username} Development`
        });

    let description = '';
    for (const item of autoresponders.slice(0, 10)) {
        const data = item.data;
        description += `**${data.type}** - \`${data.trigger}\` → ${data.reply.substring(0, 50)}${data.reply.length > 50 ? '...' : ''}\n`;
    }

    if (autoresponders.length > 10) {
        description += `\n... and ${autoresponders.length - 10} more`;
    }

    embed.setDescription(description);
    return message.reply({ embeds: [embed] });
}

async function handleSetMode(client, message, args) {
    const trigger = args[1]?.toLowerCase();
    const mode = args[2]?.toLowerCase();

    if (!trigger || !['exact', 'include'].includes(mode)) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Usage: `setmode <trigger> <exact|include>`')
            ]
        });
    }

    // Find autoresponder
    const allKeys = await client.db.all();
    const autoresponder = allKeys.find(item => 
        item.ID.startsWith(`${message.guild.id}_autoresponder_`) && 
        item.data.trigger === trigger
    );

    if (!autoresponder) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Autoresponder not found.')
            ]
        });
    }

    autoresponder.data.mode = mode;
    await client.db.set(autoresponder.ID, autoresponder.data);

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('<:tick:1387502929115877436> Mode Updated')
        .setDescription(`**Trigger:** ${trigger}\n**Mode:** ${mode}`)
        .setFooter({
            text: `Updated by ${message.author.tag}`
        });

    return message.reply({ embeds: [embed] });
}

async function handleAutoDelete(client, message, args) {
    const trigger = args[1]?.toLowerCase();
    const seconds = parseInt(args[2]);

    if (!trigger || isNaN(seconds) || seconds < 0 || seconds > 300) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Usage: `autodel <trigger> <seconds>` (0-300 seconds)')
            ]
        });
    }

    // Find autoresponder
    const allKeys = await client.db.all();
    const autoresponder = allKeys.find(item => 
        item.ID.startsWith(`${message.guild.id}_autoresponder_`) && 
        item.data.trigger === trigger
    );

    if (!autoresponder) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Autoresponder not found.')
            ]
        });
    }

    autoresponder.data.autoDelete = seconds;
    await client.db.set(autoresponder.ID, autoresponder.data);

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('<:tick:1387502929115877436> Auto Delete Updated')
        .setDescription(`**Trigger:** ${trigger}\n**Auto Delete:** ${seconds} seconds`)
        .setFooter({
            text: `Updated by ${message.author.tag}`
        });

    return message.reply({ embeds: [embed] });
}

async function handleReply(client, message, args) {
    const trigger = args[1]?.toLowerCase();
    const replyToUser = args[2]?.toLowerCase() === 'true';

    if (!trigger || !['true', 'false'].includes(args[2]?.toLowerCase())) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Usage: `reply <trigger> <true|false>`')
            ]
        });
    }

    // Find autoresponder
    const allKeys = await client.db.all();
    const autoresponder = allKeys.find(item => 
        item.ID.startsWith(`${message.guild.id}_autoresponder_`) && 
        item.data.trigger === trigger
    );

    if (!autoresponder) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Autoresponder not found.')
            ]
        });
    }

    autoresponder.data.replyToUser = replyToUser;
    await client.db.set(autoresponder.ID, autoresponder.data);

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('<:tick:1387502929115877436> Reply Setting Updated')
        .setDescription(`**Trigger:** ${trigger}\n**Reply to User:** ${replyToUser ? 'Yes' : 'No'}`)
        .setFooter({
            text: `Updated by ${message.author.tag}`
        });

    return message.reply({ embeds: [embed] });
}

async function showVariables(message, client) {
    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('Available Variables')
        .setDescription('Use these variables in your autoresponder replies:')
        .addFields(
            {
                name: '👤 User Variables',
                value: '`{mention:user}` - Mentions the user\n`{member:username}` - Username of sender\n`{member:tag}` - Full tag of sender\n`{member:id}` - User ID',
                inline: false
            },
            {
                name: '🏠 Server Variables',
                value: '`{server:name}` - Server name\n`{server:id}` - Server ID\n`{member:count}` - Total member count\n`{channel:name}` - Channel name',
                inline: false
            },
            {
                name: '📝 Example',
                value: 'Hello {mention:user}, welcome to {server:name}!',
                inline: false
            }
        )
        .setFooter({
            text: `Developed by ${client.user.username} Development`
        });

    return message.reply({ embeds: [embed] });
}

async function handleReset(client, message) {
    const allKeys = await client.db.all();
    const autoresponders = allKeys.filter(item => 
        item.ID.startsWith(`${message.guild.id}_autoresponder_`)
    );

    if (autoresponders.length === 0) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> No autoresponders to reset.')
            ]
        });
    }

    for (const item of autoresponders) {
        await client.db.delete(item.ID);
    }

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('<:tick:1387502929115877436> Autoresponders Reset')
        .setDescription(`Deleted ${autoresponders.length} autoresponder(s)`)
        .setFooter({
            text: `Reset by ${message.author.tag}`
        });

    return message.reply({ embeds: [embed] });
}

async function handleIgnore(client, message, args) {
    const action = args[1]?.toLowerCase();
    const type = args[2]?.toLowerCase();

    if (!action || !['add', 'remove', 'list'].includes(action)) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Usage: `ignore <add|remove|list> <user|role> <@mention>`')
            ]
        });
    }

    if (action === 'list') {
        const ignoreData = await client.db.get(`${message.guild.id}_autoresponder_ignore`) || { users: [], roles: [] };

        let description = '';
        if (ignoreData.users.length > 0) {
            description += '**Ignored Users:**\n';
            for (const userId of ignoreData.users) {
                const user = await client.users.fetch(userId).catch(() => null);
                description += `• ${user ? user.tag : userId}\n`;
            }
        }
        if (ignoreData.roles.length > 0) {
            description += '**Ignored Roles:**\n';
            for (const roleId of ignoreData.roles) {
                const role = message.guild.roles.cache.get(roleId);
                description += `• ${role ? role.name : roleId}\n`;
            }
        }

        if (!description) {
            description = 'No users or roles are being ignored.';
        }

        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('Ignore List')
            .setDescription(description)
            .setFooter({
                text: `Developed by ${client.user.username} Development`
            });

        return message.reply({ embeds: [embed] });
    }

    if (!type || !['user', 'role'].includes(type)) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Please specify `user` or `role`.')
            ]
        });
    }

    let target;
    if (type === 'user') {
        target = getUserFromMention(message, args[3]);
        if (!target) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a valid user.')
                ]
            });
        }
    } else if (type === 'role') {
        target = getRoleFromMention(message, args[3]);
        if (!target) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a valid role.')
                ]
            });
        }
    }

    const ignoreData = await client.db.get(`${message.guild.id}_autoresponder_ignore`) || { users: [], roles: [] };

    if (action === 'add') {
        if (type === 'user') {
            if (!ignoreData.users.includes(target.id)) {
                ignoreData.users.push(target.id);
            }
        } else if (type === 'role') {
            if (!ignoreData.roles.includes(target.id)) {
                ignoreData.roles.push(target.id);
            }
        }
    } else if (action === 'remove') {
        if (type === 'user') {
            ignoreData.users = ignoreData.users.filter(id => id !== target.id);
        } else if (type === 'role') {
            ignoreData.roles = ignoreData.roles.filter(id => id !== target.id);
        }
    }

    await client.db.set(`${message.guild.id}_autoresponder_ignore`, ignoreData);

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('<:tick:1387502929115877436> Ignore List Updated')
        .setDescription(`**Action:** ${action}\n**Type:** ${type}\n**Target:** ${target}`)
        .setFooter({
            text: `Updated by ${message.author.tag}`
        });

    return message.reply({ embeds: [embed] });
}

// Helper functions
function getUserFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<@!?(\d+)>$/);
    if (!matches) return null;
    return message.guild.members.cache.get(matches[1]);
}

function getRoleFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<@&(\d+)>$/);
    if (!matches) return null;
    return message.guild.roles.cache.get(matches[1]);
}

function getChannelFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<#(\d+)>$/);
    if (!matches) return null;
    return message.guild.channels.cache.get(matches[1]);
}