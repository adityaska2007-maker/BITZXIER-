
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');

module.exports = {
    name: 'ticket',
    category: 'ticket',
    description: 'Main ticket system command',
    usage: 'ticket',
    run: async (client, message, args) => {
        const subcommand = args[0]?.toLowerCase();

        if (subcommand === 'panel') {
            const panelCommand = require('./ticketpanel');
            return panelCommand.run(client, message, args.slice(1));
        }

        if (subcommand === 'channel') {
            const channelCommand = require('./ticketchannel');
            return channelCommand.run(client, message, args.slice(1));
        }

        if (subcommand === 'member') {
            const memberCommand = require('./ticketmember');
            return memberCommand.run(client, message, args.slice(1));
        }

        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('Ticket System')
            .setDescription('Advanced ticket management system for your server')
            .addFields([
                {
                    name: 'Panel Commands',
                    value: '`ticket panel setup` - Setup ticket panel\n`ticket panel enable` - Enable ticket panel\n`ticket panel disable` - Disable ticket panel\n`ticket panel list` - List all panels\n`ticket panel reset` - Reset panel settings'
                },
                {
                    name: 'Channel Commands', 
                    value: '`ticket channel close` - Close current ticket\n`ticket channel delete` - Delete current ticket\n`ticket channel open` - Reopen ticket\n`ticket channel rename <name>` - Rename ticket'
                },
                {
                    name: 'Member Commands',
                    value: '`ticket member add <user>` - Add user to ticket\n`ticket member remove <user>` - Remove user from ticket'
                }
            ])
            .setFooter({ text: `Developed by ${client.user.username}`, iconURL: client.user.displayAvatarURL() })
            .setTimestamp();

        return message.reply({ embeds: [embed] });
    }
};
