
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'ticketmember',
    aliases: ['tmember'],
    category: 'ticket',
    description: 'Manage ticket members',
    usage: 'ticketmember <add|remove> <user>',
    run: async (client, message, args) => {
        const subcommand = args[0]?.toLowerCase();
        const user = message.mentions.users.first() || await client.users.fetch(args[1]).catch(() => null);

        if (!user) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('<:cross:1387502959444758580> Please mention a user or provide a valid user ID.')
                ]
            });
        }

        switch (subcommand) {
            case 'add':
                return handleAdd(client, message, user);
            case 'remove':
                return handleRemove(client, message, user);
            default:
                return showHelp(client, message);
        }
    }
};

async function showHelp(client, message) {
    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('👥 Ticket Member Commands')
        .addFields([
            { name: '`ticketmember add <user>`', value: 'Add user to current ticket', inline: true },
            { name: '`ticketmember remove <user>`', value: 'Remove user from current ticket', inline: true }
        ]);
    
    return message.reply({ embeds: [embed] });
}

async function handleAdd(client, message, user) {
    if (!message.channel.name.startsWith('ticket-')) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> This command can only be used in ticket channels.')
            ]
        });
    }

    try {
        await message.channel.permissionOverwrites.edit(user.id, {
            VIEW_CHANNEL: true,
            SEND_MESSAGES: true,
            READ_MESSAGE_HISTORY: true
        });

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setDescription(`<:check:1387502959444758579> ${user} has been added to this ticket.`)
            .setTimestamp();

        return message.reply({ embeds: [embed] });
    } catch (error) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Failed to add user to the ticket.')
            ]
        });
    }
}

async function handleRemove(client, message, user) {
    if (!message.channel.name.startsWith('ticket-')) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> This command can only be used in ticket channels.')
            ]
        });
    }

    try {
        await message.channel.permissionOverwrites.edit(user.id, {
            VIEW_CHANNEL: false
        });

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setDescription(`<:check:1387502959444758579> ${user} has been removed from this ticket.`)
            .setTimestamp();

        return message.reply({ embeds: [embed] });
    } catch (error) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Failed to remove user from the ticket.')
            ]
        });
    }
}
