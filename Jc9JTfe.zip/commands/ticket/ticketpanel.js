
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    name: 'ticketpanel',
    aliases: ['tpanel'],
    category: 'ticket',
    description: 'Manage ticket panels',
    usage: 'ticketpanel <setup|enable|disable|list|reset>',
    run: async (client, message, args) => {
        const subcommand = args[0]?.toLowerCase();

        switch (subcommand) {
            case 'setup':
                return handleSetup(client, message);
            case 'enable':
                return handleEnable(client, message);
            case 'disable':
                return handleDisable(client, message);
            case 'list':
                return handleList(client, message);
            case 'reset':
                return handleReset(client, message);
            default:
                return showHelp(client, message);
        }
    }
};

async function showHelp(client, message) {
    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('🎫 Ticket Panel Commands')
        .addFields([
            { name: '`ticketpanel setup`', value: 'Setup a new ticket panel', inline: true },
            { name: '`ticketpanel enable`', value: 'Enable ticket panel', inline: true },
            { name: '`ticketpanel disable`', value: 'Disable ticket panel', inline: true },
            { name: '`ticketpanel list`', value: 'List all panels', inline: true },
            { name: '`ticketpanel reset`', value: 'Reset panel settings', inline: true }
        ]);
    
    return message.reply({ embeds: [embed] });
}

async function handleSetup(client, message) {
    const ticketData = await client.db.get(`ticket_${message.guild.id}`) || {};

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('Ticket Panel Setup')
        .setDescription(`Configure your ticket panel settings by clicking the buttons below`)
        .addFields([
            { name: 'Ticket Channel:', value: ticketData.channel ? `<#${ticketData.channel}>` : 'None' },
            { name: 'Support Role:', value: ticketData.supportRole ? `<@&${ticketData.supportRole}>` : 'None' },
            { name: 'Ping Role:', value: ticketData.pingRole ? `<@&${ticketData.pingRole}>` : 'None' },
            { name: 'Open Tickets Category:', value: ticketData.openCategory ? (message.guild.channels.cache.get(ticketData.openCategory)?.name || 'Unknown') : 'None' },
            { name: 'Closed Tickets Category:', value: ticketData.closedCategory ? (message.guild.channels.cache.get(ticketData.closedCategory)?.name || 'Unknown') : 'None' },
            { name: "Ticket's Embed Title:", value: ticketData.embedTitle || 'Ticket Panel' },
            { name: "Ticket's Embed Description:", value: ticketData.embedDescription || 'Support will be with you shortly' }
        ])
        .setFooter({ text: `${message.author.tag} | Today at ${new Date().toLocaleTimeString()}`, iconURL: message.author.displayAvatarURL() });

    const row1 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('ticket_channel')
                .setLabel('Ticket Channel')
                .setStyle(1),
            new ButtonBuilder()
                .setCustomId('support_role')
                .setLabel('Support Role')
                .setStyle(1)
        );

    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('ping_role')
                .setLabel('Ping Role')
                .setStyle(1),
            new ButtonBuilder()
                .setCustomId('open_category')
                .setLabel('Open Ticket Category')
                .setStyle(1)
        );

    const row3 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('closed_category')
                .setLabel('Closed Ticket Category')
                .setStyle(1),
            new ButtonBuilder()
                .setCustomId('embed_message')
                .setLabel('Embed Message')
                .setStyle(1)
        );

    const row4 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('abort_setup')
                .setLabel('Abort')
                .setStyle(4),
            new ButtonBuilder()
                .setCustomId('done_setup')
                .setLabel('Done')
                .setStyle(3)
        );

    return message.reply({ 
        embeds: [embed], 
        components: [row1, row2, row3, row4] 
    });
}

async function handleEnable(client, message) {
    const ticketData = await client.db.get(`ticket_${message.guild.id}`);
    
    if (!ticketData) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> No ticket panel found. Use `ticketpanel setup` first.')
            ]
        });
    }

    await client.db.set(`ticket_${message.guild.id}.enabled`, true);
    
    return message.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#00FF00')
                .setDescription('<:check:1387502959444758579> Ticket panel has been enabled.')
        ]
    });
}

async function handleDisable(client, message) {
    await client.db.set(`ticket_${message.guild.id}.enabled`, false);
    
    return message.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#FF0000')
                .setDescription('<:cross:1387502959444758580> Ticket panel has been disabled.')
        ]
    });
}

async function handleList(client, message) {
    const ticketData = await client.db.get(`ticket_${message.guild.id}`);
    
    if (!ticketData) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> No ticket panels found.')
            ]
        });
    }

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('🎫 Ticket Panels')
        .setDescription(`Found 1 ticket panel(s)`)
        .addFields([
            { name: 'Channel:', value: ticketData.channel ? `<#${ticketData.channel}>` : 'None' },
            { name: 'Support Role:', value: ticketData.supportRole ? `<@&${ticketData.supportRole}>` : 'None' },
            { name: 'Status:', value: ticketData.enabled ? '✅ Enabled' : '❌ Disabled' }
        ]);

    return message.reply({ embeds: [embed] });
}

async function handleReset(client, message) {
    await client.db.delete(`ticket_${message.guild.id}`);
    
    return message.reply({
        embeds: [
            new EmbedBuilder()
                .setColor('#00FF00')
                .setDescription('<:check:1387502959444758579> Ticket panel settings have been reset.')
        ]
    });
}
