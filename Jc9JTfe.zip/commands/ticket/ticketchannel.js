
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');

module.exports = {
    name: 'ticketchannel',
    aliases: ['tchannel'],
    category: 'ticket',
    description: 'Manage ticket channels',
    usage: 'ticketchannel <close|delete|open|rename>',
    run: async (client, message, args) => {
        const subcommand = args[0]?.toLowerCase();

        switch (subcommand) {
            case 'close':
                return handleClose(client, message);
            case 'delete':
                return handleDelete(client, message);
            case 'open':
                return handleOpen(client, message);
            case 'rename':
                return handleRename(client, message, args);
            default:
                return showHelp(client, message);
        }
    }
};

async function showHelp(client, message) {
    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle('🎫 Ticket Channel Commands')
        .addFields([
            { name: '`ticketchannel close`', value: 'Close current ticket', inline: true },
            { name: '`ticketchannel delete`', value: 'Delete current ticket', inline: true },
            { name: '`ticketchannel open`', value: 'Reopen ticket', inline: true },
            { name: '`ticketchannel rename <name>`', value: 'Rename ticket channel', inline: true }
        ]);
    
    return message.reply({ embeds: [embed] });
}

async function handleClose(client, message) {
    if (!message.channel.name.startsWith('ticket-')) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> This command can only be used in ticket channels.')
            ]
        });
    }

    const ticketData = await client.db.get(`tickets_${message.guild.id}_${message.channel.id}`);
    if (!ticketData) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> This is not a valid ticket channel.')
            ]
        });
    }

    const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('🔒 Ticket Closed')
        .setDescription(`Ticket closed by ${message.author}`)
        .setTimestamp();

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('reopen_ticket')
                .setLabel('Reopen Ticket')
                .setStyle(3)
                .setEmoji('🔓'),
            new ButtonBuilder()
                .setCustomId('delete_ticket')
                .setLabel('Delete Ticket')
                .setStyle(4)
                .setEmoji('🗑️')
        );

    // Close the ticket (remove permissions)
    await message.channel.permissionOverwrites.edit(ticketData.userId, {
        VIEW_CHANNEL: false
    });

    await client.db.set(`tickets_${message.guild.id}_${message.channel.id}.status`, 'closed');

    return message.reply({ embeds: [embed], components: [row] });
}

async function handleDelete(client, message) {
    if (!message.channel.name.startsWith('ticket-')) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> This command can only be used in ticket channels.')
            ]
        });
    }

    const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('🗑️ Delete Ticket')
        .setDescription('Are you sure you want to delete this ticket? This action cannot be undone.')
        .setTimestamp();

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('confirm_delete')
                .setLabel('Confirm Delete')
                .setStyle(4)
                .setEmoji('✅'),
            new ButtonBuilder()
                .setCustomId('cancel_delete')
                .setLabel('Cancel')
                .setStyle(2)
                .setEmoji('❌')
        );

    return message.reply({ embeds: [embed], components: [row] });
}

async function handleOpen(client, message) {
    if (!message.channel.name.startsWith('ticket-')) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> This command can only be used in ticket channels.')
            ]
        });
    }

    const ticketData = await client.db.get(`tickets_${message.guild.id}_${message.channel.id}`);
    if (!ticketData || ticketData.status !== 'closed') {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> This ticket is not closed.')
            ]
        });
    }

    // Reopen the ticket
    await message.channel.permissionOverwrites.edit(ticketData.userId, {
        VIEW_CHANNEL: true,
        SEND_MESSAGES: true,
        READ_MESSAGE_HISTORY: true
    });

    await client.db.set(`tickets_${message.guild.id}_${message.channel.id}.status`, 'open');

    const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('🔓 Ticket Reopened')
        .setDescription(`Ticket reopened by ${message.author}`)
        .setTimestamp();

    return message.reply({ embeds: [embed] });
}

async function handleRename(client, message, args) {
    if (!message.channel.name.startsWith('ticket-')) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> This command can only be used in ticket channels.')
            ]
        });
    }

    const newName = args.slice(1).join('-').toLowerCase();
    if (!newName) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Please provide a new name for the ticket.')
            ]
        });
    }

    try {
        await message.channel.setName(`ticket-${newName}`);
        
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#00FF00')
                    .setDescription(`<:check:1387502959444758579> Ticket renamed to \`ticket-${newName}\``)
            ]
        });
    } catch (error) {
        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('<:cross:1387502959444758580> Failed to rename the ticket channel.')
            ]
        });
    }
}
