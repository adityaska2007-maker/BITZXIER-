// Load environment variables if .env file exists
try {
    require('dotenv').config()
} catch(e) {
    console.log('dotenv not available, using environment variables directly');
}

// Setup module aliases
try {
    require('module-alias/register')
} catch(e) {
    console.log('module-alias not available, using direct requires');
}

const path = require('path')
const Bitzxier = require(`./structures/Bitzxier.js`)
const client = new Bitzxier()
const config = require(`${process.cwd()}/config.json`);

// Simple wait function to replace the wait module
function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

(async () => {
    try {
        console.log('🚀 Starting BITZXIER Bot with performance optimizations...')
        
        // Parallel initialization for faster startup
        const [mongooseResult, enmapResult] = await Promise.all([
            client.initializeMongoose(),
            client.initializedata()
        ]);
        
        // Parallel loading of events and commands
        const [eventsResult, logsResult, commandsResult] = await Promise.all([
            client.loadEvents(),
            client.loadlogs(), 
            client.loadMain()
        ]);
        
        // Login to Discord with error handling
        console.log('🔐 Attempting to login to Discord...');
        try {
            await client.login(process.env.DISCORD_BOT_TOKEN || config.TOKEN);
            console.log('✅ Bot startup completed successfully!');
        } catch (loginError) {
            console.error('❌ Login failed:', loginError.message);
            if (loginError.message.includes('TOKEN')) {
                console.error('🔑 Token issue detected - please check your bot token');
            }
            throw loginError;
        }
    } catch (error) {
        console.error('❌ Error starting bot:', error);
        process.exit(1);
    }
})()
