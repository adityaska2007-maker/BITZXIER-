const { Client, Collection, GatewayIntentBits, WebhookClient } = require('discord.js')
const fs = require('fs')
const mongoose = require('mongoose')
const Utils = require('./util')
const { glob } = require('glob')
const { promisify } = require('util')
const { Database } = require('quickmongo')
const axios = require('axios')
const Sweepers = require('./Sweepers')
const Enmap = require('enmap');



module.exports = class Bitzxier extends Client {
    constructor() {
        super({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.GuildMembers,
                GatewayIntentBits.GuildModeration,
                GatewayIntentBits.GuildEmojisAndStickers,
                GatewayIntentBits.GuildVoiceStates,
                GatewayIntentBits.GuildMessageReactions,
                GatewayIntentBits.DirectMessages,
                GatewayIntentBits.MessageContent
            ],
            fetchAllMembers: false,
            shards: 'auto',
            disableEveryone: true,
            // Basic performance optimizations (safe for connection)
            allowedMentions: { parse: ['users', 'roles'], repliedUser: false },
            sweepers: {
                messages: {
                    interval: 300,
                    lifetime: 60
                }
            }
        })

        this.config = require(`${process.cwd()}/config.json`)
        this.logger = require('./logger')
        this.commands = new Collection()
        this.categories = fs.readdirSync('./commands/')
        this.emoji = {
            tick: '<:tick:1393824208940961794>',
            cross: '<:cross:1393824190012063806>',
            dot: '<:ravionutil:1386591198323413055>',
            automod: '<:ravionautomod:1386588832492687421>',
            announc: '<:ravionannouc:1386589923536277555>',
            plus: '<:Ravionplus:1386592253811757167>',
            notification: '<:Ravionnotification:1386590018356772994>',
            bin: '<:Ravionbin:1386592840812986369>',
            bag: '<:ravionbag:1386591471301427243>',
            catch: '<:ravioncatch:1386587471114145914>',
            compass: '<:ravioncompass:1386590977929646181>',
            date: '<:raviondate:1386589845140537346>',
            deafen: '<:raviondeafen:1386590777093918771>',
            dev: '<:raviondev:1386591937020297346>',
            disabled: '<:disabled:1386383831678058627>',
            enabled: '<:enabled:1386383694012481628>',
            face: '<:ravionface:1386589092418031677>',
            galaxy: '<:raviongalaxy:1386591319559770152>',
            games: '<:raviongames:1386591752529510422>',
            globe: '<:ravionglobe:1386591009349304374>',
            headphone: '<:ravionheadphone:1386590736979595264>',
            home: '<:ravionhome:1386587089948381197>',
            infinity: '<:ravioninfinity:1386587622100439173>',
            info: '<:ravioninfo:1386591789577797721>',
            leaf: '<:ravionleaf:1386588965267574924>',
            member: '<:ravionmember:1386590099525079093>',
            mic: '<:ravionmic:1386590171746795571>',
            mobile: '<:ravionmobile:1386591818120171622>',
            mod: '<:ravionmod:1386587291320975361>',
            partner: '<:ravionpartner:1386587702438133810>',
            pin: '<:ravionpin:1386590914968817787>',
            planet: '<:ravionplanet:1386591369723904202>',
            plant: '<:ravionplant:1386587384191258655>',
            replit: '<:ravionreplit:1386592160039571556>',
            reply: '<:ravionreply:1386592127970185286>',
            rocket: '<:ravionrocket:1386593029804261417>',
            search: '<:ravionsearch:1386592895150198794>',
            settings: '<:ravionsetting:1386593217297780836>',
            shield: '<:ravionshield:1386589347465400340>',
            speaker: '<:ravionspeaker:1386593001069088789>',
            staff: '<:ravionstaff:1386587204100423710>',
            util: '<:ravionutil:1386591198323413055>',
            vc: '<:ravionvc:1386589611416883321>',
            vclock: '<:ravionvclock:1386589690903138304>',
            trophy: '<:raviontrophy:1386592932689215489>',
            discotools: '<:discotools_xyz_icon___2025_07_20:1396361038617907274>',
            success: '<:tick:1393824208940961794>',
            warning: '<:ravionnotification:1386590018356772994>'
        }
        this.util = new Utils(this)
        this.Sweeper = new Sweepers(this)
        this.color = 0x2b2d31
        this.support = ` `
        this.cooldowns = new Collection()
        this.noprefix = []
        this.blacklist = []
        
        // Performance optimizations
        this.prefixCache = new Map()
        this.guildCache = new Map()
        this.userCache = new Map()
        this.commandCache = new Map()
        
        // Configure axios for better performance
        this.snek = require('axios').create({
            timeout: 5000,
            maxRedirects: 2,
            validateStatus: status => status < 500
        })
        
        this.ratelimit = new WebhookClient({
            url: 'https://discord.com/api/webhooks/1217307952839659580/7zP31sS0A05e8-r1dIQV_mIZ0X--1THpe_NeRdKAnvgDHh2RmIi0xFlfz2Lqk2Zze7x0'
        })
        this.error = new WebhookClient({
            url: 'https://discord.com/api/webhooks/1217307864255955025/3sTJz2tmU6P9dWYPxfpqZnOoapwtU3txWDRAiAg09zYvt0xll4ha_w5Wvq7CfMAYAuOJ'
        })

        this.on('error', (error) => {
            this.error.send(`\`\`\`js\n${error.stack}\`\`\``)
        })
        process.on('unhandledRejection', (error) => {
            this.error.send(`\`\`\`js\n${error.stack}\`\`\``)
        })
        process.on('uncaughtException', (error) => {
            this.error.send(`\`\`\`js\n${error.stack}\`\`\``)
        })
        process.on('warning', (warn) => {
            this.error.send(`\`\`\`js\n${warn}\`\`\``)
        })
        process.on('uncaughtExceptionMonitor', (err, origin) => {
            this.error.send(`\`\`\`js\n${err},${origin}\`\`\``)
        })
        this.on('rateLimit', (info) => {
            this.ratelimit.send({
                content: `\`\`\`js\nTimeout: ${info.timeout},\nLimit: ${info.limit},\nMethod: ${info.method},\nPath: ${info.path},\nRoute: ${info.route},\nGlobal: ${info.global}\`\`\``
            })
        })
        
        // Setup performance monitoring and cache cleanup
        this.setupPerformanceOptimizations()
    }
    
    setupPerformanceOptimizations() {
        // Regular cache cleanup to prevent memory leaks
        setInterval(() => {
            const cacheSize = this.prefixCache.size + this.guildCache.size + this.userCache.size + this.commandCache.size
            if (cacheSize > 10000) {
                this.prefixCache.clear()
                this.guildCache.clear()
                this.userCache.clear()
                this.commandCache.clear()
                this.logger.log(`Cache cleared to optimize memory usage (${cacheSize} entries)`, 'debug')
            }
        }, 300000) // Every 5 minutes
        
        // Performance monitoring
        setInterval(() => {
            const memUsage = process.memoryUsage()
            if (memUsage.heapUsed > 200 * 1024 * 1024) { // 200MB threshold
                this.logger.log(`High memory usage detected: ${Math.round(memUsage.heapUsed / 1024 / 1024)}MB`, 'warn')
                if (global.gc) {
                    global.gc()
                    this.logger.log('Garbage collection triggered', 'debug')
                }
            }
        }, 60000) // Every minute
    }
    async initializedata() {
        try {
            this.logger.log(`Initializing Enmap (local cache)...`)
            this.data = new Enmap()
            this.logger.log('Enmap (local cache) initialized successfully', 'ready')
        } catch (error) {
            this.logger.log(`Enmap initialization failed: ${error.message}`, 'error')
            throw error
        }
    }
    async initializeMongoose() {
        try {
            this.logger.log(`Connecting to MongoDB...`)
            
            // Initialize QuickMongo with optimized settings
            this.db = new Database(this.config.MONGO_DB)
            await this.db.connect()
            this.logger.log('✅ QuickMongo Database Connected', 'ready')
            
            // Initialize Mongoose with performance optimizations
            await mongoose.connect(this.config.MONGO_DB, {
                maxPoolSize: 10,
                minPoolSize: 5,
                maxIdleTimeMS: 30000,
                serverSelectionTimeoutMS: 5000,
                socketTimeoutMS: 45000,
                connectTimeoutMS: 10000,
                heartbeatFrequencyMS: 10000
            })
            this.logger.log('✅ Mongoose Database Connected', 'ready')
            
            // Test the database connection
            await this.db.set('connection_test', Date.now())
            const testValue = await this.db.get('connection_test')
            if (testValue) {
                this.logger.log('✅ Database connection test successful', 'ready')
                await this.db.delete('connection_test')
            } else {
                throw new Error('Database test failed - could not write/read test data')
            }
        } catch (error) {
            this.logger.log(`❌ Database connection failed: ${error.message}`, 'error')
            throw error
        }
    }

    async loadEvents() {
        const eventFiles = fs.readdirSync('./events/').filter(file => file.endsWith('.js'))
        
        // Parallel event loading for faster startup
        await Promise.all(eventFiles.map(file => {
            return new Promise((resolve) => {
                try {
                    const eventName = file.split('.')[0]
                    require(`${process.cwd()}/events/${file}`)(this)
                    this.logger.log(`Updated Event ${eventName}.`, 'event')
                    resolve()
                } catch (error) {
                    this.logger.log(`Failed to load event ${file}: ${error.message}`, 'error')
                    resolve()
                }
            })
        }))
    }

    async loadlogs() {
        fs.readdirSync('./logs/').forEach((file) => {
            let logevent = file.split('.')[0]
            require(`${process.cwd()}/logs/${file}`)(this)
            this.logger.log(`Updated Logs ${logevent}.`, 'event')
        })
    }
    async loadMain() {
        const commandFiles = []

        const commandDirectories = fs.readdirSync(`${process.cwd()}/commands`)

        for (const directory of commandDirectories) {
            const files = fs
                .readdirSync(`${process.cwd()}/commands/${directory}`)
                .filter((file) => file.endsWith('.js'))

            for (const file of files) {
                commandFiles.push(
                    `${process.cwd()}/commands/${directory}/${file}`
                )
            }
        }
        commandFiles.map((value) => {
            const file = require(value)
            const splitted = value.split('/')
            const directory = splitted[splitted.length - 2]
            if (file.name) {
                const properties = { directory, ...file }
                this.commands.set(file.name, properties)
            }
        })
        this.logger.log(`Updated ${this.commands.size} Commands.`, 'cmd')
    }
}
